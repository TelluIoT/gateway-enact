/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *        Implementation for Thing PosixMQTTAdapter
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#include "PosixMQTTAdapter.h"

/*****************************************************************************
 * Implementation for type : PosixMQTTAdapter
 *****************************************************************************/


// BEGIN: Code from the c_global annotation PosixMQTTAdapter

// END: Code from the c_global annotation PosixMQTTAdapter

// Declaration of prototypes:
//Prototypes: State Machine
void PosixMQTTAdapter_MQTTAdapterThing_OnExit(int state, struct PosixMQTTAdapter_Instance *_instance);
//Prototypes: Message Sending
void PosixMQTTAdapter_send_mqtt_mqtt_connected(struct PosixMQTTAdapter_Instance *_instance);
void PosixMQTTAdapter_send_mqtt_mqtt_disconnected(struct PosixMQTTAdapter_Instance *_instance);
void PosixMQTTAdapter_send_mqtt_mqtt_message(struct PosixMQTTAdapter_Instance *_instance, char * topic, uint8_t * payload, uint32_t size);
void PosixMQTTAdapter_send_mqtt_mqtt_error(struct PosixMQTTAdapter_Instance *_instance);
void PosixMQTTAdapter_send_mqtt_mqtt_message_published(struct PosixMQTTAdapter_Instance *_instance);
void PosixMQTTAdapter_send_mqtt_mqtt_topic_subscribed(struct PosixMQTTAdapter_Instance *_instance);
//Prototypes: Function
void f_PosixMQTTAdapter_init_properties(struct PosixMQTTAdapter_Instance *_instance);
void f_PosixMQTTAdapter_setTopicPrefix(struct PosixMQTTAdapter_Instance *_instance, char * src);
void mosquitto_connect_callback(struct mosquitto *mosq, struct PosixMQTTAdapter_Instance *_thing_instance, int result);
void mosquitto_disconnect_callback(struct mosquitto *mosq, struct PosixMQTTAdapter_Instance *_thing_instance, int result);
void mosquitto_publish_callback(struct mosquitto *mosq, struct PosixMQTTAdapter_Instance *_thing_instance, int msgid);
void mosquitto_message_callback(struct mosquitto *mosq, struct PosixMQTTAdapter_Instance *_thing_instance, const struct mosquitto_message * msg);
void mosquitto_subscription_callback(struct mosquitto *mosq, struct PosixMQTTAdapter_Instance *_thing_instance, int msgid, int qos_count, const int * granted_qos);
void mosquitto_unsubscribe_callback(struct mosquitto *mosq, struct PosixMQTTAdapter_Instance *_thing_instance, int msgid);
void mosquitto_log_callback(struct mosquitto *mosq, struct PosixMQTTAdapter_Instance *_thing_instance, int level, const char * msg);
bool f_PosixMQTTAdapter_mqtt_connect(struct PosixMQTTAdapter_Instance *_instance);
void f_PosixMQTTAdapter_mqtt_publish(struct PosixMQTTAdapter_Instance *_instance, char * topic, uint8_t * payload, uint16_t size, uint8_t qos, bool retain);
void f_PosixMQTTAdapter_mqtt_subscribe(struct PosixMQTTAdapter_Instance *_instance, char * topic);
// Declaration of functions:
// Definition of function init_properties
void f_PosixMQTTAdapter_init_properties(struct PosixMQTTAdapter_Instance *_instance) {
_instance->AbstractMQTTAdapter_username_var = NULL;
_instance->AbstractMQTTAdapter_password_var = NULL;
_instance->AbstractMQTTAdapter_cafile_var = NULL;
_instance->AbstractMQTTAdapter_capath_var = NULL;
_instance->AbstractMQTTAdapter_certfile_var = NULL;
_instance->AbstractMQTTAdapter_keyfile_var = NULL;
}
// Definition of function setTopicPrefix
void f_PosixMQTTAdapter_setTopicPrefix(struct PosixMQTTAdapter_Instance *_instance, char * src) {
if (_instance->AbstractMQTTAdapter_topic_prefix_var != NULL) free(_instance->AbstractMQTTAdapter_topic_prefix_var);
		_instance->AbstractMQTTAdapter_topic_prefix_var = (char *)malloc(sizeof(char) * (strlen(src) + 1));
		if (_instance->AbstractMQTTAdapter_topic_prefix_var == NULL) {
fprintf(stderr, "[PANIC] Malloc failed to allocate memory to copy a String. Exiting...\n");
exit(-1);
} else {
			strcpy(_instance->AbstractMQTTAdapter_topic_prefix_var, src);
			printf("src:%s topic_prefix:%s\n", src, _instance->AbstractMQTTAdapter_topic_prefix_var);
		}
}
// Definition of function mosquitto_connect_callback
void mosquitto_connect_callback(struct mosquitto *mosq, struct PosixMQTTAdapter_Instance *_thing_instance, int result) {
if(result == 0) {
PosixMQTTAdapter_send_mqtt_mqtt_connected(_thing_instance);

}
}
// Definition of function mosquitto_disconnect_callback
void mosquitto_disconnect_callback(struct mosquitto *mosq, struct PosixMQTTAdapter_Instance *_thing_instance, int result) {
PosixMQTTAdapter_send_mqtt_mqtt_disconnected(_thing_instance);
}
// Definition of function mosquitto_publish_callback
void mosquitto_publish_callback(struct mosquitto *mosq, struct PosixMQTTAdapter_Instance *_thing_instance, int msgid) {
}
// Definition of function mosquitto_message_callback
void mosquitto_message_callback(struct mosquitto *mosq, struct PosixMQTTAdapter_Instance *_thing_instance, const struct mosquitto_message * msg) {
char* top = msg->topic;
		 if (_thing_instance->AbstractMQTTAdapter_topic_prefix_var != NULL) {
		 	int prefix_len = strlen(_thing_instance->AbstractMQTTAdapter_topic_prefix_var);
		 	
		 	if (strlen(top) > prefix_len && strncmp(top, _thing_instance->AbstractMQTTAdapter_topic_prefix_var, prefix_len) == 0) {
PosixMQTTAdapter_send_mqtt_mqtt_message(_thing_instance, top + prefix_len + 1, msg->payload, msg->payloadlen);
}
		 	else {
fprintf(stderr, "[MQTT] Receive message on topic with incorrect prefix.\n");
printf("   Topic:%s, Prefix:%s, prefix_len:%d\n", msg->topic, _thing_instance->AbstractMQTTAdapter_topic_prefix_var, prefix_len);
}
		 }
		 else {
PosixMQTTAdapter_send_mqtt_mqtt_message(_thing_instance, msg->topic, msg->payload, msg->payloadlen);
}
}
// Definition of function mosquitto_subscription_callback
void mosquitto_subscription_callback(struct mosquitto *mosq, struct PosixMQTTAdapter_Instance *_thing_instance, int msgid, int qos_count, const int * granted_qos) {
}
// Definition of function mosquitto_unsubscribe_callback
void mosquitto_unsubscribe_callback(struct mosquitto *mosq, struct PosixMQTTAdapter_Instance *_thing_instance, int msgid) {
}
// Definition of function mosquitto_log_callback
void mosquitto_log_callback(struct mosquitto *mosq, struct PosixMQTTAdapter_Instance *_thing_instance, int level, const char * msg) {
if(_thing_instance->PosixMQTTAdapter_debug_log_var) {
printf("[MQTT %s:%d] %s\n", _thing_instance->AbstractMQTTAdapter_client_id_var, level, msg);

}
}
// Definition of function mqtt_connect
bool f_PosixMQTTAdapter_mqtt_connect(struct PosixMQTTAdapter_Instance *_instance) {
int16_t status;
mosquitto_lib_init();
_instance->PosixMQTTAdapter_client_var = mosquitto_new(_instance->AbstractMQTTAdapter_client_id_var, true, _instance);;
if(_instance->PosixMQTTAdapter_client_var == NULL) {
fprintf(stderr, "[MQTT] Error creating MQTT client (mosquitto_new errno= ");
fprintf(stderr, "%i",errno);
fprintf(stderr, ")\n");
perror("[MQTT] mosquitto_new failed ");
return 0;

}
mosquitto_connect_callback_set(_instance->PosixMQTTAdapter_client_var, mosquitto_connect_callback);
mosquitto_disconnect_callback_set(_instance->PosixMQTTAdapter_client_var, mosquitto_disconnect_callback);
mosquitto_publish_callback_set(_instance->PosixMQTTAdapter_client_var, mosquitto_publish_callback);
mosquitto_message_callback_set(_instance->PosixMQTTAdapter_client_var, mosquitto_message_callback);
mosquitto_subscribe_callback_set(_instance->PosixMQTTAdapter_client_var, mosquitto_subscription_callback);
mosquitto_unsubscribe_callback_set(_instance->PosixMQTTAdapter_client_var, mosquitto_unsubscribe_callback);
mosquitto_log_callback_set(_instance->PosixMQTTAdapter_client_var, mosquitto_log_callback);
if(_instance->AbstractMQTTAdapter_enable_user_credentials_var) {
status = mosquitto_username_pw_set(_instance->PosixMQTTAdapter_client_var, _instance->AbstractMQTTAdapter_username_var, _instance->AbstractMQTTAdapter_password_var);;
if(status != MOSQ_ERR_SUCCESS) {
fprintf(stderr, "[MQTT] Error setting up username / password (mosquitto_username_pw_set returned ");
fprintf(stderr, "%i",status);
fprintf(stderr, ")\n");
return 0;

}

}
if(_instance->AbstractMQTTAdapter_enable_tls_var) {
if( !(_instance->AbstractMQTTAdapter_enable_tls_certificates_var)) {
status = mosquitto_tls_set(_instance->PosixMQTTAdapter_client_var, NULL, "~/certs", NULL, NULL, NULL);;
if(status != MOSQ_ERR_SUCCESS) {
fprintf(stderr, "[MQTT] Error setting up MQTT Client (mosquitto_tls_set returned ");
fprintf(stderr, "%i",status);
fprintf(stderr, ")\n");
return 0;

}

} else {
status = mosquitto_tls_set(_instance->PosixMQTTAdapter_client_var, _instance->AbstractMQTTAdapter_cafile_var, _instance->AbstractMQTTAdapter_capath_var, _instance->AbstractMQTTAdapter_certfile_var, _instance->AbstractMQTTAdapter_keyfile_var, NULL);;
if(status != MOSQ_ERR_SUCCESS) {
fprintf(stderr, "[MQTT] Error setting up MQTT Client (mosquitto_tls_set returned ");
fprintf(stderr, "%i",status);
fprintf(stderr, ")\n");
printf("cafile = %s\n", _instance->AbstractMQTTAdapter_cafile_var);
printf("capath = %s\n", _instance->AbstractMQTTAdapter_capath_var);
printf("certfile = %s\n", _instance->AbstractMQTTAdapter_certfile_var);
printf("keyfile = %s\n", _instance->AbstractMQTTAdapter_keyfile_var);
return 0;

}

}
status = mosquitto_tls_opts_set(_instance->PosixMQTTAdapter_client_var, 0, "tlsv1.2", NULL);;
if(status != MOSQ_ERR_SUCCESS) {
fprintf(stderr, "[MQTT] Error setting up MQTT Client (`mosquitto_tls_opts_set returned ");
fprintf(stderr, "%i",status);
fprintf(stderr, ")\n");
return 0;

}

}
status = mosquitto_loop_start(_instance->PosixMQTTAdapter_client_var);
if(status != MOSQ_ERR_SUCCESS) {
fprintf(stderr, "[MQTT] Error starting mosquitto loop thread (mosquitto_loop_start returned ");
fprintf(stderr, "%i",status);
fprintf(stderr, ")\n");
return 0;

}
status = mosquitto_connect_async(_instance->PosixMQTTAdapter_client_var, _instance->AbstractMQTTAdapter_broker_host_var, _instance->AbstractMQTTAdapter_broker_port_var, 10);
if(status != MOSQ_ERR_SUCCESS) {
fprintf(stderr, "[MQTT] Error connecting to broker (mosquitto_connect_async returned ");
fprintf(stderr, "%i",status);
fprintf(stderr, ")\n");
perror("[MQTT] mosquitto_connect_async failed ");
return 0;

}
return 1;
}
// Definition of function mqtt_publish
void f_PosixMQTTAdapter_mqtt_publish(struct PosixMQTTAdapter_Instance *_instance, char * topic, uint8_t * payload, uint16_t size, uint8_t qos, bool retain) {
char top[256];
if(_instance->AbstractMQTTAdapter_topic_prefix_var != NULL) {
snprintf(top, 256, "%s/%s", _instance->AbstractMQTTAdapter_topic_prefix_var, topic);

} else {
snprintf(top, 256, "%s", topic);

}
int16_t status = mosquitto_publish(_instance->PosixMQTTAdapter_client_var, NULL, top, size, payload, qos, retain);
if(status != MOSQ_ERR_SUCCESS) {
fprintf(stderr, "[MQTT] Error publishing message (mosquitto_publish returned ");
fprintf(stderr, "%i",status);
fprintf(stderr, ")\n");

}
}
// Definition of function mqtt_subscribe
void f_PosixMQTTAdapter_mqtt_subscribe(struct PosixMQTTAdapter_Instance *_instance, char * topic) {
char top[256];
if(_instance->AbstractMQTTAdapter_topic_prefix_var != NULL) {
snprintf(top, 256, "%s/%s", _instance->AbstractMQTTAdapter_topic_prefix_var, topic);

} else {
snprintf(top, 256, "%s", topic);

}
int16_t status = mosquitto_subscribe(_instance->PosixMQTTAdapter_client_var, NULL, top, 0);
if(status != MOSQ_ERR_SUCCESS) {
fprintf(stderr, "[MQTT] Error subscribing to topic (mosquitto_subscribe returned ");
fprintf(stderr, "%i",status);
fprintf(stderr, ")\n");

}
}

// Sessions functionss:


// On Entry Actions:
void PosixMQTTAdapter_MQTTAdapterThing_OnEntry(int state, struct PosixMQTTAdapter_Instance *_instance) {
switch(state) {
case POSIXMQTTADAPTER_MQTTADAPTERTHING_STATE:{
_instance->PosixMQTTAdapter_MQTTAdapterThing_State = POSIXMQTTADAPTER_MQTTADAPTERTHING_START_STATE;
f_PosixMQTTAdapter_init_properties(_instance);
PosixMQTTAdapter_MQTTAdapterThing_OnEntry(_instance->PosixMQTTAdapter_MQTTAdapterThing_State, _instance);
break;
}
case POSIXMQTTADAPTER_MQTTADAPTERTHING_START_STATE:{
break;
}
default: break;
}
}

// On Exit Actions:
void PosixMQTTAdapter_MQTTAdapterThing_OnExit(int state, struct PosixMQTTAdapter_Instance *_instance) {
switch(state) {
case POSIXMQTTADAPTER_MQTTADAPTERTHING_STATE:{
PosixMQTTAdapter_MQTTAdapterThing_OnExit(_instance->PosixMQTTAdapter_MQTTAdapterThing_State, _instance);
break;}
case POSIXMQTTADAPTER_MQTTADAPTERTHING_START_STATE:{
break;}
default: break;
}
}

// Event Handlers for incoming messages:
void PosixMQTTAdapter_handle_mqtt_mqtt_set_tls_certificates(struct PosixMQTTAdapter_Instance *_instance, char * cafile, char * capath, char * certfile, char * keyfile) {
if(!(_instance->active)) return;
//Region MQTTAdapterThing
uint8_t PosixMQTTAdapter_MQTTAdapterThing_State_event_consumed = 0;
//End Region MQTTAdapterThing
//End dsregion MQTTAdapterThing
//Session list: 
if (1) {
_instance->AbstractMQTTAdapter_cafile_var = cafile;
_instance->AbstractMQTTAdapter_capath_var = capath;
_instance->AbstractMQTTAdapter_certfile_var = certfile;
_instance->AbstractMQTTAdapter_keyfile_var = keyfile;
_instance->AbstractMQTTAdapter_enable_tls_certificates_var = 1;
PosixMQTTAdapter_MQTTAdapterThing_State_event_consumed = 1;
}
}
void PosixMQTTAdapter_handle_mqtt_mqtt_publish(struct PosixMQTTAdapter_Instance *_instance, char * topic, uint8_t * payload, uint32_t size) {
if(!(_instance->active)) return;
//Region MQTTAdapterThing
uint8_t PosixMQTTAdapter_MQTTAdapterThing_State_event_consumed = 0;
//End Region MQTTAdapterThing
//End dsregion MQTTAdapterThing
//Session list: 
if (1) {
f_PosixMQTTAdapter_mqtt_publish(_instance, topic, payload, size, 0, 0);
PosixMQTTAdapter_MQTTAdapterThing_State_event_consumed = 1;
}
}
void PosixMQTTAdapter_handle_mqtt_mqtt_set_credentials(struct PosixMQTTAdapter_Instance *_instance, char * usr, char * pwd) {
if(!(_instance->active)) return;
//Region MQTTAdapterThing
uint8_t PosixMQTTAdapter_MQTTAdapterThing_State_event_consumed = 0;
//End Region MQTTAdapterThing
//End dsregion MQTTAdapterThing
//Session list: 
if (1) {
_instance->AbstractMQTTAdapter_username_var = usr;
_instance->AbstractMQTTAdapter_password_var = pwd;
_instance->AbstractMQTTAdapter_enable_user_credentials_var = 1;
PosixMQTTAdapter_MQTTAdapterThing_State_event_consumed = 1;
}
}
void PosixMQTTAdapter_handle_mqtt_mqtt_subscribe(struct PosixMQTTAdapter_Instance *_instance, char * topic) {
if(!(_instance->active)) return;
//Region MQTTAdapterThing
uint8_t PosixMQTTAdapter_MQTTAdapterThing_State_event_consumed = 0;
//End Region MQTTAdapterThing
//End dsregion MQTTAdapterThing
//Session list: 
if (1) {
f_PosixMQTTAdapter_mqtt_subscribe(_instance, topic);
PosixMQTTAdapter_MQTTAdapterThing_State_event_consumed = 1;
}
}
void PosixMQTTAdapter_handle_mqtt_mqtt_set_prefix(struct PosixMQTTAdapter_Instance *_instance, char * prefix) {
if(!(_instance->active)) return;
//Region MQTTAdapterThing
uint8_t PosixMQTTAdapter_MQTTAdapterThing_State_event_consumed = 0;
//End Region MQTTAdapterThing
//End dsregion MQTTAdapterThing
//Session list: 
if (1) {
f_PosixMQTTAdapter_setTopicPrefix(_instance, prefix);
PosixMQTTAdapter_MQTTAdapterThing_State_event_consumed = 1;
}
}
void PosixMQTTAdapter_handle_mqtt_mqtt_connect(struct PosixMQTTAdapter_Instance *_instance, char * client_id, char * host, uint16_t portno, bool tls) {
if(!(_instance->active)) return;
//Region MQTTAdapterThing
uint8_t PosixMQTTAdapter_MQTTAdapterThing_State_event_consumed = 0;
//End Region MQTTAdapterThing
//End dsregion MQTTAdapterThing
//Session list: 
if (1) {
_instance->AbstractMQTTAdapter_client_id_var = client_id;
_instance->AbstractMQTTAdapter_broker_host_var = host;
_instance->AbstractMQTTAdapter_broker_port_var = portno;
_instance->AbstractMQTTAdapter_enable_tls_var = tls;
f_PosixMQTTAdapter_mqtt_connect(_instance);
PosixMQTTAdapter_MQTTAdapterThing_State_event_consumed = 1;
}
}
void PosixMQTTAdapter_handle_mqtt_mqtt_publish_with_qos(struct PosixMQTTAdapter_Instance *_instance, char * topic, uint8_t * payload, uint32_t size, uint8_t qos, bool retain) {
if(!(_instance->active)) return;
//Region MQTTAdapterThing
uint8_t PosixMQTTAdapter_MQTTAdapterThing_State_event_consumed = 0;
//End Region MQTTAdapterThing
//End dsregion MQTTAdapterThing
//Session list: 
if (1) {
f_PosixMQTTAdapter_mqtt_publish(_instance, topic, payload, size, qos, retain);
PosixMQTTAdapter_MQTTAdapterThing_State_event_consumed = 1;
}
}

// Observers for outgoing messages:
void (*external_PosixMQTTAdapter_send_mqtt_mqtt_connected_listener)(struct PosixMQTTAdapter_Instance *)= 0x0;
void (*PosixMQTTAdapter_send_mqtt_mqtt_connected_listener)(struct PosixMQTTAdapter_Instance *)= 0x0;
void register_external_PosixMQTTAdapter_send_mqtt_mqtt_connected_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *)){
external_PosixMQTTAdapter_send_mqtt_mqtt_connected_listener = _listener;
}
void register_PosixMQTTAdapter_send_mqtt_mqtt_connected_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *)){
PosixMQTTAdapter_send_mqtt_mqtt_connected_listener = _listener;
}
void PosixMQTTAdapter_send_mqtt_mqtt_connected(struct PosixMQTTAdapter_Instance *_instance){
if (PosixMQTTAdapter_send_mqtt_mqtt_connected_listener != 0x0) PosixMQTTAdapter_send_mqtt_mqtt_connected_listener(_instance);
if (external_PosixMQTTAdapter_send_mqtt_mqtt_connected_listener != 0x0) external_PosixMQTTAdapter_send_mqtt_mqtt_connected_listener(_instance);
;
}
void (*external_PosixMQTTAdapter_send_mqtt_mqtt_disconnected_listener)(struct PosixMQTTAdapter_Instance *)= 0x0;
void (*PosixMQTTAdapter_send_mqtt_mqtt_disconnected_listener)(struct PosixMQTTAdapter_Instance *)= 0x0;
void register_external_PosixMQTTAdapter_send_mqtt_mqtt_disconnected_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *)){
external_PosixMQTTAdapter_send_mqtt_mqtt_disconnected_listener = _listener;
}
void register_PosixMQTTAdapter_send_mqtt_mqtt_disconnected_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *)){
PosixMQTTAdapter_send_mqtt_mqtt_disconnected_listener = _listener;
}
void PosixMQTTAdapter_send_mqtt_mqtt_disconnected(struct PosixMQTTAdapter_Instance *_instance){
if (PosixMQTTAdapter_send_mqtt_mqtt_disconnected_listener != 0x0) PosixMQTTAdapter_send_mqtt_mqtt_disconnected_listener(_instance);
if (external_PosixMQTTAdapter_send_mqtt_mqtt_disconnected_listener != 0x0) external_PosixMQTTAdapter_send_mqtt_mqtt_disconnected_listener(_instance);
;
}
void (*external_PosixMQTTAdapter_send_mqtt_mqtt_message_listener)(struct PosixMQTTAdapter_Instance *, char *, uint8_t *, uint32_t)= 0x0;
void (*PosixMQTTAdapter_send_mqtt_mqtt_message_listener)(struct PosixMQTTAdapter_Instance *, char *, uint8_t *, uint32_t)= 0x0;
void register_external_PosixMQTTAdapter_send_mqtt_mqtt_message_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *, char *, uint8_t *, uint32_t)){
external_PosixMQTTAdapter_send_mqtt_mqtt_message_listener = _listener;
}
void register_PosixMQTTAdapter_send_mqtt_mqtt_message_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *, char *, uint8_t *, uint32_t)){
PosixMQTTAdapter_send_mqtt_mqtt_message_listener = _listener;
}
void PosixMQTTAdapter_send_mqtt_mqtt_message(struct PosixMQTTAdapter_Instance *_instance, char * topic, uint8_t * payload, uint32_t size){
if (PosixMQTTAdapter_send_mqtt_mqtt_message_listener != 0x0) PosixMQTTAdapter_send_mqtt_mqtt_message_listener(_instance, topic, payload, size);
if (external_PosixMQTTAdapter_send_mqtt_mqtt_message_listener != 0x0) external_PosixMQTTAdapter_send_mqtt_mqtt_message_listener(_instance, topic, payload, size);
;
}
void (*external_PosixMQTTAdapter_send_mqtt_mqtt_error_listener)(struct PosixMQTTAdapter_Instance *)= 0x0;
void (*PosixMQTTAdapter_send_mqtt_mqtt_error_listener)(struct PosixMQTTAdapter_Instance *)= 0x0;
void register_external_PosixMQTTAdapter_send_mqtt_mqtt_error_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *)){
external_PosixMQTTAdapter_send_mqtt_mqtt_error_listener = _listener;
}
void register_PosixMQTTAdapter_send_mqtt_mqtt_error_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *)){
PosixMQTTAdapter_send_mqtt_mqtt_error_listener = _listener;
}
void PosixMQTTAdapter_send_mqtt_mqtt_error(struct PosixMQTTAdapter_Instance *_instance){
if (PosixMQTTAdapter_send_mqtt_mqtt_error_listener != 0x0) PosixMQTTAdapter_send_mqtt_mqtt_error_listener(_instance);
if (external_PosixMQTTAdapter_send_mqtt_mqtt_error_listener != 0x0) external_PosixMQTTAdapter_send_mqtt_mqtt_error_listener(_instance);
;
}
void (*external_PosixMQTTAdapter_send_mqtt_mqtt_message_published_listener)(struct PosixMQTTAdapter_Instance *)= 0x0;
void (*PosixMQTTAdapter_send_mqtt_mqtt_message_published_listener)(struct PosixMQTTAdapter_Instance *)= 0x0;
void register_external_PosixMQTTAdapter_send_mqtt_mqtt_message_published_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *)){
external_PosixMQTTAdapter_send_mqtt_mqtt_message_published_listener = _listener;
}
void register_PosixMQTTAdapter_send_mqtt_mqtt_message_published_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *)){
PosixMQTTAdapter_send_mqtt_mqtt_message_published_listener = _listener;
}
void PosixMQTTAdapter_send_mqtt_mqtt_message_published(struct PosixMQTTAdapter_Instance *_instance){
if (PosixMQTTAdapter_send_mqtt_mqtt_message_published_listener != 0x0) PosixMQTTAdapter_send_mqtt_mqtt_message_published_listener(_instance);
if (external_PosixMQTTAdapter_send_mqtt_mqtt_message_published_listener != 0x0) external_PosixMQTTAdapter_send_mqtt_mqtt_message_published_listener(_instance);
;
}
void (*external_PosixMQTTAdapter_send_mqtt_mqtt_topic_subscribed_listener)(struct PosixMQTTAdapter_Instance *)= 0x0;
void (*PosixMQTTAdapter_send_mqtt_mqtt_topic_subscribed_listener)(struct PosixMQTTAdapter_Instance *)= 0x0;
void register_external_PosixMQTTAdapter_send_mqtt_mqtt_topic_subscribed_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *)){
external_PosixMQTTAdapter_send_mqtt_mqtt_topic_subscribed_listener = _listener;
}
void register_PosixMQTTAdapter_send_mqtt_mqtt_topic_subscribed_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *)){
PosixMQTTAdapter_send_mqtt_mqtt_topic_subscribed_listener = _listener;
}
void PosixMQTTAdapter_send_mqtt_mqtt_topic_subscribed(struct PosixMQTTAdapter_Instance *_instance){
if (PosixMQTTAdapter_send_mqtt_mqtt_topic_subscribed_listener != 0x0) PosixMQTTAdapter_send_mqtt_mqtt_topic_subscribed_listener(_instance);
if (external_PosixMQTTAdapter_send_mqtt_mqtt_topic_subscribed_listener != 0x0) external_PosixMQTTAdapter_send_mqtt_mqtt_topic_subscribed_listener(_instance);
;
}



