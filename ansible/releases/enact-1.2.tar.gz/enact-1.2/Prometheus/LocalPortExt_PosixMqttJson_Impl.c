/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *        Implementation for Thing LocalPortExt_PosixMqttJson_Impl
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#include "LocalPortExt_PosixMqttJson_Impl.h"

/*****************************************************************************
 * Implementation for type : LocalPortExt_PosixMqttJson_Impl
 *****************************************************************************/

// Declaration of prototypes:
//Prototypes: State Machine
void LocalPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_OnExit(int state, struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance);
//Prototypes: Message Sending
void LocalPortExt_PosixMqttJson_Impl_send_localext_ruuvi_measurement(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, uint32_t timestamp, char * blemac, uint32_t deviceID, uint8_t humidity, int32_t temperature, int32_t pressure, int16_t ax, int16_t ay, int16_t az, uint16_t battery, int8_t rssi);
void LocalPortExt_PosixMqttJson_Impl_send_localext_gps_status(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, uint32_t timestamp, uint8_t status, uint8_t satellites_visible, uint8_t satellites_used);
void LocalPortExt_PosixMqttJson_Impl_send_localext_gps_position(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, uint32_t timestamp, uint32_t gpstime, double latitude, double latitude_err, double longitude, double longitude_err, double speed, double speed_err, double track, double track_err);
void LocalPortExt_PosixMqttJson_Impl_send_localext_gps_altitude(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, uint32_t timestamp, double altitude, double altitude_err, double vspeed, double vspeed_err);
void LocalPortExt_PosixMqttJson_Impl_send_localext_adc_values(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, uint16_t a0, uint16_t a1, uint16_t a2, uint16_t a3);
void LocalPortExt_PosixMqttJson_Impl_send_localext_front_panel_hwmonitor(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, int8_t temp, uint16_t voltage);
void LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic, uint8_t * payload, uint32_t size);
void LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic);
//Prototypes: Function
void f_LocalPortExt_PosixMqttJson_Impl_subscribe_for_message(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, char * msg_name);
void f_LocalPortExt_PosixMqttJson_Impl_publish_message(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, char * msg_name, uint8_t * payload, uint32_t size);
void f_LocalPortExt_PosixMqttJson_Impl_posixmqtt_subscribe(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance);
bool f_LocalPortExt_PosixMqttJson_Impl_posixmqtt_parsemsg(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic, char * payload, uint32_t len);
// Declaration of functions:
// Definition of function subscribe_for_message
void f_LocalPortExt_PosixMqttJson_Impl_subscribe_for_message(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, char * msg_name) {
char topic[256];
snprintf(topic, 256, "%s/%s", _instance->LocalPortExt_PosixMqttJson_Impl_mqtt_topic_name_var, msg_name);
LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe(_instance, topic);
}
// Definition of function publish_message
void f_LocalPortExt_PosixMqttJson_Impl_publish_message(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, char * msg_name, uint8_t * payload, uint32_t size) {
char topic[256];
snprintf(topic, 256, "%s/%s", _instance->LocalPortExt_PosixMqttJson_Impl_mqtt_topic_name_var, msg_name);
LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish(_instance, topic, payload, size);
}
// Definition of function posixmqtt_subscribe
void f_LocalPortExt_PosixMqttJson_Impl_posixmqtt_subscribe(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance) {
f_LocalPortExt_PosixMqttJson_Impl_subscribe_for_message(_instance, "ruuvi_measurement");
f_LocalPortExt_PosixMqttJson_Impl_subscribe_for_message(_instance, "gps_status");
f_LocalPortExt_PosixMqttJson_Impl_subscribe_for_message(_instance, "gps_position");
f_LocalPortExt_PosixMqttJson_Impl_subscribe_for_message(_instance, "gps_altitude");
f_LocalPortExt_PosixMqttJson_Impl_subscribe_for_message(_instance, "adc_values");
f_LocalPortExt_PosixMqttJson_Impl_subscribe_for_message(_instance, "front_panel_hwmonitor");
}
// Definition of function posixmqtt_parsemsg
bool f_LocalPortExt_PosixMqttJson_Impl_posixmqtt_parsemsg(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic, char * payload, uint32_t len) {
jsmn_parser parser;
		jsmn_init(&parser);
		jsmntok_t tokens[32];
int16_t parse_result;
int mqtt_topic_name_length = strlen(_instance->LocalPortExt_PosixMqttJson_Impl_mqtt_topic_name_var);
if(!(strlen(topic) > mqtt_topic_name_length+1)) {
return 0;

}
if(strncmp(topic, _instance->LocalPortExt_PosixMqttJson_Impl_mqtt_topic_name_var, mqtt_topic_name_length) != 0) {
return 0;

}
if(!(topic[mqtt_topic_name_length] == '/')) {
return 0;

}
char * msg_name = &topic[mqtt_topic_name_length+1];
parse_result = jsmn_parse(&parser, payload, len, tokens, 32);;
if(strcmp(msg_name, "ruuvi_measurement") == 0) {
bool ___result = 0;
uint32_t timestamp;
bool _found_timestamp = 0;
char * blemac;
bool _found_blemac = 0;
uint32_t deviceID;
bool _found_deviceID = 0;
uint8_t humidity;
bool _found_humidity = 0;
int32_t temperature;
bool _found_temperature = 0;
int32_t pressure;
bool _found_pressure = 0;
int16_t ax;
bool _found_ax = 0;
int16_t ay;
bool _found_ay = 0;
int16_t az;
bool _found_az = 0;
uint16_t battery;
bool _found_battery = 0;
int8_t rssi;
bool _found_rssi = 0;
if(parse_result < 0) {
fprintf(stderr, "JSON ERROR: Parse error for ruuvi_measurement message payload\n");
return 0;

}
if(parse_result < 1 + 11) {
fprintf(stderr, "JSON ERROR: incomplete payload for ruuvi_measurement message\n");
return 0;

}
if(tokens[0].type != 1) {
fprintf(stderr, "JSON ERROR: wrong payload format for ruuvi_measurement message\n");
return 0;

}
uint16_t __parse_i = 1;
while(__parse_i < parse_result - 1) {
if(tokens[__parse_i].type != 3 || tokens[__parse_i].size != 1) {
fprintf(stderr, "JSON ERROR: unexpected token parsing parameters for ruuvi_measurement message\n");

}
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 9) && (strncmp(payload + tokens[__parse_i].start , "timestamp", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for timestamp in ruuvi_measurement message\n");

} else {
timestamp = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_timestamp = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 6) && (strncmp(payload + tokens[__parse_i].start , "blemac", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 3 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for blemac in ruuvi_measurement message\n");

} else {
blemac = malloc(tokens[__parse_i + 1].end - tokens[__parse_i + 1].start + 1);
if(blemac == NULL) {
fprintf(stderr, "FATAL: Unable to allocate memory while deserializing JSON message. Exiting.");
exit(-1);

}
strncpy ( blemac, payload + tokens[__parse_i + 1].start, tokens[__parse_i + 1].end - tokens[__parse_i + 1].start );
blemac[tokens[__parse_i + 1].end - tokens[__parse_i + 1].start] = 0;
_found_blemac = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 8) && (strncmp(payload + tokens[__parse_i].start , "deviceID", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for deviceID in ruuvi_measurement message\n");

} else {
deviceID = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_deviceID = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 8) && (strncmp(payload + tokens[__parse_i].start , "humidity", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for humidity in ruuvi_measurement message\n");

} else {
humidity = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_humidity = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 11) && (strncmp(payload + tokens[__parse_i].start , "temperature", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for temperature in ruuvi_measurement message\n");

} else {
temperature = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_temperature = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 8) && (strncmp(payload + tokens[__parse_i].start , "pressure", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for pressure in ruuvi_measurement message\n");

} else {
pressure = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_pressure = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 2) && (strncmp(payload + tokens[__parse_i].start , "ax", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for ax in ruuvi_measurement message\n");

} else {
ax = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_ax = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 2) && (strncmp(payload + tokens[__parse_i].start , "ay", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for ay in ruuvi_measurement message\n");

} else {
ay = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_ay = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 2) && (strncmp(payload + tokens[__parse_i].start , "az", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for az in ruuvi_measurement message\n");

} else {
az = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_az = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 7) && (strncmp(payload + tokens[__parse_i].start , "battery", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for battery in ruuvi_measurement message\n");

} else {
battery = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_battery = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 4) && (strncmp(payload + tokens[__parse_i].start , "rssi", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for rssi in ruuvi_measurement message\n");

} else {
rssi = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_rssi = 1;

}

} else {
fprintf(stdout, "JSON WARNING: got unknown parameters for ruuvi_measurement message\n");

}

}

}

}

}

}

}

}

}

}

}
__parse_i = __parse_i + 2;

}
if( !(_found_timestamp)) {
fprintf(stderr, "JSON ERROR: Missing timestamp parameter for message ruuvi_measurement\n");

}
if( !(_found_blemac)) {
fprintf(stderr, "JSON ERROR: Missing blemac parameter for message ruuvi_measurement\n");

}
if( !(_found_deviceID)) {
fprintf(stderr, "JSON ERROR: Missing deviceID parameter for message ruuvi_measurement\n");

}
if( !(_found_humidity)) {
fprintf(stderr, "JSON ERROR: Missing humidity parameter for message ruuvi_measurement\n");

}
if( !(_found_temperature)) {
fprintf(stderr, "JSON ERROR: Missing temperature parameter for message ruuvi_measurement\n");

}
if( !(_found_pressure)) {
fprintf(stderr, "JSON ERROR: Missing pressure parameter for message ruuvi_measurement\n");

}
if( !(_found_ax)) {
fprintf(stderr, "JSON ERROR: Missing ax parameter for message ruuvi_measurement\n");

}
if( !(_found_ay)) {
fprintf(stderr, "JSON ERROR: Missing ay parameter for message ruuvi_measurement\n");

}
if( !(_found_az)) {
fprintf(stderr, "JSON ERROR: Missing az parameter for message ruuvi_measurement\n");

}
if( !(_found_battery)) {
fprintf(stderr, "JSON ERROR: Missing battery parameter for message ruuvi_measurement\n");

}
if( !(_found_rssi)) {
fprintf(stderr, "JSON ERROR: Missing rssi parameter for message ruuvi_measurement\n");

}
if(_found_timestamp && _found_blemac && _found_deviceID && _found_humidity && _found_temperature && _found_pressure && _found_ax && _found_ay && _found_az && _found_battery && _found_rssi) {
LocalPortExt_PosixMqttJson_Impl_send_localext_ruuvi_measurement(_instance, timestamp, blemac, deviceID, humidity, temperature, pressure, ax, ay, az, battery, rssi);
___result = 1;

} else {
fprintf(stderr, "JSON ERROR: Dropping message ruuvi_measurement because of missing parameters\n");

}
if(blemac != NULL) {
free(blemac);


}
return ___result;

} else {
if(strcmp(msg_name, "gps_status") == 0) {
bool ___result = 0;
uint32_t timestamp;
bool _found_timestamp = 0;
uint8_t status;
bool _found_status = 0;
uint8_t satellites_visible;
bool _found_satellites_visible = 0;
uint8_t satellites_used;
bool _found_satellites_used = 0;
if(parse_result < 0) {
fprintf(stderr, "JSON ERROR: Parse error for gps_status message payload\n");
return 0;

}
if(parse_result < 1 + 4) {
fprintf(stderr, "JSON ERROR: incomplete payload for gps_status message\n");
return 0;

}
if(tokens[0].type != 1) {
fprintf(stderr, "JSON ERROR: wrong payload format for gps_status message\n");
return 0;

}
uint16_t __parse_i = 1;
while(__parse_i < parse_result - 1) {
if(tokens[__parse_i].type != 3 || tokens[__parse_i].size != 1) {
fprintf(stderr, "JSON ERROR: unexpected token parsing parameters for gps_status message\n");

}
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 9) && (strncmp(payload + tokens[__parse_i].start , "timestamp", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for timestamp in gps_status message\n");

} else {
timestamp = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_timestamp = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 6) && (strncmp(payload + tokens[__parse_i].start , "status", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for status in gps_status message\n");

} else {
status = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_status = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 18) && (strncmp(payload + tokens[__parse_i].start , "satellites_visible", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for satellites_visible in gps_status message\n");

} else {
satellites_visible = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_satellites_visible = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 15) && (strncmp(payload + tokens[__parse_i].start , "satellites_used", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for satellites_used in gps_status message\n");

} else {
satellites_used = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_satellites_used = 1;

}

} else {
fprintf(stdout, "JSON WARNING: got unknown parameters for gps_status message\n");

}

}

}

}
__parse_i = __parse_i + 2;

}
if( !(_found_timestamp)) {
fprintf(stderr, "JSON ERROR: Missing timestamp parameter for message gps_status\n");

}
if( !(_found_status)) {
fprintf(stderr, "JSON ERROR: Missing status parameter for message gps_status\n");

}
if( !(_found_satellites_visible)) {
fprintf(stderr, "JSON ERROR: Missing satellites_visible parameter for message gps_status\n");

}
if( !(_found_satellites_used)) {
fprintf(stderr, "JSON ERROR: Missing satellites_used parameter for message gps_status\n");

}
if(_found_timestamp && _found_status && _found_satellites_visible && _found_satellites_used) {
LocalPortExt_PosixMqttJson_Impl_send_localext_gps_status(_instance, timestamp, status, satellites_visible, satellites_used);
___result = 1;

} else {
fprintf(stderr, "JSON ERROR: Dropping message gps_status because of missing parameters\n");

}
return ___result;

} else {
if(strcmp(msg_name, "gps_position") == 0) {
bool ___result = 0;
uint32_t timestamp;
bool _found_timestamp = 0;
uint32_t gpstime;
bool _found_gpstime = 0;
double latitude;
bool _found_latitude = 0;
double latitude_err;
bool _found_latitude_err = 0;
double longitude;
bool _found_longitude = 0;
double longitude_err;
bool _found_longitude_err = 0;
double speed;
bool _found_speed = 0;
double speed_err;
bool _found_speed_err = 0;
double track;
bool _found_track = 0;
double track_err;
bool _found_track_err = 0;
if(parse_result < 0) {
fprintf(stderr, "JSON ERROR: Parse error for gps_position message payload\n");
return 0;

}
if(parse_result < 1 + 10) {
fprintf(stderr, "JSON ERROR: incomplete payload for gps_position message\n");
return 0;

}
if(tokens[0].type != 1) {
fprintf(stderr, "JSON ERROR: wrong payload format for gps_position message\n");
return 0;

}
uint16_t __parse_i = 1;
while(__parse_i < parse_result - 1) {
if(tokens[__parse_i].type != 3 || tokens[__parse_i].size != 1) {
fprintf(stderr, "JSON ERROR: unexpected token parsing parameters for gps_position message\n");

}
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 9) && (strncmp(payload + tokens[__parse_i].start , "timestamp", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for timestamp in gps_position message\n");

} else {
timestamp = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_timestamp = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 7) && (strncmp(payload + tokens[__parse_i].start , "gpstime", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for gpstime in gps_position message\n");

} else {
gpstime = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_gpstime = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 8) && (strncmp(payload + tokens[__parse_i].start , "latitude", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for latitude in gps_position message\n");

} else {
latitude = strtod(payload + tokens[__parse_i + 1].start, NULL);
_found_latitude = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 12) && (strncmp(payload + tokens[__parse_i].start , "latitude_err", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for latitude_err in gps_position message\n");

} else {
latitude_err = strtod(payload + tokens[__parse_i + 1].start, NULL);
_found_latitude_err = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 9) && (strncmp(payload + tokens[__parse_i].start , "longitude", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for longitude in gps_position message\n");

} else {
longitude = strtod(payload + tokens[__parse_i + 1].start, NULL);
_found_longitude = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 13) && (strncmp(payload + tokens[__parse_i].start , "longitude_err", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for longitude_err in gps_position message\n");

} else {
longitude_err = strtod(payload + tokens[__parse_i + 1].start, NULL);
_found_longitude_err = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 5) && (strncmp(payload + tokens[__parse_i].start , "speed", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for speed in gps_position message\n");

} else {
speed = strtod(payload + tokens[__parse_i + 1].start, NULL);
_found_speed = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 9) && (strncmp(payload + tokens[__parse_i].start , "speed_err", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for speed_err in gps_position message\n");

} else {
speed_err = strtod(payload + tokens[__parse_i + 1].start, NULL);
_found_speed_err = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 5) && (strncmp(payload + tokens[__parse_i].start , "track", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for track in gps_position message\n");

} else {
track = strtod(payload + tokens[__parse_i + 1].start, NULL);
_found_track = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 9) && (strncmp(payload + tokens[__parse_i].start , "track_err", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for track_err in gps_position message\n");

} else {
track_err = strtod(payload + tokens[__parse_i + 1].start, NULL);
_found_track_err = 1;

}

} else {
fprintf(stdout, "JSON WARNING: got unknown parameters for gps_position message\n");

}

}

}

}

}

}

}

}

}

}
__parse_i = __parse_i + 2;

}
if( !(_found_timestamp)) {
fprintf(stderr, "JSON ERROR: Missing timestamp parameter for message gps_position\n");

}
if( !(_found_gpstime)) {
fprintf(stderr, "JSON ERROR: Missing gpstime parameter for message gps_position\n");

}
if( !(_found_latitude)) {
fprintf(stderr, "JSON ERROR: Missing latitude parameter for message gps_position\n");

}
if( !(_found_latitude_err)) {
fprintf(stderr, "JSON ERROR: Missing latitude_err parameter for message gps_position\n");

}
if( !(_found_longitude)) {
fprintf(stderr, "JSON ERROR: Missing longitude parameter for message gps_position\n");

}
if( !(_found_longitude_err)) {
fprintf(stderr, "JSON ERROR: Missing longitude_err parameter for message gps_position\n");

}
if( !(_found_speed)) {
fprintf(stderr, "JSON ERROR: Missing speed parameter for message gps_position\n");

}
if( !(_found_speed_err)) {
fprintf(stderr, "JSON ERROR: Missing speed_err parameter for message gps_position\n");

}
if( !(_found_track)) {
fprintf(stderr, "JSON ERROR: Missing track parameter for message gps_position\n");

}
if( !(_found_track_err)) {
fprintf(stderr, "JSON ERROR: Missing track_err parameter for message gps_position\n");

}
if(_found_timestamp && _found_gpstime && _found_latitude && _found_latitude_err && _found_longitude && _found_longitude_err && _found_speed && _found_speed_err && _found_track && _found_track_err) {
LocalPortExt_PosixMqttJson_Impl_send_localext_gps_position(_instance, timestamp, gpstime, latitude, latitude_err, longitude, longitude_err, speed, speed_err, track, track_err);
___result = 1;

} else {
fprintf(stderr, "JSON ERROR: Dropping message gps_position because of missing parameters\n");

}
return ___result;

} else {
if(strcmp(msg_name, "gps_altitude") == 0) {
bool ___result = 0;
uint32_t timestamp;
bool _found_timestamp = 0;
double altitude;
bool _found_altitude = 0;
double altitude_err;
bool _found_altitude_err = 0;
double vspeed;
bool _found_vspeed = 0;
double vspeed_err;
bool _found_vspeed_err = 0;
if(parse_result < 0) {
fprintf(stderr, "JSON ERROR: Parse error for gps_altitude message payload\n");
return 0;

}
if(parse_result < 1 + 5) {
fprintf(stderr, "JSON ERROR: incomplete payload for gps_altitude message\n");
return 0;

}
if(tokens[0].type != 1) {
fprintf(stderr, "JSON ERROR: wrong payload format for gps_altitude message\n");
return 0;

}
uint16_t __parse_i = 1;
while(__parse_i < parse_result - 1) {
if(tokens[__parse_i].type != 3 || tokens[__parse_i].size != 1) {
fprintf(stderr, "JSON ERROR: unexpected token parsing parameters for gps_altitude message\n");

}
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 9) && (strncmp(payload + tokens[__parse_i].start , "timestamp", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for timestamp in gps_altitude message\n");

} else {
timestamp = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_timestamp = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 8) && (strncmp(payload + tokens[__parse_i].start , "altitude", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for altitude in gps_altitude message\n");

} else {
altitude = strtod(payload + tokens[__parse_i + 1].start, NULL);
_found_altitude = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 12) && (strncmp(payload + tokens[__parse_i].start , "altitude_err", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for altitude_err in gps_altitude message\n");

} else {
altitude_err = strtod(payload + tokens[__parse_i + 1].start, NULL);
_found_altitude_err = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 6) && (strncmp(payload + tokens[__parse_i].start , "vspeed", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for vspeed in gps_altitude message\n");

} else {
vspeed = strtod(payload + tokens[__parse_i + 1].start, NULL);
_found_vspeed = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 10) && (strncmp(payload + tokens[__parse_i].start , "vspeed_err", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for vspeed_err in gps_altitude message\n");

} else {
vspeed_err = strtod(payload + tokens[__parse_i + 1].start, NULL);
_found_vspeed_err = 1;

}

} else {
fprintf(stdout, "JSON WARNING: got unknown parameters for gps_altitude message\n");

}

}

}

}

}
__parse_i = __parse_i + 2;

}
if( !(_found_timestamp)) {
fprintf(stderr, "JSON ERROR: Missing timestamp parameter for message gps_altitude\n");

}
if( !(_found_altitude)) {
fprintf(stderr, "JSON ERROR: Missing altitude parameter for message gps_altitude\n");

}
if( !(_found_altitude_err)) {
fprintf(stderr, "JSON ERROR: Missing altitude_err parameter for message gps_altitude\n");

}
if( !(_found_vspeed)) {
fprintf(stderr, "JSON ERROR: Missing vspeed parameter for message gps_altitude\n");

}
if( !(_found_vspeed_err)) {
fprintf(stderr, "JSON ERROR: Missing vspeed_err parameter for message gps_altitude\n");

}
if(_found_timestamp && _found_altitude && _found_altitude_err && _found_vspeed && _found_vspeed_err) {
LocalPortExt_PosixMqttJson_Impl_send_localext_gps_altitude(_instance, timestamp, altitude, altitude_err, vspeed, vspeed_err);
___result = 1;

} else {
fprintf(stderr, "JSON ERROR: Dropping message gps_altitude because of missing parameters\n");

}
return ___result;

} else {
if(strcmp(msg_name, "adc_values") == 0) {
bool ___result = 0;
uint16_t a0;
bool _found_a0 = 0;
uint16_t a1;
bool _found_a1 = 0;
uint16_t a2;
bool _found_a2 = 0;
uint16_t a3;
bool _found_a3 = 0;
if(parse_result < 0) {
fprintf(stderr, "JSON ERROR: Parse error for adc_values message payload\n");
return 0;

}
if(parse_result < 1 + 4) {
fprintf(stderr, "JSON ERROR: incomplete payload for adc_values message\n");
return 0;

}
if(tokens[0].type != 1) {
fprintf(stderr, "JSON ERROR: wrong payload format for adc_values message\n");
return 0;

}
uint16_t __parse_i = 1;
while(__parse_i < parse_result - 1) {
if(tokens[__parse_i].type != 3 || tokens[__parse_i].size != 1) {
fprintf(stderr, "JSON ERROR: unexpected token parsing parameters for adc_values message\n");

}
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 2) && (strncmp(payload + tokens[__parse_i].start , "a0", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for a0 in adc_values message\n");

} else {
a0 = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_a0 = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 2) && (strncmp(payload + tokens[__parse_i].start , "a1", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for a1 in adc_values message\n");

} else {
a1 = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_a1 = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 2) && (strncmp(payload + tokens[__parse_i].start , "a2", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for a2 in adc_values message\n");

} else {
a2 = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_a2 = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 2) && (strncmp(payload + tokens[__parse_i].start , "a3", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for a3 in adc_values message\n");

} else {
a3 = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_a3 = 1;

}

} else {
fprintf(stdout, "JSON WARNING: got unknown parameters for adc_values message\n");

}

}

}

}
__parse_i = __parse_i + 2;

}
if( !(_found_a0)) {
fprintf(stderr, "JSON ERROR: Missing a0 parameter for message adc_values\n");

}
if( !(_found_a1)) {
fprintf(stderr, "JSON ERROR: Missing a1 parameter for message adc_values\n");

}
if( !(_found_a2)) {
fprintf(stderr, "JSON ERROR: Missing a2 parameter for message adc_values\n");

}
if( !(_found_a3)) {
fprintf(stderr, "JSON ERROR: Missing a3 parameter for message adc_values\n");

}
if(_found_a0 && _found_a1 && _found_a2 && _found_a3) {
LocalPortExt_PosixMqttJson_Impl_send_localext_adc_values(_instance, a0, a1, a2, a3);
___result = 1;

} else {
fprintf(stderr, "JSON ERROR: Dropping message adc_values because of missing parameters\n");

}
return ___result;

} else {
if(strcmp(msg_name, "front_panel_hwmonitor") == 0) {
bool ___result = 0;
int8_t temp;
bool _found_temp = 0;
uint16_t voltage;
bool _found_voltage = 0;
if(parse_result < 0) {
fprintf(stderr, "JSON ERROR: Parse error for front_panel_hwmonitor message payload\n");
return 0;

}
if(parse_result < 1 + 2) {
fprintf(stderr, "JSON ERROR: incomplete payload for front_panel_hwmonitor message\n");
return 0;

}
if(tokens[0].type != 1) {
fprintf(stderr, "JSON ERROR: wrong payload format for front_panel_hwmonitor message\n");
return 0;

}
uint16_t __parse_i = 1;
while(__parse_i < parse_result - 1) {
if(tokens[__parse_i].type != 3 || tokens[__parse_i].size != 1) {
fprintf(stderr, "JSON ERROR: unexpected token parsing parameters for front_panel_hwmonitor message\n");

}
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 4) && (strncmp(payload + tokens[__parse_i].start , "temp", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for temp in front_panel_hwmonitor message\n");

} else {
temp = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_temp = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 7) && (strncmp(payload + tokens[__parse_i].start , "voltage", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for voltage in front_panel_hwmonitor message\n");

} else {
voltage = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_voltage = 1;

}

} else {
fprintf(stdout, "JSON WARNING: got unknown parameters for front_panel_hwmonitor message\n");

}

}
__parse_i = __parse_i + 2;

}
if( !(_found_temp)) {
fprintf(stderr, "JSON ERROR: Missing temp parameter for message front_panel_hwmonitor\n");

}
if( !(_found_voltage)) {
fprintf(stderr, "JSON ERROR: Missing voltage parameter for message front_panel_hwmonitor\n");

}
if(_found_temp && _found_voltage) {
LocalPortExt_PosixMqttJson_Impl_send_localext_front_panel_hwmonitor(_instance, temp, voltage);
___result = 1;

} else {
fprintf(stderr, "JSON ERROR: Dropping message front_panel_hwmonitor because of missing parameters\n");

}
return ___result;

} else {

}

}

}

}

}

}
return 0;
}

// Sessions functionss:


// On Entry Actions:
void LocalPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_OnEntry(int state, struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance) {
switch(state) {
case LOCALPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_STATE:{
_instance->LocalPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State = LOCALPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_RUNNING_STATE;
LocalPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_OnEntry(_instance->LocalPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State, _instance);
break;
}
case LOCALPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_RUNNING_STATE:{
break;
}
default: break;
}
}

// On Exit Actions:
void LocalPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_OnExit(int state, struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance) {
switch(state) {
case LOCALPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_STATE:{
LocalPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_OnExit(_instance->LocalPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State, _instance);
break;}
case LOCALPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_RUNNING_STATE:{
break;}
default: break;
}
}

// Event Handlers for incoming messages:
void LocalPortExt_PosixMqttJson_Impl_handle_posixmqtt_mqtt_connected(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance) {
if(!(_instance->active)) return;
//Region PosixMQTTJSonSC
uint8_t LocalPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 0;
//End Region PosixMQTTJSonSC
//End dsregion PosixMQTTJSonSC
//Session list: 
if (1) {
f_LocalPortExt_PosixMqttJson_Impl_posixmqtt_subscribe(_instance);
LocalPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 1;
}
}
void LocalPortExt_PosixMqttJson_Impl_handle_posixmqtt_mqtt_message(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic, uint8_t * payload, uint32_t size) {
if(!(_instance->active)) return;
//Region PosixMQTTJSonSC
uint8_t LocalPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 0;
//End Region PosixMQTTJSonSC
//End dsregion PosixMQTTJSonSC
//Session list: 
if (1) {
f_LocalPortExt_PosixMqttJson_Impl_posixmqtt_parsemsg(_instance, topic, payload, size);
LocalPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 1;
}
}

// Observers for outgoing messages:
void (*external_LocalPortExt_PosixMqttJson_Impl_send_localext_ruuvi_measurement_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, char *, uint32_t, uint8_t, int32_t, int32_t, int16_t, int16_t, int16_t, uint16_t, int8_t)= 0x0;
void (*LocalPortExt_PosixMqttJson_Impl_send_localext_ruuvi_measurement_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, char *, uint32_t, uint8_t, int32_t, int32_t, int16_t, int16_t, int16_t, uint16_t, int8_t)= 0x0;
void register_external_LocalPortExt_PosixMqttJson_Impl_send_localext_ruuvi_measurement_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, char *, uint32_t, uint8_t, int32_t, int32_t, int16_t, int16_t, int16_t, uint16_t, int8_t)){
external_LocalPortExt_PosixMqttJson_Impl_send_localext_ruuvi_measurement_listener = _listener;
}
void register_LocalPortExt_PosixMqttJson_Impl_send_localext_ruuvi_measurement_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, char *, uint32_t, uint8_t, int32_t, int32_t, int16_t, int16_t, int16_t, uint16_t, int8_t)){
LocalPortExt_PosixMqttJson_Impl_send_localext_ruuvi_measurement_listener = _listener;
}
void LocalPortExt_PosixMqttJson_Impl_send_localext_ruuvi_measurement(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, uint32_t timestamp, char * blemac, uint32_t deviceID, uint8_t humidity, int32_t temperature, int32_t pressure, int16_t ax, int16_t ay, int16_t az, uint16_t battery, int8_t rssi){
if (LocalPortExt_PosixMqttJson_Impl_send_localext_ruuvi_measurement_listener != 0x0) LocalPortExt_PosixMqttJson_Impl_send_localext_ruuvi_measurement_listener(_instance, timestamp, blemac, deviceID, humidity, temperature, pressure, ax, ay, az, battery, rssi);
if (external_LocalPortExt_PosixMqttJson_Impl_send_localext_ruuvi_measurement_listener != 0x0) external_LocalPortExt_PosixMqttJson_Impl_send_localext_ruuvi_measurement_listener(_instance, timestamp, blemac, deviceID, humidity, temperature, pressure, ax, ay, az, battery, rssi);
;
}
void (*external_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_status_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, uint8_t, uint8_t, uint8_t)= 0x0;
void (*LocalPortExt_PosixMqttJson_Impl_send_localext_gps_status_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, uint8_t, uint8_t, uint8_t)= 0x0;
void register_external_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_status_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, uint8_t, uint8_t, uint8_t)){
external_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_status_listener = _listener;
}
void register_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_status_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, uint8_t, uint8_t, uint8_t)){
LocalPortExt_PosixMqttJson_Impl_send_localext_gps_status_listener = _listener;
}
void LocalPortExt_PosixMqttJson_Impl_send_localext_gps_status(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, uint32_t timestamp, uint8_t status, uint8_t satellites_visible, uint8_t satellites_used){
if (LocalPortExt_PosixMqttJson_Impl_send_localext_gps_status_listener != 0x0) LocalPortExt_PosixMqttJson_Impl_send_localext_gps_status_listener(_instance, timestamp, status, satellites_visible, satellites_used);
if (external_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_status_listener != 0x0) external_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_status_listener(_instance, timestamp, status, satellites_visible, satellites_used);
;
}
void (*external_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_position_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, uint32_t, double, double, double, double, double, double, double, double)= 0x0;
void (*LocalPortExt_PosixMqttJson_Impl_send_localext_gps_position_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, uint32_t, double, double, double, double, double, double, double, double)= 0x0;
void register_external_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_position_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, uint32_t, double, double, double, double, double, double, double, double)){
external_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_position_listener = _listener;
}
void register_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_position_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, uint32_t, double, double, double, double, double, double, double, double)){
LocalPortExt_PosixMqttJson_Impl_send_localext_gps_position_listener = _listener;
}
void LocalPortExt_PosixMqttJson_Impl_send_localext_gps_position(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, uint32_t timestamp, uint32_t gpstime, double latitude, double latitude_err, double longitude, double longitude_err, double speed, double speed_err, double track, double track_err){
if (LocalPortExt_PosixMqttJson_Impl_send_localext_gps_position_listener != 0x0) LocalPortExt_PosixMqttJson_Impl_send_localext_gps_position_listener(_instance, timestamp, gpstime, latitude, latitude_err, longitude, longitude_err, speed, speed_err, track, track_err);
if (external_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_position_listener != 0x0) external_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_position_listener(_instance, timestamp, gpstime, latitude, latitude_err, longitude, longitude_err, speed, speed_err, track, track_err);
;
}
void (*external_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_altitude_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, double, double, double, double)= 0x0;
void (*LocalPortExt_PosixMqttJson_Impl_send_localext_gps_altitude_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, double, double, double, double)= 0x0;
void register_external_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_altitude_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, double, double, double, double)){
external_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_altitude_listener = _listener;
}
void register_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_altitude_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, double, double, double, double)){
LocalPortExt_PosixMqttJson_Impl_send_localext_gps_altitude_listener = _listener;
}
void LocalPortExt_PosixMqttJson_Impl_send_localext_gps_altitude(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, uint32_t timestamp, double altitude, double altitude_err, double vspeed, double vspeed_err){
if (LocalPortExt_PosixMqttJson_Impl_send_localext_gps_altitude_listener != 0x0) LocalPortExt_PosixMqttJson_Impl_send_localext_gps_altitude_listener(_instance, timestamp, altitude, altitude_err, vspeed, vspeed_err);
if (external_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_altitude_listener != 0x0) external_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_altitude_listener(_instance, timestamp, altitude, altitude_err, vspeed, vspeed_err);
;
}
void (*external_LocalPortExt_PosixMqttJson_Impl_send_localext_adc_values_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint16_t, uint16_t, uint16_t, uint16_t)= 0x0;
void (*LocalPortExt_PosixMqttJson_Impl_send_localext_adc_values_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint16_t, uint16_t, uint16_t, uint16_t)= 0x0;
void register_external_LocalPortExt_PosixMqttJson_Impl_send_localext_adc_values_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint16_t, uint16_t, uint16_t, uint16_t)){
external_LocalPortExt_PosixMqttJson_Impl_send_localext_adc_values_listener = _listener;
}
void register_LocalPortExt_PosixMqttJson_Impl_send_localext_adc_values_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint16_t, uint16_t, uint16_t, uint16_t)){
LocalPortExt_PosixMqttJson_Impl_send_localext_adc_values_listener = _listener;
}
void LocalPortExt_PosixMqttJson_Impl_send_localext_adc_values(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, uint16_t a0, uint16_t a1, uint16_t a2, uint16_t a3){
if (LocalPortExt_PosixMqttJson_Impl_send_localext_adc_values_listener != 0x0) LocalPortExt_PosixMqttJson_Impl_send_localext_adc_values_listener(_instance, a0, a1, a2, a3);
if (external_LocalPortExt_PosixMqttJson_Impl_send_localext_adc_values_listener != 0x0) external_LocalPortExt_PosixMqttJson_Impl_send_localext_adc_values_listener(_instance, a0, a1, a2, a3);
;
}
void (*external_LocalPortExt_PosixMqttJson_Impl_send_localext_front_panel_hwmonitor_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, int8_t, uint16_t)= 0x0;
void (*LocalPortExt_PosixMqttJson_Impl_send_localext_front_panel_hwmonitor_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, int8_t, uint16_t)= 0x0;
void register_external_LocalPortExt_PosixMqttJson_Impl_send_localext_front_panel_hwmonitor_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, int8_t, uint16_t)){
external_LocalPortExt_PosixMqttJson_Impl_send_localext_front_panel_hwmonitor_listener = _listener;
}
void register_LocalPortExt_PosixMqttJson_Impl_send_localext_front_panel_hwmonitor_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, int8_t, uint16_t)){
LocalPortExt_PosixMqttJson_Impl_send_localext_front_panel_hwmonitor_listener = _listener;
}
void LocalPortExt_PosixMqttJson_Impl_send_localext_front_panel_hwmonitor(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, int8_t temp, uint16_t voltage){
if (LocalPortExt_PosixMqttJson_Impl_send_localext_front_panel_hwmonitor_listener != 0x0) LocalPortExt_PosixMqttJson_Impl_send_localext_front_panel_hwmonitor_listener(_instance, temp, voltage);
if (external_LocalPortExt_PosixMqttJson_Impl_send_localext_front_panel_hwmonitor_listener != 0x0) external_LocalPortExt_PosixMqttJson_Impl_send_localext_front_panel_hwmonitor_listener(_instance, temp, voltage);
;
}
void (*external_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t)= 0x0;
void (*LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t)= 0x0;
void register_external_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t)){
external_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener = _listener;
}
void register_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t)){
LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener = _listener;
}
void LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic, uint8_t * payload, uint32_t size){
if (LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener != 0x0) LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(_instance, topic, payload, size);
if (external_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener != 0x0) external_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(_instance, topic, payload, size);
;
}
void (*external_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, char *)= 0x0;
void (*LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, char *)= 0x0;
void register_external_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, char *)){
external_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener = _listener;
}
void register_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, char *)){
LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener = _listener;
}
void LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic){
if (LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener != 0x0) LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(_instance, topic);
if (external_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener != 0x0) external_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(_instance, topic);
;
}



