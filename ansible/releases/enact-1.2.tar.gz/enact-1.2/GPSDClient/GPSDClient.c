/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *        Implementation for Thing GPSDClient
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#include "GPSDClient.h"

/*****************************************************************************
 * Implementation for type : GPSDClient
 *****************************************************************************/


// BEGIN: Code from the c_global annotation GPSDClient
int rc;
struct gps_data_t gpsdata;

// END: Code from the c_global annotation GPSDClient

// Declaration of prototypes:
//Prototypes: State Machine
void GPSDClient_OnExit(int state, struct GPSDClient_Instance *_instance);
//Prototypes: Message Sending
void GPSDClient_send_local_gps_status(struct GPSDClient_Instance *_instance, uint32_t timestamp, uint8_t status, uint8_t satellites_visible, uint8_t satellites_used);
void GPSDClient_send_local_gps_position(struct GPSDClient_Instance *_instance, uint32_t timestamp, uint32_t gpstime, double latitude, double latitude_err, double longitude, double longitude_err, double speed, double speed_err, double track, double track_err);
void GPSDClient_send_local_gps_altitude(struct GPSDClient_Instance *_instance, uint32_t timestamp, double altitude, double altitude_err, double vspeed, double vspeed_err);
void GPSDClient_send_timer_timer_start(struct GPSDClient_Instance *_instance, uint8_t id, uint16_t time);
void GPSDClient_send_timer_timer_cancel(struct GPSDClient_Instance *_instance, uint8_t id);
void GPSDClient_send_mqtt_mqtt_connect(struct GPSDClient_Instance *_instance, char * client_id, char * host, uint16_t portno, bool tls);
void GPSDClient_send_mqtt_mqtt_disconnect(struct GPSDClient_Instance *_instance);
void GPSDClient_send_mqtt_mqtt_set_credentials(struct GPSDClient_Instance *_instance, char * usr, char * pwd);
void GPSDClient_send_mqtt_mqtt_set_tls_certificates(struct GPSDClient_Instance *_instance, char * cafile, char * capath, char * certfile, char * keyfile);
void GPSDClient_send_mqtt_mqtt_set_prefix(struct GPSDClient_Instance *_instance, char * prefix);
//Prototypes: Function
uint64_t f_GPSDClient_getEpochTimeStamp(struct GPSDClient_Instance *_instance);
void f_GPSDClient_init_gps(struct GPSDClient_Instance *_instance);
void f_GPSDClient_forward_last_gps_packet(struct GPSDClient_Instance *_instance);
// Declaration of functions:
// Definition of function getEpochTimeStamp
uint64_t f_GPSDClient_getEpochTimeStamp(struct GPSDClient_Instance *_instance) {
time_t utc = time(NULL);
return utc;
}
// Definition of function init_gps
void f_GPSDClient_init_gps(struct GPSDClient_Instance *_instance) {
if ((rc = gps_open("localhost", "2947", &gpsdata)) == -1) {
    		printf("Error Openning GPS code: %d, reason: %s\n", rc, gps_errstr(rc));
    		exit(-1);
		}
		gps_stream(&gpsdata, WATCH_ENABLE | WATCH_JSON, NULL);
		
}
// Definition of function forward_last_gps_packet
void f_GPSDClient_forward_last_gps_packet(struct GPSDClient_Instance *_instance) {
uint64_t ts = f_GPSDClient_getEpochTimeStamp(_instance);
bool hasdata = 0;
while((rc = gps_read(&gpsdata)) != 0) {	// Get the last measurment in the buffer
			if (rc == -1){
	            printf("error occured reading gps data. code: %d, reason: %s\n", rc, gps_errstr(rc));
	            exit(-1);
	        }
hasdata = 1;

		}
if(hasdata) {
GPSDClient_send_local_gps_status(_instance, ts, gpsdata.status, gpsdata.satellites_visible, gpsdata.satellites_used);
if((gpsdata.status == STATUS_FIX) && (gpsdata.fix.mode == MODE_2D || gpsdata.fix.mode == MODE_3D)) {
uint32_t gpstime = (long)gpsdata.fix.time;
GPSDClient_send_local_gps_position(_instance, ts, gpstime, gpsdata.fix.latitude, gpsdata.fix.epy, gpsdata.fix.longitude, gpsdata.fix.epx, gpsdata.fix.speed, gpsdata.fix.eps, gpsdata.fix.track, gpsdata.fix.epd);
if(gpsdata.fix.mode == MODE_3D) {
GPSDClient_send_local_gps_altitude(_instance, ts, gpsdata.fix.altitude, gpsdata.fix.epv, gpsdata.fix.climb, gpsdata.fix.epc);

}

}

}
}

// Sessions functionss:


// On Entry Actions:
void GPSDClient_OnEntry(int state, struct GPSDClient_Instance *_instance) {
switch(state) {
case GPSDCLIENT_STATE:{
_instance->GPSDClient_State = GPSDCLIENT_NULL_WAIT_STATE;
GPSDClient_send_mqtt_mqtt_connect(_instance, _instance->GPSDClient_client_id_var, _instance->GPSDClient_broker_host_var, _instance->GPSDClient_broker_port_var, 0);
f_GPSDClient_init_gps(_instance);
GPSDClient_OnEntry(_instance->GPSDClient_State, _instance);
break;
}
case GPSDCLIENT_NULL_READGPS_STATE:{
f_GPSDClient_forward_last_gps_packet(_instance);
break;
}
case GPSDCLIENT_NULL_WAIT_STATE:{
GPSDClient_send_timer_timer_start(_instance, _instance->GPSDClient_timer_id_var, 10000);
break;
}
default: break;
}
}

// On Exit Actions:
void GPSDClient_OnExit(int state, struct GPSDClient_Instance *_instance) {
switch(state) {
case GPSDCLIENT_STATE:{
GPSDClient_OnExit(_instance->GPSDClient_State, _instance);
break;}
case GPSDCLIENT_NULL_READGPS_STATE:{
break;}
case GPSDCLIENT_NULL_WAIT_STATE:{
break;}
default: break;
}
}

// Event Handlers for incoming messages:
void GPSDClient_handle_timer_timer_timeout(struct GPSDClient_Instance *_instance, uint8_t id) {
if(!(_instance->active)) return;
//Region null
uint8_t GPSDClient_State_event_consumed = 0;
if (_instance->GPSDClient_State == GPSDCLIENT_NULL_WAIT_STATE) {
if (GPSDClient_State_event_consumed == 0 && id == _instance->GPSDClient_timer_id_var) {
GPSDClient_OnExit(GPSDCLIENT_NULL_WAIT_STATE, _instance);
_instance->GPSDClient_State = GPSDCLIENT_NULL_READGPS_STATE;
GPSDClient_OnEntry(GPSDCLIENT_NULL_READGPS_STATE, _instance);
GPSDClient_State_event_consumed = 1;
}
}
//End Region null
//End dsregion null
//Session list: 
}
int GPSDClient_handle_empty_event(struct GPSDClient_Instance *_instance) {
 uint8_t empty_event_consumed = 0;
if(!(_instance->active)) return 0;
//Region null
if (_instance->GPSDClient_State == GPSDCLIENT_NULL_READGPS_STATE) {
if (1) {
GPSDClient_OnExit(GPSDCLIENT_NULL_READGPS_STATE, _instance);
_instance->GPSDClient_State = GPSDCLIENT_NULL_WAIT_STATE;
GPSDClient_OnEntry(GPSDCLIENT_NULL_WAIT_STATE, _instance);
return 1;
}
}
//begin dispatchEmptyToSession
//end dispatchEmptyToSession
return empty_event_consumed;
}

// Observers for outgoing messages:
void (*external_GPSDClient_send_local_gps_status_listener)(struct GPSDClient_Instance *, uint32_t, uint8_t, uint8_t, uint8_t)= 0x0;
void (*GPSDClient_send_local_gps_status_listener)(struct GPSDClient_Instance *, uint32_t, uint8_t, uint8_t, uint8_t)= 0x0;
void register_external_GPSDClient_send_local_gps_status_listener(void (*_listener)(struct GPSDClient_Instance *, uint32_t, uint8_t, uint8_t, uint8_t)){
external_GPSDClient_send_local_gps_status_listener = _listener;
}
void register_GPSDClient_send_local_gps_status_listener(void (*_listener)(struct GPSDClient_Instance *, uint32_t, uint8_t, uint8_t, uint8_t)){
GPSDClient_send_local_gps_status_listener = _listener;
}
void GPSDClient_send_local_gps_status(struct GPSDClient_Instance *_instance, uint32_t timestamp, uint8_t status, uint8_t satellites_visible, uint8_t satellites_used){
if (GPSDClient_send_local_gps_status_listener != 0x0) GPSDClient_send_local_gps_status_listener(_instance, timestamp, status, satellites_visible, satellites_used);
if (external_GPSDClient_send_local_gps_status_listener != 0x0) external_GPSDClient_send_local_gps_status_listener(_instance, timestamp, status, satellites_visible, satellites_used);
;
}
void (*external_GPSDClient_send_local_gps_position_listener)(struct GPSDClient_Instance *, uint32_t, uint32_t, double, double, double, double, double, double, double, double)= 0x0;
void (*GPSDClient_send_local_gps_position_listener)(struct GPSDClient_Instance *, uint32_t, uint32_t, double, double, double, double, double, double, double, double)= 0x0;
void register_external_GPSDClient_send_local_gps_position_listener(void (*_listener)(struct GPSDClient_Instance *, uint32_t, uint32_t, double, double, double, double, double, double, double, double)){
external_GPSDClient_send_local_gps_position_listener = _listener;
}
void register_GPSDClient_send_local_gps_position_listener(void (*_listener)(struct GPSDClient_Instance *, uint32_t, uint32_t, double, double, double, double, double, double, double, double)){
GPSDClient_send_local_gps_position_listener = _listener;
}
void GPSDClient_send_local_gps_position(struct GPSDClient_Instance *_instance, uint32_t timestamp, uint32_t gpstime, double latitude, double latitude_err, double longitude, double longitude_err, double speed, double speed_err, double track, double track_err){
if (GPSDClient_send_local_gps_position_listener != 0x0) GPSDClient_send_local_gps_position_listener(_instance, timestamp, gpstime, latitude, latitude_err, longitude, longitude_err, speed, speed_err, track, track_err);
if (external_GPSDClient_send_local_gps_position_listener != 0x0) external_GPSDClient_send_local_gps_position_listener(_instance, timestamp, gpstime, latitude, latitude_err, longitude, longitude_err, speed, speed_err, track, track_err);
;
}
void (*external_GPSDClient_send_local_gps_altitude_listener)(struct GPSDClient_Instance *, uint32_t, double, double, double, double)= 0x0;
void (*GPSDClient_send_local_gps_altitude_listener)(struct GPSDClient_Instance *, uint32_t, double, double, double, double)= 0x0;
void register_external_GPSDClient_send_local_gps_altitude_listener(void (*_listener)(struct GPSDClient_Instance *, uint32_t, double, double, double, double)){
external_GPSDClient_send_local_gps_altitude_listener = _listener;
}
void register_GPSDClient_send_local_gps_altitude_listener(void (*_listener)(struct GPSDClient_Instance *, uint32_t, double, double, double, double)){
GPSDClient_send_local_gps_altitude_listener = _listener;
}
void GPSDClient_send_local_gps_altitude(struct GPSDClient_Instance *_instance, uint32_t timestamp, double altitude, double altitude_err, double vspeed, double vspeed_err){
if (GPSDClient_send_local_gps_altitude_listener != 0x0) GPSDClient_send_local_gps_altitude_listener(_instance, timestamp, altitude, altitude_err, vspeed, vspeed_err);
if (external_GPSDClient_send_local_gps_altitude_listener != 0x0) external_GPSDClient_send_local_gps_altitude_listener(_instance, timestamp, altitude, altitude_err, vspeed, vspeed_err);
;
}
void (*external_GPSDClient_send_timer_timer_start_listener)(struct GPSDClient_Instance *, uint8_t, uint16_t)= 0x0;
void (*GPSDClient_send_timer_timer_start_listener)(struct GPSDClient_Instance *, uint8_t, uint16_t)= 0x0;
void register_external_GPSDClient_send_timer_timer_start_listener(void (*_listener)(struct GPSDClient_Instance *, uint8_t, uint16_t)){
external_GPSDClient_send_timer_timer_start_listener = _listener;
}
void register_GPSDClient_send_timer_timer_start_listener(void (*_listener)(struct GPSDClient_Instance *, uint8_t, uint16_t)){
GPSDClient_send_timer_timer_start_listener = _listener;
}
void GPSDClient_send_timer_timer_start(struct GPSDClient_Instance *_instance, uint8_t id, uint16_t time){
if (GPSDClient_send_timer_timer_start_listener != 0x0) GPSDClient_send_timer_timer_start_listener(_instance, id, time);
if (external_GPSDClient_send_timer_timer_start_listener != 0x0) external_GPSDClient_send_timer_timer_start_listener(_instance, id, time);
;
}
void (*external_GPSDClient_send_timer_timer_cancel_listener)(struct GPSDClient_Instance *, uint8_t)= 0x0;
void (*GPSDClient_send_timer_timer_cancel_listener)(struct GPSDClient_Instance *, uint8_t)= 0x0;
void register_external_GPSDClient_send_timer_timer_cancel_listener(void (*_listener)(struct GPSDClient_Instance *, uint8_t)){
external_GPSDClient_send_timer_timer_cancel_listener = _listener;
}
void register_GPSDClient_send_timer_timer_cancel_listener(void (*_listener)(struct GPSDClient_Instance *, uint8_t)){
GPSDClient_send_timer_timer_cancel_listener = _listener;
}
void GPSDClient_send_timer_timer_cancel(struct GPSDClient_Instance *_instance, uint8_t id){
if (GPSDClient_send_timer_timer_cancel_listener != 0x0) GPSDClient_send_timer_timer_cancel_listener(_instance, id);
if (external_GPSDClient_send_timer_timer_cancel_listener != 0x0) external_GPSDClient_send_timer_timer_cancel_listener(_instance, id);
;
}
void (*external_GPSDClient_send_mqtt_mqtt_connect_listener)(struct GPSDClient_Instance *, char *, char *, uint16_t, bool)= 0x0;
void (*GPSDClient_send_mqtt_mqtt_connect_listener)(struct GPSDClient_Instance *, char *, char *, uint16_t, bool)= 0x0;
void register_external_GPSDClient_send_mqtt_mqtt_connect_listener(void (*_listener)(struct GPSDClient_Instance *, char *, char *, uint16_t, bool)){
external_GPSDClient_send_mqtt_mqtt_connect_listener = _listener;
}
void register_GPSDClient_send_mqtt_mqtt_connect_listener(void (*_listener)(struct GPSDClient_Instance *, char *, char *, uint16_t, bool)){
GPSDClient_send_mqtt_mqtt_connect_listener = _listener;
}
void GPSDClient_send_mqtt_mqtt_connect(struct GPSDClient_Instance *_instance, char * client_id, char * host, uint16_t portno, bool tls){
if (GPSDClient_send_mqtt_mqtt_connect_listener != 0x0) GPSDClient_send_mqtt_mqtt_connect_listener(_instance, client_id, host, portno, tls);
if (external_GPSDClient_send_mqtt_mqtt_connect_listener != 0x0) external_GPSDClient_send_mqtt_mqtt_connect_listener(_instance, client_id, host, portno, tls);
;
}
void (*external_GPSDClient_send_mqtt_mqtt_disconnect_listener)(struct GPSDClient_Instance *)= 0x0;
void (*GPSDClient_send_mqtt_mqtt_disconnect_listener)(struct GPSDClient_Instance *)= 0x0;
void register_external_GPSDClient_send_mqtt_mqtt_disconnect_listener(void (*_listener)(struct GPSDClient_Instance *)){
external_GPSDClient_send_mqtt_mqtt_disconnect_listener = _listener;
}
void register_GPSDClient_send_mqtt_mqtt_disconnect_listener(void (*_listener)(struct GPSDClient_Instance *)){
GPSDClient_send_mqtt_mqtt_disconnect_listener = _listener;
}
void GPSDClient_send_mqtt_mqtt_disconnect(struct GPSDClient_Instance *_instance){
if (GPSDClient_send_mqtt_mqtt_disconnect_listener != 0x0) GPSDClient_send_mqtt_mqtt_disconnect_listener(_instance);
if (external_GPSDClient_send_mqtt_mqtt_disconnect_listener != 0x0) external_GPSDClient_send_mqtt_mqtt_disconnect_listener(_instance);
;
}
void (*external_GPSDClient_send_mqtt_mqtt_set_credentials_listener)(struct GPSDClient_Instance *, char *, char *)= 0x0;
void (*GPSDClient_send_mqtt_mqtt_set_credentials_listener)(struct GPSDClient_Instance *, char *, char *)= 0x0;
void register_external_GPSDClient_send_mqtt_mqtt_set_credentials_listener(void (*_listener)(struct GPSDClient_Instance *, char *, char *)){
external_GPSDClient_send_mqtt_mqtt_set_credentials_listener = _listener;
}
void register_GPSDClient_send_mqtt_mqtt_set_credentials_listener(void (*_listener)(struct GPSDClient_Instance *, char *, char *)){
GPSDClient_send_mqtt_mqtt_set_credentials_listener = _listener;
}
void GPSDClient_send_mqtt_mqtt_set_credentials(struct GPSDClient_Instance *_instance, char * usr, char * pwd){
if (GPSDClient_send_mqtt_mqtt_set_credentials_listener != 0x0) GPSDClient_send_mqtt_mqtt_set_credentials_listener(_instance, usr, pwd);
if (external_GPSDClient_send_mqtt_mqtt_set_credentials_listener != 0x0) external_GPSDClient_send_mqtt_mqtt_set_credentials_listener(_instance, usr, pwd);
;
}
void (*external_GPSDClient_send_mqtt_mqtt_set_tls_certificates_listener)(struct GPSDClient_Instance *, char *, char *, char *, char *)= 0x0;
void (*GPSDClient_send_mqtt_mqtt_set_tls_certificates_listener)(struct GPSDClient_Instance *, char *, char *, char *, char *)= 0x0;
void register_external_GPSDClient_send_mqtt_mqtt_set_tls_certificates_listener(void (*_listener)(struct GPSDClient_Instance *, char *, char *, char *, char *)){
external_GPSDClient_send_mqtt_mqtt_set_tls_certificates_listener = _listener;
}
void register_GPSDClient_send_mqtt_mqtt_set_tls_certificates_listener(void (*_listener)(struct GPSDClient_Instance *, char *, char *, char *, char *)){
GPSDClient_send_mqtt_mqtt_set_tls_certificates_listener = _listener;
}
void GPSDClient_send_mqtt_mqtt_set_tls_certificates(struct GPSDClient_Instance *_instance, char * cafile, char * capath, char * certfile, char * keyfile){
if (GPSDClient_send_mqtt_mqtt_set_tls_certificates_listener != 0x0) GPSDClient_send_mqtt_mqtt_set_tls_certificates_listener(_instance, cafile, capath, certfile, keyfile);
if (external_GPSDClient_send_mqtt_mqtt_set_tls_certificates_listener != 0x0) external_GPSDClient_send_mqtt_mqtt_set_tls_certificates_listener(_instance, cafile, capath, certfile, keyfile);
;
}
void (*external_GPSDClient_send_mqtt_mqtt_set_prefix_listener)(struct GPSDClient_Instance *, char *)= 0x0;
void (*GPSDClient_send_mqtt_mqtt_set_prefix_listener)(struct GPSDClient_Instance *, char *)= 0x0;
void register_external_GPSDClient_send_mqtt_mqtt_set_prefix_listener(void (*_listener)(struct GPSDClient_Instance *, char *)){
external_GPSDClient_send_mqtt_mqtt_set_prefix_listener = _listener;
}
void register_GPSDClient_send_mqtt_mqtt_set_prefix_listener(void (*_listener)(struct GPSDClient_Instance *, char *)){
GPSDClient_send_mqtt_mqtt_set_prefix_listener = _listener;
}
void GPSDClient_send_mqtt_mqtt_set_prefix(struct GPSDClient_Instance *_instance, char * prefix){
if (GPSDClient_send_mqtt_mqtt_set_prefix_listener != 0x0) GPSDClient_send_mqtt_mqtt_set_prefix_listener(_instance, prefix);
if (external_GPSDClient_send_mqtt_mqtt_set_prefix_listener != 0x0) external_GPSDClient_send_mqtt_mqtt_set_prefix_listener(_instance, prefix);
;
}



