/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *           Header for Thing GPSPortExt_PosixMqttJson_Impl
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#ifndef GPSPortExt_PosixMqttJson_Impl_H_
#define GPSPortExt_PosixMqttJson_Impl_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "thingml_typedefs.h"

/*****************************************************************************
 * Headers for type : GPSPortExt_PosixMqttJson_Impl
 *****************************************************************************/


// BEGIN: Code from the c_header annotation GPSPortExt_PosixMqttJson_Impl
#include "jsmn.h"
// END: Code from the c_header annotation GPSPortExt_PosixMqttJson_Impl

// Definition of the instance struct:
struct GPSPortExt_PosixMqttJson_Impl_Instance {

// Instances of different sessions
bool active;
// Variables for the ID of the ports of the instance
uint16_t id_localext;
uint16_t id_posixmqtt;
// Variables for the current instance state
int GPSPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State;
// Variables for the properties of the instance
char * GPSPortExt_PosixMqttJson_Impl_mqtt_topic_name_var;

};
// Declaration of prototypes outgoing messages :
void GPSPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_OnEntry(int state, struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance);
void GPSPortExt_PosixMqttJson_Impl_handle_localext_gps_altitude(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance, uint32_t timestamp, double altitude, double altitude_err, double vspeed, double vspeed_err);
void GPSPortExt_PosixMqttJson_Impl_handle_localext_gps_status(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance, uint32_t timestamp, uint8_t status, uint8_t satellites_visible, uint8_t satellites_used);
void GPSPortExt_PosixMqttJson_Impl_handle_localext_gps_position(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance, uint32_t timestamp, uint32_t gpstime, double latitude, double latitude_err, double longitude, double longitude_err, double speed, double speed_err, double track, double track_err);
void GPSPortExt_PosixMqttJson_Impl_handle_posixmqtt_mqtt_connected(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance);
void GPSPortExt_PosixMqttJson_Impl_handle_posixmqtt_mqtt_message(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic, uint8_t * payload, uint32_t size);
// Declaration of callbacks for incoming messages:
void register_GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(void (*_listener)(struct GPSPortExt_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t));
void register_external_GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(void (*_listener)(struct GPSPortExt_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t));
void register_GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(void (*_listener)(struct GPSPortExt_PosixMqttJson_Impl_Instance *, char *));
void register_external_GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(void (*_listener)(struct GPSPortExt_PosixMqttJson_Impl_Instance *, char *));

// Definition of the states:
#define GPSPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_RUNNING_STATE 0
#define GPSPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_STATE 1



#ifdef __cplusplus
}
#endif

#endif //GPSPortExt_PosixMqttJson_Impl_H_
