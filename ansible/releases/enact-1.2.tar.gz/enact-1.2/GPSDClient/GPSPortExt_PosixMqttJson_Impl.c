/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *        Implementation for Thing GPSPortExt_PosixMqttJson_Impl
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#include "GPSPortExt_PosixMqttJson_Impl.h"

/*****************************************************************************
 * Implementation for type : GPSPortExt_PosixMqttJson_Impl
 *****************************************************************************/

// Declaration of prototypes:
//Prototypes: State Machine
void GPSPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_OnExit(int state, struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance);
//Prototypes: Message Sending
void GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic, uint8_t * payload, uint32_t size);
void GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic);
//Prototypes: Function
void f_GPSPortExt_PosixMqttJson_Impl_subscribe_for_message(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance, char * msg_name);
void f_GPSPortExt_PosixMqttJson_Impl_publish_message(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance, char * msg_name, uint8_t * payload, uint32_t size);
void f_GPSPortExt_PosixMqttJson_Impl_posixmqtt_subscribe(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance);
bool f_GPSPortExt_PosixMqttJson_Impl_posixmqtt_parsemsg(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic, char * payload, uint32_t len);
// Declaration of functions:
// Definition of function subscribe_for_message
void f_GPSPortExt_PosixMqttJson_Impl_subscribe_for_message(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance, char * msg_name) {
char topic[256];
snprintf(topic, 256, "%s/%s", _instance->GPSPortExt_PosixMqttJson_Impl_mqtt_topic_name_var, msg_name);
GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe(_instance, topic);
}
// Definition of function publish_message
void f_GPSPortExt_PosixMqttJson_Impl_publish_message(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance, char * msg_name, uint8_t * payload, uint32_t size) {
char topic[256];
snprintf(topic, 256, "%s/%s", _instance->GPSPortExt_PosixMqttJson_Impl_mqtt_topic_name_var, msg_name);
GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish(_instance, topic, payload, size);
}
// Definition of function posixmqtt_subscribe
void f_GPSPortExt_PosixMqttJson_Impl_posixmqtt_subscribe(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance) {
}
// Definition of function posixmqtt_parsemsg
bool f_GPSPortExt_PosixMqttJson_Impl_posixmqtt_parsemsg(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic, char * payload, uint32_t len) {
jsmn_parser parser;
		jsmn_init(&parser);
		jsmntok_t tokens[32];
int16_t parse_result;
int mqtt_topic_name_length = strlen(_instance->GPSPortExt_PosixMqttJson_Impl_mqtt_topic_name_var);
if(!(strlen(topic) > mqtt_topic_name_length+1)) {
return 0;

}
if(strncmp(topic, _instance->GPSPortExt_PosixMqttJson_Impl_mqtt_topic_name_var, mqtt_topic_name_length) != 0) {
return 0;

}
if(!(topic[mqtt_topic_name_length] == '/')) {
return 0;

}
char * msg_name = &topic[mqtt_topic_name_length+1];
parse_result = jsmn_parse(&parser, payload, len, tokens, 32);;
return 0;
}

// Sessions functionss:


// On Entry Actions:
void GPSPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_OnEntry(int state, struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance) {
switch(state) {
case GPSPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_STATE:{
_instance->GPSPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State = GPSPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_RUNNING_STATE;
GPSPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_OnEntry(_instance->GPSPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State, _instance);
break;
}
case GPSPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_RUNNING_STATE:{
break;
}
default: break;
}
}

// On Exit Actions:
void GPSPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_OnExit(int state, struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance) {
switch(state) {
case GPSPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_STATE:{
GPSPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_OnExit(_instance->GPSPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State, _instance);
break;}
case GPSPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_RUNNING_STATE:{
break;}
default: break;
}
}

// Event Handlers for incoming messages:
void GPSPortExt_PosixMqttJson_Impl_handle_localext_gps_altitude(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance, uint32_t timestamp, double altitude, double altitude_err, double vspeed, double vspeed_err) {
if(!(_instance->active)) return;
//Region PosixMQTTJSonSC
uint8_t GPSPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 0;
//End Region PosixMQTTJSonSC
//End dsregion PosixMQTTJSonSC
//Session list: 
if (1) {
size_t maxlength = 172;
char * payload = malloc(maxlength);
if(payload == NULL) {
printf("FATAL: ThingML runtime failed to allocate memory serializing message to JSON. Exiting.");
exit(-1);
}
uint16_t index = 0;
int result = 0;
payload[index++] = '{';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "timestamp");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%u", timestamp);
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "altitude");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
if (isnan(altitude) || isinf(altitude)) {
	result = sprintf(&payload[index],"%.*s", 172-index, "null");
} else {
	result = sprintf(&payload[index], "%#.15g", altitude);
}
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "altitude_err");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
if (isnan(altitude_err) || isinf(altitude_err)) {
	result = sprintf(&payload[index],"%.*s", 172-index, "null");
} else {
	result = sprintf(&payload[index], "%#.15g", altitude_err);
}
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "vspeed");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
if (isnan(vspeed) || isinf(vspeed)) {
	result = sprintf(&payload[index],"%.*s", 172-index, "null");
} else {
	result = sprintf(&payload[index], "%#.15g", vspeed);
}
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "vspeed_err");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
if (isnan(vspeed_err) || isinf(vspeed_err)) {
	result = sprintf(&payload[index],"%.*s", 172-index, "null");
} else {
	result = sprintf(&payload[index], "%#.15g", vspeed_err);
}
if (result >= 0) { index += result; } else { return; }
payload[index++] = '}';
payload[index++] = 0;
f_GPSPortExt_PosixMqttJson_Impl_publish_message(_instance, "gps_altitude", payload, strlen(payload));
free(payload);
GPSPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 1;
}
}
void GPSPortExt_PosixMqttJson_Impl_handle_localext_gps_status(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance, uint32_t timestamp, uint8_t status, uint8_t satellites_visible, uint8_t satellites_used) {
if(!(_instance->active)) return;
//Region PosixMQTTJSonSC
uint8_t GPSPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 0;
//End Region PosixMQTTJSonSC
//End dsregion PosixMQTTJSonSC
//Session list: 
if (1) {
size_t maxlength = 97;
char * payload = malloc(maxlength);
if(payload == NULL) {
printf("FATAL: ThingML runtime failed to allocate memory serializing message to JSON. Exiting.");
exit(-1);
}
uint16_t index = 0;
int result = 0;
payload[index++] = '{';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "timestamp");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%u", timestamp);
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "status");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%u", status);
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "satellites_visible");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%u", satellites_visible);
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "satellites_used");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%u", satellites_used);
if (result >= 0) { index += result; } else { return; }
payload[index++] = '}';
payload[index++] = 0;
f_GPSPortExt_PosixMqttJson_Impl_publish_message(_instance, "gps_status", payload, strlen(payload));
free(payload);
GPSPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 1;
}
}
void GPSPortExt_PosixMqttJson_Impl_handle_localext_gps_position(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance, uint32_t timestamp, uint32_t gpstime, double latitude, double latitude_err, double longitude, double longitude_err, double speed, double speed_err, double track, double track_err) {
if(!(_instance->active)) return;
//Region PosixMQTTJSonSC
uint8_t GPSPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 0;
//End Region PosixMQTTJSonSC
//End dsregion PosixMQTTJSonSC
//Session list: 
if (1) {
size_t maxlength = 338;
char * payload = malloc(maxlength);
if(payload == NULL) {
printf("FATAL: ThingML runtime failed to allocate memory serializing message to JSON. Exiting.");
exit(-1);
}
uint16_t index = 0;
int result = 0;
payload[index++] = '{';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "timestamp");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%u", timestamp);
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "gpstime");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%u", gpstime);
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "latitude");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
if (isnan(latitude) || isinf(latitude)) {
	result = sprintf(&payload[index],"%.*s", 338-index, "null");
} else {
	result = sprintf(&payload[index], "%#.15g", latitude);
}
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "latitude_err");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
if (isnan(latitude_err) || isinf(latitude_err)) {
	result = sprintf(&payload[index],"%.*s", 338-index, "null");
} else {
	result = sprintf(&payload[index], "%#.15g", latitude_err);
}
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "longitude");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
if (isnan(longitude) || isinf(longitude)) {
	result = sprintf(&payload[index],"%.*s", 338-index, "null");
} else {
	result = sprintf(&payload[index], "%#.15g", longitude);
}
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "longitude_err");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
if (isnan(longitude_err) || isinf(longitude_err)) {
	result = sprintf(&payload[index],"%.*s", 338-index, "null");
} else {
	result = sprintf(&payload[index], "%#.15g", longitude_err);
}
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "speed");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
if (isnan(speed) || isinf(speed)) {
	result = sprintf(&payload[index],"%.*s", 338-index, "null");
} else {
	result = sprintf(&payload[index], "%#.15g", speed);
}
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "speed_err");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
if (isnan(speed_err) || isinf(speed_err)) {
	result = sprintf(&payload[index],"%.*s", 338-index, "null");
} else {
	result = sprintf(&payload[index], "%#.15g", speed_err);
}
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "track");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
if (isnan(track) || isinf(track)) {
	result = sprintf(&payload[index],"%.*s", 338-index, "null");
} else {
	result = sprintf(&payload[index], "%#.15g", track);
}
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "track_err");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
if (isnan(track_err) || isinf(track_err)) {
	result = sprintf(&payload[index],"%.*s", 338-index, "null");
} else {
	result = sprintf(&payload[index], "%#.15g", track_err);
}
if (result >= 0) { index += result; } else { return; }
payload[index++] = '}';
payload[index++] = 0;
f_GPSPortExt_PosixMqttJson_Impl_publish_message(_instance, "gps_position", payload, strlen(payload));
free(payload);
GPSPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 1;
}
}
void GPSPortExt_PosixMqttJson_Impl_handle_posixmqtt_mqtt_connected(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance) {
if(!(_instance->active)) return;
//Region PosixMQTTJSonSC
uint8_t GPSPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 0;
//End Region PosixMQTTJSonSC
//End dsregion PosixMQTTJSonSC
//Session list: 
if (1) {
f_GPSPortExt_PosixMqttJson_Impl_posixmqtt_subscribe(_instance);
GPSPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 1;
}
}
void GPSPortExt_PosixMqttJson_Impl_handle_posixmqtt_mqtt_message(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic, uint8_t * payload, uint32_t size) {
if(!(_instance->active)) return;
//Region PosixMQTTJSonSC
uint8_t GPSPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 0;
//End Region PosixMQTTJSonSC
//End dsregion PosixMQTTJSonSC
//Session list: 
if (1) {
f_GPSPortExt_PosixMqttJson_Impl_posixmqtt_parsemsg(_instance, topic, payload, size);
GPSPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 1;
}
}

// Observers for outgoing messages:
void (*external_GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener)(struct GPSPortExt_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t)= 0x0;
void (*GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener)(struct GPSPortExt_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t)= 0x0;
void register_external_GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(void (*_listener)(struct GPSPortExt_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t)){
external_GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener = _listener;
}
void register_GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(void (*_listener)(struct GPSPortExt_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t)){
GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener = _listener;
}
void GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic, uint8_t * payload, uint32_t size){
if (GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener != 0x0) GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(_instance, topic, payload, size);
if (external_GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener != 0x0) external_GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(_instance, topic, payload, size);
;
}
void (*external_GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener)(struct GPSPortExt_PosixMqttJson_Impl_Instance *, char *)= 0x0;
void (*GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener)(struct GPSPortExt_PosixMqttJson_Impl_Instance *, char *)= 0x0;
void register_external_GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(void (*_listener)(struct GPSPortExt_PosixMqttJson_Impl_Instance *, char *)){
external_GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener = _listener;
}
void register_GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(void (*_listener)(struct GPSPortExt_PosixMqttJson_Impl_Instance *, char *)){
GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener = _listener;
}
void GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe(struct GPSPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic){
if (GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener != 0x0) GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(_instance, topic);
if (external_GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener != 0x0) external_GPSPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(_instance, topic);
;
}



