/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *           Header for Thing PosixMQTTAdapter
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#ifndef PosixMQTTAdapter_H_
#define PosixMQTTAdapter_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "thingml_typedefs.h"

/*****************************************************************************
 * Headers for type : PosixMQTTAdapter
 *****************************************************************************/


// BEGIN: Code from the c_header annotation PosixMQTTAdapter

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <stdint.h>
#include <math.h>
#include <time.h>
#include <mosquitto.h>
// END: Code from the c_header annotation PosixMQTTAdapter

// Definition of the instance struct:
struct PosixMQTTAdapter_Instance {

// Instances of different sessions
bool active;
// Variables for the ID of the ports of the instance
uint16_t id_mqtt;
// Variables for the current instance state
int PosixMQTTAdapter_MQTTAdapterThing_State;
// Variables for the properties of the instance
uint16_t AbstractMQTTAdapter_broker_port_var;
char * AbstractMQTTAdapter_keyfile_var;
char * AbstractMQTTAdapter_username_var;
char * AbstractMQTTAdapter_cafile_var;
char * AbstractMQTTAdapter_client_id_var;
char * AbstractMQTTAdapter_capath_var;
bool AbstractMQTTAdapter_enable_tls_var;
char * AbstractMQTTAdapter_certfile_var;
bool AbstractMQTTAdapter_enable_user_credentials_var;
char * AbstractMQTTAdapter_topic_prefix_var;
struct mosquitto * PosixMQTTAdapter_client_var;
char * AbstractMQTTAdapter_broker_host_var;
bool PosixMQTTAdapter_debug_log_var;
char * AbstractMQTTAdapter_password_var;
bool AbstractMQTTAdapter_enable_tls_certificates_var;

};
// Declaration of prototypes outgoing messages :
void PosixMQTTAdapter_MQTTAdapterThing_OnEntry(int state, struct PosixMQTTAdapter_Instance *_instance);
void PosixMQTTAdapter_handle_mqtt_mqtt_publish(struct PosixMQTTAdapter_Instance *_instance, char * topic, uint8_t * payload, uint32_t size);
void PosixMQTTAdapter_handle_mqtt_mqtt_connect(struct PosixMQTTAdapter_Instance *_instance, char * client_id, char * host, uint16_t portno, bool tls);
void PosixMQTTAdapter_handle_mqtt_mqtt_set_tls_certificates(struct PosixMQTTAdapter_Instance *_instance, char * cafile, char * capath, char * certfile, char * keyfile);
void PosixMQTTAdapter_handle_mqtt_mqtt_subscribe(struct PosixMQTTAdapter_Instance *_instance, char * topic);
void PosixMQTTAdapter_handle_mqtt_mqtt_set_credentials(struct PosixMQTTAdapter_Instance *_instance, char * usr, char * pwd);
void PosixMQTTAdapter_handle_mqtt_mqtt_publish_with_qos(struct PosixMQTTAdapter_Instance *_instance, char * topic, uint8_t * payload, uint32_t size, uint8_t qos, bool retain);
void PosixMQTTAdapter_handle_mqtt_mqtt_set_prefix(struct PosixMQTTAdapter_Instance *_instance, char * prefix);
// Declaration of callbacks for incoming messages:
void register_PosixMQTTAdapter_send_mqtt_mqtt_connected_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *));
void register_external_PosixMQTTAdapter_send_mqtt_mqtt_connected_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *));
void register_PosixMQTTAdapter_send_mqtt_mqtt_disconnected_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *));
void register_external_PosixMQTTAdapter_send_mqtt_mqtt_disconnected_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *));
void register_PosixMQTTAdapter_send_mqtt_mqtt_message_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *, char *, uint8_t *, uint32_t));
void register_external_PosixMQTTAdapter_send_mqtt_mqtt_message_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *, char *, uint8_t *, uint32_t));
void register_PosixMQTTAdapter_send_mqtt_mqtt_error_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *));
void register_external_PosixMQTTAdapter_send_mqtt_mqtt_error_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *));
void register_PosixMQTTAdapter_send_mqtt_mqtt_message_published_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *));
void register_external_PosixMQTTAdapter_send_mqtt_mqtt_message_published_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *));
void register_PosixMQTTAdapter_send_mqtt_mqtt_topic_subscribed_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *));
void register_external_PosixMQTTAdapter_send_mqtt_mqtt_topic_subscribed_listener(void (*_listener)(struct PosixMQTTAdapter_Instance *));

// Definition of the states:
#define POSIXMQTTADAPTER_MQTTADAPTERTHING_STATE 0
#define POSIXMQTTADAPTER_MQTTADAPTERTHING_START_STATE 1



#ifdef __cplusplus
}
#endif

#endif //PosixMQTTAdapter_H_
