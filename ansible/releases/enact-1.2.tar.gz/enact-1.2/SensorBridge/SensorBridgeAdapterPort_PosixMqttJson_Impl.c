/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *        Implementation for Thing SensorBridgeAdapterPort_PosixMqttJson_Impl
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#include "SensorBridgeAdapterPort_PosixMqttJson_Impl.h"

/*****************************************************************************
 * Implementation for type : SensorBridgeAdapterPort_PosixMqttJson_Impl
 *****************************************************************************/

// Declaration of prototypes:
//Prototypes: State Machine
void SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_OnExit(int state, struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance);
//Prototypes: Message Sending
void SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_sensor_rate(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, uint16_t ms);
void SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_digital_output(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, uint8_t pin, uint8_t value);
void SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, char * topic, uint8_t * payload, uint32_t size);
void SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, char * topic);
//Prototypes: Function
void f_SensorBridgeAdapterPort_PosixMqttJson_Impl_subscribe_for_message(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, char * msg_name);
void f_SensorBridgeAdapterPort_PosixMqttJson_Impl_publish_message(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, char * msg_name, uint8_t * payload, uint32_t size);
void f_SensorBridgeAdapterPort_PosixMqttJson_Impl_posixmqtt_subscribe(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance);
bool f_SensorBridgeAdapterPort_PosixMqttJson_Impl_posixmqtt_parsemsg(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, char * topic, char * payload, uint32_t len);
// Declaration of functions:
// Definition of function subscribe_for_message
void f_SensorBridgeAdapterPort_PosixMqttJson_Impl_subscribe_for_message(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, char * msg_name) {
char topic[256];
snprintf(topic, 256, "%s/%s", _instance->SensorBridgeAdapterPort_PosixMqttJson_Impl_mqtt_topic_name_var, msg_name);
SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe(_instance, topic);
}
// Definition of function publish_message
void f_SensorBridgeAdapterPort_PosixMqttJson_Impl_publish_message(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, char * msg_name, uint8_t * payload, uint32_t size) {
char topic[256];
snprintf(topic, 256, "%s/%s", _instance->SensorBridgeAdapterPort_PosixMqttJson_Impl_mqtt_topic_name_var, msg_name);
SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish(_instance, topic, payload, size);
}
// Definition of function posixmqtt_subscribe
void f_SensorBridgeAdapterPort_PosixMqttJson_Impl_posixmqtt_subscribe(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance) {
f_SensorBridgeAdapterPort_PosixMqttJson_Impl_subscribe_for_message(_instance, "set_sensor_rate");
f_SensorBridgeAdapterPort_PosixMqttJson_Impl_subscribe_for_message(_instance, "set_digital_output");
}
// Definition of function posixmqtt_parsemsg
bool f_SensorBridgeAdapterPort_PosixMqttJson_Impl_posixmqtt_parsemsg(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, char * topic, char * payload, uint32_t len) {
jsmn_parser parser;
		jsmn_init(&parser);
		jsmntok_t tokens[32];
int16_t parse_result;
int mqtt_topic_name_length = strlen(_instance->SensorBridgeAdapterPort_PosixMqttJson_Impl_mqtt_topic_name_var);
if(!(strlen(topic) > mqtt_topic_name_length+1)) {
return 0;

}
if(strncmp(topic, _instance->SensorBridgeAdapterPort_PosixMqttJson_Impl_mqtt_topic_name_var, mqtt_topic_name_length) != 0) {
return 0;

}
if(!(topic[mqtt_topic_name_length] == '/')) {
return 0;

}
char * msg_name = &topic[mqtt_topic_name_length+1];
parse_result = jsmn_parse(&parser, payload, len, tokens, 32);;
if(strcmp(msg_name, "set_sensor_rate") == 0) {
bool ___result = 0;
uint16_t ms;
bool _found_ms = 0;
if(parse_result < 0) {
fprintf(stderr, "JSON ERROR: Parse error for set_sensor_rate message payload\n");
return 0;

}
if(parse_result < 1 + 1) {
fprintf(stderr, "JSON ERROR: incomplete payload for set_sensor_rate message\n");
return 0;

}
if(tokens[0].type != 1) {
fprintf(stderr, "JSON ERROR: wrong payload format for set_sensor_rate message\n");
return 0;

}
uint16_t __parse_i = 1;
while(__parse_i < parse_result - 1) {
if(tokens[__parse_i].type != 3 || tokens[__parse_i].size != 1) {
fprintf(stderr, "JSON ERROR: unexpected token parsing parameters for set_sensor_rate message\n");

}
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 2) && (strncmp(payload + tokens[__parse_i].start , "ms", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for ms in set_sensor_rate message\n");

} else {
ms = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_ms = 1;

}

} else {
fprintf(stdout, "JSON WARNING: got unknown parameters for set_sensor_rate message\n");

}
__parse_i = __parse_i + 2;

}
if( !(_found_ms)) {
fprintf(stderr, "JSON ERROR: Missing ms parameter for message set_sensor_rate\n");

}
if(_found_ms) {
SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_sensor_rate(_instance, ms);
___result = 1;

} else {
fprintf(stderr, "JSON ERROR: Dropping message set_sensor_rate because of missing parameters\n");

}
return ___result;

} else {
if(strcmp(msg_name, "set_digital_output") == 0) {
bool ___result = 0;
uint8_t pin;
bool _found_pin = 0;
uint8_t value;
bool _found_value = 0;
if(parse_result < 0) {
fprintf(stderr, "JSON ERROR: Parse error for set_digital_output message payload\n");
return 0;

}
if(parse_result < 1 + 2) {
fprintf(stderr, "JSON ERROR: incomplete payload for set_digital_output message\n");
return 0;

}
if(tokens[0].type != 1) {
fprintf(stderr, "JSON ERROR: wrong payload format for set_digital_output message\n");
return 0;

}
uint16_t __parse_i = 1;
while(__parse_i < parse_result - 1) {
if(tokens[__parse_i].type != 3 || tokens[__parse_i].size != 1) {
fprintf(stderr, "JSON ERROR: unexpected token parsing parameters for set_digital_output message\n");

}
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 3) && (strncmp(payload + tokens[__parse_i].start , "pin", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for pin in set_digital_output message\n");

} else {
pin = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_pin = 1;

}

} else {
if(((tokens[__parse_i].end - tokens[__parse_i].start) == 5) && (strncmp(payload + tokens[__parse_i].start , "value", tokens[__parse_i].end - tokens[__parse_i].start) == 0)) {
if(tokens[__parse_i + 1].type != 4 || tokens[__parse_i + 1].size != 0) {
fprintf(stderr, "JSON ERROR: invalid parameters type/value for value in set_digital_output message\n");

} else {
value = strtol(payload + tokens[__parse_i + 1].start, NULL, 10);
_found_value = 1;

}

} else {
fprintf(stdout, "JSON WARNING: got unknown parameters for set_digital_output message\n");

}

}
__parse_i = __parse_i + 2;

}
if( !(_found_pin)) {
fprintf(stderr, "JSON ERROR: Missing pin parameter for message set_digital_output\n");

}
if( !(_found_value)) {
fprintf(stderr, "JSON ERROR: Missing value parameter for message set_digital_output\n");

}
if(_found_pin && _found_value) {
SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_digital_output(_instance, pin, value);
___result = 1;

} else {
fprintf(stderr, "JSON ERROR: Dropping message set_digital_output because of missing parameters\n");

}
return ___result;

} else {

}

}
return 0;
}

// Sessions functionss:


// On Entry Actions:
void SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_OnEntry(int state, struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance) {
switch(state) {
case SENSORBRIDGEADAPTERPORT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_STATE:{
_instance->SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_State = SENSORBRIDGEADAPTERPORT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_RUNNING_STATE;
SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_OnEntry(_instance->SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_State, _instance);
break;
}
case SENSORBRIDGEADAPTERPORT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_RUNNING_STATE:{
break;
}
default: break;
}
}

// On Exit Actions:
void SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_OnExit(int state, struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance) {
switch(state) {
case SENSORBRIDGEADAPTERPORT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_STATE:{
SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_OnExit(_instance->SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_State, _instance);
break;}
case SENSORBRIDGEADAPTERPORT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_RUNNING_STATE:{
break;}
default: break;
}
}

// Event Handlers for incoming messages:
void SensorBridgeAdapterPort_PosixMqttJson_Impl_handle_posixmqtt_mqtt_connected(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance) {
if(!(_instance->active)) return;
//Region PosixMQTTJSonSC
uint8_t SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 0;
//End Region PosixMQTTJSonSC
//End dsregion PosixMQTTJSonSC
//Session list: 
if (1) {
f_SensorBridgeAdapterPort_PosixMqttJson_Impl_posixmqtt_subscribe(_instance);
SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 1;
}
}
void SensorBridgeAdapterPort_PosixMqttJson_Impl_handle_posixmqtt_mqtt_message(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, char * topic, uint8_t * payload, uint32_t size) {
if(!(_instance->active)) return;
//Region PosixMQTTJSonSC
uint8_t SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 0;
//End Region PosixMQTTJSonSC
//End dsregion PosixMQTTJSonSC
//Session list: 
if (1) {
f_SensorBridgeAdapterPort_PosixMqttJson_Impl_posixmqtt_parsemsg(_instance, topic, payload, size);
SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 1;
}
}
void SensorBridgeAdapterPort_PosixMqttJson_Impl_handle_fpmqtt_adc_values(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, uint16_t a0, uint16_t a1, uint16_t a2, uint16_t a3) {
if(!(_instance->active)) return;
//Region PosixMQTTJSonSC
uint8_t SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 0;
//End Region PosixMQTTJSonSC
//End dsregion PosixMQTTJSonSC
//Session list: 
if (1) {
size_t maxlength = 58;
char * payload = malloc(maxlength);
if(payload == NULL) {
printf("FATAL: ThingML runtime failed to allocate memory serializing message to JSON. Exiting.");
exit(-1);
}
uint16_t index = 0;
int result = 0;
payload[index++] = '{';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "a0");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%u", a0);
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "a1");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%u", a1);
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "a2");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%u", a2);
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "a3");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%u", a3);
if (result >= 0) { index += result; } else { return; }
payload[index++] = '}';
payload[index++] = 0;
f_SensorBridgeAdapterPort_PosixMqttJson_Impl_publish_message(_instance, "adc_values", payload, strlen(payload));
free(payload);
SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 1;
}
}
void SensorBridgeAdapterPort_PosixMqttJson_Impl_handle_fpmqtt_heartbeat_network(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, bool stable, uint8_t interval) {
if(!(_instance->active)) return;
//Region PosixMQTTJSonSC
uint8_t SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 0;
//End Region PosixMQTTJSonSC
//End dsregion PosixMQTTJSonSC
//Session list: 
if (1) {
size_t maxlength = 38;
char * payload = malloc(maxlength);
if(payload == NULL) {
printf("FATAL: ThingML runtime failed to allocate memory serializing message to JSON. Exiting.");
exit(-1);
}
uint16_t index = 0;
int result = 0;
payload[index++] = '{';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "stable");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
if (stable) { result = sprintf(&payload[index],"%.*s", 38-index, "true"); }
else { result = sprintf(&payload[index],"%.*s", 38-index, "false"); }
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "interval");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%u", interval);
if (result >= 0) { index += result; } else { return; }
payload[index++] = '}';
payload[index++] = 0;
f_SensorBridgeAdapterPort_PosixMqttJson_Impl_publish_message(_instance, "heartbeat_network", payload, strlen(payload));
free(payload);
SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 1;
}
}
void SensorBridgeAdapterPort_PosixMqttJson_Impl_handle_fpmqtt_front_panel_hwmonitor(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, int8_t temp, uint16_t voltage) {
if(!(_instance->active)) return;
//Region PosixMQTTJSonSC
uint8_t SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 0;
//End Region PosixMQTTJSonSC
//End dsregion PosixMQTTJSonSC
//Session list: 
if (1) {
size_t maxlength = 36;
char * payload = malloc(maxlength);
if(payload == NULL) {
printf("FATAL: ThingML runtime failed to allocate memory serializing message to JSON. Exiting.");
exit(-1);
}
uint16_t index = 0;
int result = 0;
payload[index++] = '{';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "temp");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%d", temp);
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "voltage");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%u", voltage);
if (result >= 0) { index += result; } else { return; }
payload[index++] = '}';
payload[index++] = 0;
f_SensorBridgeAdapterPort_PosixMqttJson_Impl_publish_message(_instance, "front_panel_hwmonitor", payload, strlen(payload));
free(payload);
SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 1;
}
}

// Observers for outgoing messages:
void (*external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_sensor_rate_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, uint16_t)= 0x0;
void (*SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_sensor_rate_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, uint16_t)= 0x0;
void register_external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_sensor_rate_listener(void (*_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, uint16_t)){
external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_sensor_rate_listener = _listener;
}
void register_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_sensor_rate_listener(void (*_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, uint16_t)){
SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_sensor_rate_listener = _listener;
}
void SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_sensor_rate(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, uint16_t ms){
if (SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_sensor_rate_listener != 0x0) SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_sensor_rate_listener(_instance, ms);
if (external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_sensor_rate_listener != 0x0) external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_sensor_rate_listener(_instance, ms);
;
}
void (*external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_digital_output_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, uint8_t, uint8_t)= 0x0;
void (*SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_digital_output_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, uint8_t, uint8_t)= 0x0;
void register_external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_digital_output_listener(void (*_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, uint8_t, uint8_t)){
external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_digital_output_listener = _listener;
}
void register_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_digital_output_listener(void (*_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, uint8_t, uint8_t)){
SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_digital_output_listener = _listener;
}
void SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_digital_output(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, uint8_t pin, uint8_t value){
if (SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_digital_output_listener != 0x0) SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_digital_output_listener(_instance, pin, value);
if (external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_digital_output_listener != 0x0) external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_digital_output_listener(_instance, pin, value);
;
}
void (*external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t)= 0x0;
void (*SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t)= 0x0;
void register_external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(void (*_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t)){
external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener = _listener;
}
void register_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(void (*_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t)){
SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener = _listener;
}
void SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, char * topic, uint8_t * payload, uint32_t size){
if (SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener != 0x0) SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(_instance, topic, payload, size);
if (external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener != 0x0) external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(_instance, topic, payload, size);
;
}
void (*external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, char *)= 0x0;
void (*SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, char *)= 0x0;
void register_external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(void (*_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, char *)){
external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener = _listener;
}
void register_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(void (*_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, char *)){
SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener = _listener;
}
void SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, char * topic){
if (SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener != 0x0) SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(_instance, topic);
if (external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener != 0x0) external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(_instance, topic);
;
}



