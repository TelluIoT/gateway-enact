/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *           Header for Thing SensorBridge
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#ifndef SensorBridge_H_
#define SensorBridge_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "thingml_typedefs.h"

/*****************************************************************************
 * Headers for type : SensorBridge
 *****************************************************************************/

// Definition of the instance struct:
struct SensorBridge_Instance {

// Instances of different sessions
bool active;
// Variables for the ID of the ports of the instance
uint16_t id_fpmqtt;
uint16_t id_fpserial;
uint16_t id_mqtt;
uint16_t id_clock;
uint16_t id_netmon;
// Variables for the current instance state
int SensorBridge_FrontPanelBridgeSC_State;
int SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State;
int SensorBridge_FrontPanelBridgeSC_NetworkMonitor_State;
// Variables for the properties of the instance
uint8_t SensorBridge_timer_id_var;
char * SensorBridge_client_id_var;
char * SensorBridge_broker_host_var;
uint16_t SensorBridge_broker_port_var;
char * SensorBridge_build_version_var;

};
// Declaration of prototypes outgoing messages :
void SensorBridge_FrontPanelBridgeSC_OnEntry(int state, struct SensorBridge_Instance *_instance);
void SensorBridge_handle_clock_timer_timeout(struct SensorBridge_Instance *_instance, uint8_t id);
void SensorBridge_handle_netmon_network_heartbeat(struct SensorBridge_Instance *_instance);
void SensorBridge_handle_mqtt_mqtt_connected(struct SensorBridge_Instance *_instance);
void SensorBridge_handle_mqtt_mqtt_disconnected(struct SensorBridge_Instance *_instance);
void SensorBridge_handle_fpserial_adc_values(struct SensorBridge_Instance *_instance, uint16_t a0, uint16_t a1, uint16_t a2, uint16_t a3);
void SensorBridge_handle_fpserial_front_panel_hwmonitor(struct SensorBridge_Instance *_instance, int8_t temp, uint16_t voltage);
void SensorBridge_handle_fpserial_ping_serial(struct SensorBridge_Instance *_instance, uint16_t seq);
void SensorBridge_handle_fpmqtt_set_sensor_rate(struct SensorBridge_Instance *_instance, uint16_t ms);
void SensorBridge_handle_fpmqtt_set_digital_output(struct SensorBridge_Instance *_instance, uint8_t pin, uint8_t value);
// Declaration of callbacks for incoming messages:
void register_SensorBridge_send_fpmqtt_front_panel_hwmonitor_listener(void (*_listener)(struct SensorBridge_Instance *, int8_t, uint16_t));
void register_external_SensorBridge_send_fpmqtt_front_panel_hwmonitor_listener(void (*_listener)(struct SensorBridge_Instance *, int8_t, uint16_t));
void register_SensorBridge_send_fpmqtt_heartbeat_network_listener(void (*_listener)(struct SensorBridge_Instance *, bool, uint8_t));
void register_external_SensorBridge_send_fpmqtt_heartbeat_network_listener(void (*_listener)(struct SensorBridge_Instance *, bool, uint8_t));
void register_SensorBridge_send_fpmqtt_adc_values_listener(void (*_listener)(struct SensorBridge_Instance *, uint16_t, uint16_t, uint16_t, uint16_t));
void register_external_SensorBridge_send_fpmqtt_adc_values_listener(void (*_listener)(struct SensorBridge_Instance *, uint16_t, uint16_t, uint16_t, uint16_t));
void register_SensorBridge_send_fpserial_pong_serial_listener(void (*_listener)(struct SensorBridge_Instance *, uint16_t));
void register_external_SensorBridge_send_fpserial_pong_serial_listener(void (*_listener)(struct SensorBridge_Instance *, uint16_t));
void register_SensorBridge_send_fpserial_heartbeat_gateway_listener(void (*_listener)(struct SensorBridge_Instance *, uint8_t));
void register_external_SensorBridge_send_fpserial_heartbeat_gateway_listener(void (*_listener)(struct SensorBridge_Instance *, uint8_t));
void register_SensorBridge_send_fpserial_heartbeat_network_listener(void (*_listener)(struct SensorBridge_Instance *, bool, uint8_t));
void register_external_SensorBridge_send_fpserial_heartbeat_network_listener(void (*_listener)(struct SensorBridge_Instance *, bool, uint8_t));
void register_SensorBridge_send_fpserial_set_sensor_rate_listener(void (*_listener)(struct SensorBridge_Instance *, uint16_t));
void register_external_SensorBridge_send_fpserial_set_sensor_rate_listener(void (*_listener)(struct SensorBridge_Instance *, uint16_t));
void register_SensorBridge_send_fpserial_set_digital_output_listener(void (*_listener)(struct SensorBridge_Instance *, uint8_t, uint8_t));
void register_external_SensorBridge_send_fpserial_set_digital_output_listener(void (*_listener)(struct SensorBridge_Instance *, uint8_t, uint8_t));
void register_SensorBridge_send_mqtt_mqtt_connect_listener(void (*_listener)(struct SensorBridge_Instance *, char *, char *, uint16_t, bool));
void register_external_SensorBridge_send_mqtt_mqtt_connect_listener(void (*_listener)(struct SensorBridge_Instance *, char *, char *, uint16_t, bool));
void register_SensorBridge_send_mqtt_mqtt_disconnect_listener(void (*_listener)(struct SensorBridge_Instance *));
void register_external_SensorBridge_send_mqtt_mqtt_disconnect_listener(void (*_listener)(struct SensorBridge_Instance *));
void register_SensorBridge_send_mqtt_mqtt_set_credentials_listener(void (*_listener)(struct SensorBridge_Instance *, char *, char *));
void register_external_SensorBridge_send_mqtt_mqtt_set_credentials_listener(void (*_listener)(struct SensorBridge_Instance *, char *, char *));
void register_SensorBridge_send_mqtt_mqtt_set_tls_certificates_listener(void (*_listener)(struct SensorBridge_Instance *, char *, char *, char *, char *));
void register_external_SensorBridge_send_mqtt_mqtt_set_tls_certificates_listener(void (*_listener)(struct SensorBridge_Instance *, char *, char *, char *, char *));
void register_SensorBridge_send_mqtt_mqtt_set_prefix_listener(void (*_listener)(struct SensorBridge_Instance *, char *));
void register_external_SensorBridge_send_mqtt_mqtt_set_prefix_listener(void (*_listener)(struct SensorBridge_Instance *, char *));
void register_SensorBridge_send_clock_timer_start_listener(void (*_listener)(struct SensorBridge_Instance *, uint8_t, uint16_t));
void register_external_SensorBridge_send_clock_timer_start_listener(void (*_listener)(struct SensorBridge_Instance *, uint8_t, uint16_t));
void register_SensorBridge_send_clock_timer_cancel_listener(void (*_listener)(struct SensorBridge_Instance *, uint8_t));
void register_external_SensorBridge_send_clock_timer_cancel_listener(void (*_listener)(struct SensorBridge_Instance *, uint8_t));
void register_SensorBridge_send_netmon_start_netmonitor_listener(void (*_listener)(struct SensorBridge_Instance *, uint8_t));
void register_external_SensorBridge_send_netmon_start_netmonitor_listener(void (*_listener)(struct SensorBridge_Instance *, uint8_t));
void register_SensorBridge_send_netmon_stop_netmonitor_listener(void (*_listener)(struct SensorBridge_Instance *));
void register_external_SensorBridge_send_netmon_stop_netmonitor_listener(void (*_listener)(struct SensorBridge_Instance *));

// Definition of the states:
#define SENSORBRIDGE_FRONTPANELBRIDGESC_NETWORKMONITOR_ACTIVE_STATE 0
#define SENSORBRIDGE_FRONTPANELBRIDGESC_LOCALMQTTMONITOR_DISCONNECTED_STATE 1
#define SENSORBRIDGE_FRONTPANELBRIDGESC_STATE 2
#define SENSORBRIDGE_FRONTPANELBRIDGESC_BRIDGING_STATE 3
#define SENSORBRIDGE_FRONTPANELBRIDGESC_LOCALMQTTMONITOR_CONNECTED_STATE 4



#ifdef __cplusplus
}
#endif

#endif //SensorBridge_H_
