#ifndef Serial_lib_h

#define Serial_lib_h

#include "Serial.c"

struct Serial_instance_type Serial_instance;

void Serial_set_listener_id(uint16_t id);
int Serial_setup();
void Serial_forwardMessage(byte * msg, uint8_t size);
void Serial_start_receiver_process();

#endif

// Forwarding of messages Serial::SensorBridge::fpserial::heartbeat_gateway
void forward_Serial_SensorBridge_send_fpserial_heartbeat_gateway(struct SensorBridge_Instance *_instance, uint8_t interval);
// Forwarding of messages Serial::SensorBridge::fpserial::heartbeat_network
void forward_Serial_SensorBridge_send_fpserial_heartbeat_network(struct SensorBridge_Instance *_instance, bool stable, uint8_t interval);
// Forwarding of messages Serial::SensorBridge::fpserial::pong_serial
void forward_Serial_SensorBridge_send_fpserial_pong_serial(struct SensorBridge_Instance *_instance, uint16_t seq);
// Forwarding of messages Serial::SensorBridge::fpserial::set_sensor_rate
void forward_Serial_SensorBridge_send_fpserial_set_sensor_rate(struct SensorBridge_Instance *_instance, uint16_t ms);
// Forwarding of messages Serial::SensorBridge::fpserial::set_digital_output
void forward_Serial_SensorBridge_send_fpserial_set_digital_output(struct SensorBridge_Instance *_instance, uint8_t pin, uint8_t value);
