/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *      Implementation for Application NetworkAgent
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include <signal.h>
#include <pthread.h>
#include "thingml_typedefs.h"
#include "runtime.h"
#include "NetworkAgent.h"
#include "TimerPosix.h"





/*****************************************************************************
 * Definitions for configuration : NetworkAgent
 *****************************************************************************/

//Declaration of instance variables
//Instance na
// Variables for the properties of the instance
struct NetworkAgent_Instance na_var;
// Variables for the sessions of the instance
//Instance t
// Variables for the properties of the instance
struct TimerPosix_Instance t_var;
// Variables for the sessions of the instance


// Enqueue of messages NetworkAgent::clock::timer_cancel
void enqueue_NetworkAgent_send_clock_timer_cancel(struct NetworkAgent_Instance *_instance, uint8_t id){
fifo_lock();
if ( fifo_byte_available() > 5 ) {

_fifo_enqueue( (1 >> 8) & 0xFF );
_fifo_enqueue( 1 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_clock >> 8) & 0xFF );
_fifo_enqueue( _instance->id_clock & 0xFF );

// parameter id
union u_id_t {
uint8_t p;
byte bytebuffer[1];
} u_id;
u_id.p = id;
_fifo_enqueue(u_id.bytebuffer[0] & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages NetworkAgent::clock::timer_start
void enqueue_NetworkAgent_send_clock_timer_start(struct NetworkAgent_Instance *_instance, uint8_t id, uint16_t time){
fifo_lock();
if ( fifo_byte_available() > 7 ) {

_fifo_enqueue( (2 >> 8) & 0xFF );
_fifo_enqueue( 2 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_clock >> 8) & 0xFF );
_fifo_enqueue( _instance->id_clock & 0xFF );

// parameter id
union u_id_t {
uint8_t p;
byte bytebuffer[1];
} u_id;
u_id.p = id;
_fifo_enqueue(u_id.bytebuffer[0] & 0xFF );

// parameter time
union u_time_t {
uint16_t p;
byte bytebuffer[2];
} u_time;
u_time.p = time;
_fifo_enqueue(u_time.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_time.bytebuffer[1] & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages TimerPosix::timer::timer_timeout
void enqueue_TimerPosix_send_timer_timer_timeout(struct TimerPosix_Instance *_instance, uint8_t id){
fifo_lock();
if ( fifo_byte_available() > 5 ) {

_fifo_enqueue( (3 >> 8) & 0xFF );
_fifo_enqueue( 3 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_timer >> 8) & 0xFF );
_fifo_enqueue( _instance->id_timer & 0xFF );

// parameter id
union u_id_t {
uint8_t p;
byte bytebuffer[1];
} u_id;
u_id.p = id;
_fifo_enqueue(u_id.bytebuffer[0] & 0xFF );
}
fifo_unlock_and_notify();
}


//New dispatcher for messages
void dispatch_timer_cancel(uint16_t sender, uint8_t param_id) {
if (sender == na_var.id_clock) {
TimerPosix_handle_timer_timer_cancel(&t_var, param_id);

}

}


//New dispatcher for messages
void dispatch_timer_timeout(uint16_t sender, uint8_t param_id) {
if (sender == t_var.id_timer) {
NetworkAgent_handle_clock_timer_timeout(&na_var, param_id);

}

}


//New dispatcher for messages
void dispatch_timer_start(uint16_t sender, uint8_t param_id, uint16_t param_time) {
if (sender == na_var.id_clock) {
TimerPosix_handle_timer_timer_start(&t_var, param_id, param_time);

}

}


int processMessageQueue() {
fifo_lock();
while (fifo_empty()) fifo_wait();
uint8_t mbufi = 0;

// Read the code of the next port/message in the queue
uint16_t code = fifo_dequeue() << 8;

code += fifo_dequeue();

// Switch to call the appropriate handler
switch(code) {
case 1:{
byte mbuf[5 - 2];
while (mbufi < (5 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_timer_cancel = 2;
union u_timer_cancel_id_t {
uint8_t p;
byte bytebuffer[1];
} u_timer_cancel_id;
u_timer_cancel_id.bytebuffer[0] = mbuf[mbufi_timer_cancel + 0];
mbufi_timer_cancel += 1;
dispatch_timer_cancel((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_timer_cancel_id.p /* id */ );
break;
}
case 3:{
byte mbuf[5 - 2];
while (mbufi < (5 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_timer_timeout = 2;
union u_timer_timeout_id_t {
uint8_t p;
byte bytebuffer[1];
} u_timer_timeout_id;
u_timer_timeout_id.bytebuffer[0] = mbuf[mbufi_timer_timeout + 0];
mbufi_timer_timeout += 1;
dispatch_timer_timeout((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_timer_timeout_id.p /* id */ );
break;
}
case 2:{
byte mbuf[7 - 2];
while (mbufi < (7 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_timer_start = 2;
union u_timer_start_id_t {
uint8_t p;
byte bytebuffer[1];
} u_timer_start_id;
u_timer_start_id.bytebuffer[0] = mbuf[mbufi_timer_start + 0];
mbufi_timer_start += 1;
union u_timer_start_time_t {
uint16_t p;
byte bytebuffer[2];
} u_timer_start_time;
u_timer_start_time.bytebuffer[0] = mbuf[mbufi_timer_start + 0];
u_timer_start_time.bytebuffer[1] = mbuf[mbufi_timer_start + 1];
mbufi_timer_start += 2;
dispatch_timer_start((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_timer_start_id.p /* id */ ,
 u_timer_start_time.p /* time */ );
break;
}
}
return 1;
}


//external Message enqueue

void initialize_configuration_NetworkAgent() {
// Initialize connectors
register_NetworkAgent_send_clock_timer_cancel_listener(&enqueue_NetworkAgent_send_clock_timer_cancel);
register_NetworkAgent_send_clock_timer_start_listener(&enqueue_NetworkAgent_send_clock_timer_start);
register_TimerPosix_send_timer_timer_timeout_listener(&enqueue_TimerPosix_send_timer_timer_timeout);


// Network Initialization
// End Network Initialization

// Init the ID, state variables and properties for instance t
t_var.active = true;
t_var.id_timer = add_instance( (void*) &t_var);
t_var.TimerPosix_SoftTimer_State = TIMERPOSIX_SOFTTIMER_DEFAULT_STATE;
t_var.TimerPosix_NB_SOFT_TIMERS_var = NB_SOFT_TIMERS;
t_var.TimerPosix_SOFT_TIMER_PERIOD_var = 50;

TimerPosix_SoftTimer_OnEntry(TIMERPOSIX_SOFTTIMER_STATE, &t_var);
// Init the ID, state variables and properties for instance na
na_var.active = true;
na_var.id_clock = add_instance( (void*) &na_var);
na_var.NetworkAgent_NetworkAgentSC_State = NETWORKAGENT_NETWORKAGENTSC_INITDELAY_STATE;
na_var.NetworkAgent_NetworkAgentSC_NeverConnected_State = NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_CHECKNETWORK_STATE;
na_var.NetworkAgent_NetworkAgentSC_Monitoring_State = NETWORKAGENT_NETWORKAGENTSC_MONITORING_WAITING_STATE;
na_var.NetworkAgent_NetworkAgentSC_ConnectionLost_State = NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_RESTARTNETWORK_STATE;
na_var.NetworkAgent_timer_id_var = 1;
na_var.NetworkAgent_INIT_RETRY_DELAY_var = 90;
na_var.NetworkAgent_NetworkAgentSC_InitDelay_sec_count_var = 0;
na_var.NetworkAgent_NetworkAgentSC_ConnectionLost_Waiting_seconds_var = 120;
na_var.NetworkAgent_LOST_RETRY_DELAY_var = 120;
na_var.NetworkAgent_NetworkAgentSC_ConnectionLost_retries_var = 0;
na_var.NetworkAgent_NetworkAgentSC_InitDelay_seconds_var = 15;
na_var.NetworkAgent_MONITORING_INTERVAL_var = 60;
na_var.NetworkAgent_NetworkAgentSC_Monitoring_error_count_var = 0;
na_var.NetworkAgent_build_version_var = "enact-1.0";
na_var.NetworkAgent_NetworkAgentSC_NeverConnected_retries_var = 0;
na_var.NetworkAgent_NetworkAgentSC_NeverConnected_Waiting_seconds_var = 90;
na_var.NetworkAgent_LOST_MAX_RETRY_var = 6;
na_var.NetworkAgent_NetworkAgentSC_Monitoring_Waiting_seconds_var = 60;
na_var.NetworkAgent_NetworkAgentSC_ConnectionLost_Waiting_sec_count_var = 0;
na_var.NetworkAgent_MONITORING_ERROR_THRESHOLD_var = 15;
na_var.NetworkAgent_NetworkAgentSC_NeverConnected_Waiting_sec_count_var = 0;
na_var.NetworkAgent_NetworkAgentSC_NeverConnected_connected_var = 0;
na_var.NetworkAgent_INIT_MAX_RETRY_var = 15;
na_var.NetworkAgent_NetworkAgentSC_ConnectionLost_connected_var = 0;
na_var.NetworkAgent_NetworkAgentSC_Monitoring_Waiting_sec_count_var = 0;

NetworkAgent_NetworkAgentSC_OnEntry(NETWORKAGENT_NETWORKAGENTSC_STATE, &na_var);
}




void term(int signum)
{
    

    fflush(stdout);
    fflush(stderr);
    exit(signum);
}


int main(int argc, char *argv[]) {
    struct sigaction action;
    memset(&action, 0, sizeof(struct sigaction));
    action.sa_handler = term;
    sigaction(SIGINT, &action, NULL);
    sigaction(SIGTERM, &action, NULL);

    init_runtime();
    
    initialize_configuration_NetworkAgent();

    while (1) {
        
// Network Listener// End Network Listener

int emptyEventConsumed = 1;
while (emptyEventConsumed != 0) {
emptyEventConsumed = 0;
emptyEventConsumed += NetworkAgent_handle_empty_event(&na_var);
}

        processMessageQueue();
  }
}