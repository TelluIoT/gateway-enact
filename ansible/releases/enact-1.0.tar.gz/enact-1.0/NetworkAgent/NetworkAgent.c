/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *        Implementation for Thing NetworkAgent
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#include "NetworkAgent.h"

/*****************************************************************************
 * Implementation for type : NetworkAgent
 *****************************************************************************/

// Declaration of prototypes:
//Prototypes: State Machine
void NetworkAgent_NetworkAgentSC_OnExit(int state, struct NetworkAgent_Instance *_instance);
//Prototypes: Message Sending
void NetworkAgent_send_clock_timer_start(struct NetworkAgent_Instance *_instance, uint8_t id, uint16_t time);
void NetworkAgent_send_clock_timer_cancel(struct NetworkAgent_Instance *_instance, uint8_t id);
//Prototypes: Function
int16_t f_NetworkAgent_checkNetwork(struct NetworkAgent_Instance *_instance);
int16_t f_NetworkAgent_restartNetwork(struct NetworkAgent_Instance *_instance);
int16_t f_NetworkAgent_restartSystem(struct NetworkAgent_Instance *_instance);
// Declaration of functions:
// Definition of function checkNetwork
int16_t f_NetworkAgent_checkNetwork(struct NetworkAgent_Instance *_instance) {
return system("/etc/tellugw/scripts/check_network.sh");
}
// Definition of function restartNetwork
int16_t f_NetworkAgent_restartNetwork(struct NetworkAgent_Instance *_instance) {
return system("/etc/tellugw/scripts/restart_network.sh");
}
// Definition of function restartSystem
int16_t f_NetworkAgent_restartSystem(struct NetworkAgent_Instance *_instance) {
return system("/etc/tellugw/scripts/restart_system.sh");
}

// Sessions functionss:


// On Entry Actions:
void NetworkAgent_NetworkAgentSC_OnEntry(int state, struct NetworkAgent_Instance *_instance) {
switch(state) {
case NETWORKAGENT_NETWORKAGENTSC_STATE:{
_instance->NetworkAgent_NetworkAgentSC_State = NETWORKAGENT_NETWORKAGENTSC_INITDELAY_STATE;
NetworkAgent_NetworkAgentSC_OnEntry(_instance->NetworkAgent_NetworkAgentSC_State, _instance);
break;
}
case NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_STATE:{
_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_State = NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_RESTARTNETWORK_STATE;
_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_connected_var = 0;
_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_retries_var = 0;
fprintf(stdout, "Network connection has been lost.");
fprintf(stdout, "\n");
fflush(stdout);
_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_connected_var = 0;
_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_retries_var = 0;
NetworkAgent_NetworkAgentSC_OnEntry(_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_State, _instance);
break;
}
case NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_STATE:{
_instance->NetworkAgent_NetworkAgentSC_NeverConnected_State = NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_CHECKNETWORK_STATE;
_instance->NetworkAgent_NetworkAgentSC_NeverConnected_connected_var = 0;
_instance->NetworkAgent_NetworkAgentSC_NeverConnected_retries_var = 0;
fprintf(stdout, "NetworkAgent checking for initial network connection.");
fprintf(stdout, "\n");
fflush(stdout);
_instance->NetworkAgent_NetworkAgentSC_NeverConnected_connected_var = 0;
_instance->NetworkAgent_NetworkAgentSC_NeverConnected_retries_var = 0;
NetworkAgent_NetworkAgentSC_OnEntry(_instance->NetworkAgent_NetworkAgentSC_NeverConnected_State, _instance);
break;
}
case NETWORKAGENT_NETWORKAGENTSC_MONITORING_STATE:{
_instance->NetworkAgent_NetworkAgentSC_Monitoring_State = NETWORKAGENT_NETWORKAGENTSC_MONITORING_WAITING_STATE;
_instance->NetworkAgent_NetworkAgentSC_Monitoring_error_count_var = 0;
fprintf(stdout, "Network connected. Monitoring connection.");
fprintf(stdout, "\n");
fflush(stdout);
_instance->NetworkAgent_NetworkAgentSC_Monitoring_error_count_var = 0;
NetworkAgent_NetworkAgentSC_OnEntry(_instance->NetworkAgent_NetworkAgentSC_Monitoring_State, _instance);
break;
}
case NETWORKAGENT_NETWORKAGENTSC_MONITORING_CHECKNETWORK_STATE:{
if(f_NetworkAgent_checkNetwork(_instance) == 0) {
_instance->NetworkAgent_NetworkAgentSC_Monitoring_error_count_var = 0;
fprintf(stdout, "Network checked OK.");
fprintf(stdout, "\n");
fflush(stdout);

} else {
_instance->NetworkAgent_NetworkAgentSC_Monitoring_error_count_var = _instance->NetworkAgent_NetworkAgentSC_Monitoring_error_count_var + 1;
fprintf(stdout, "Network is unstable. Error count: ");
fprintf(stdout, "%i",_instance->NetworkAgent_NetworkAgentSC_Monitoring_error_count_var);
fprintf(stdout, ".");
fprintf(stdout, "\n");
fflush(stdout);

}
break;
}
case NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_CHECKNETWORK_STATE:{
if(f_NetworkAgent_checkNetwork(_instance) == 0) {
fprintf(stdout, "Found network.");
fprintf(stdout, "\n");
fflush(stdout);
_instance->NetworkAgent_NetworkAgentSC_NeverConnected_connected_var = 1;

}
break;
}
case NETWORKAGENT_NETWORKAGENTSC_INITDELAY_STATE:{
fprintf(stdout, "NetworkAgent service started. Waiting 15sec before checking connection.");
fprintf(stdout, "\n");
fflush(stdout);
_instance->NetworkAgent_NetworkAgentSC_InitDelay_sec_count_var = 0;
NetworkAgent_send_clock_timer_start(_instance, _instance->NetworkAgent_timer_id_var, 1000);
break;
}
case NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_WAITING_STATE:{
_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_Waiting_sec_count_var = 0;
NetworkAgent_send_clock_timer_start(_instance, _instance->NetworkAgent_timer_id_var, 1000);
break;
}
case NETWORKAGENT_NETWORKAGENTSC_MONITORING_WAITING_STATE:{
_instance->NetworkAgent_NetworkAgentSC_Monitoring_Waiting_sec_count_var = 0;
NetworkAgent_send_clock_timer_start(_instance, _instance->NetworkAgent_timer_id_var, 1000);
break;
}
case NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_WAITING_STATE:{
_instance->NetworkAgent_NetworkAgentSC_NeverConnected_Waiting_sec_count_var = 0;
NetworkAgent_send_clock_timer_start(_instance, _instance->NetworkAgent_timer_id_var, 1000);
break;
}
case NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_RESTARTNETWORK_STATE:{
_instance->NetworkAgent_NetworkAgentSC_NeverConnected_retries_var = _instance->NetworkAgent_NetworkAgentSC_NeverConnected_retries_var + 1;
if(_instance->NetworkAgent_NetworkAgentSC_NeverConnected_retries_var <= _instance->NetworkAgent_INIT_MAX_RETRY_var) {
fprintf(stdout, "No network detected. Running restart_network script. Attempt #");
fprintf(stdout, "%i",_instance->NetworkAgent_NetworkAgentSC_NeverConnected_retries_var);
fprintf(stdout, ".");
fprintf(stdout, "\n");
fflush(stdout);
f_NetworkAgent_restartNetwork(_instance);

} else {
fprintf(stdout, "No network detected. Reached maximum number of attempts. Restarting system.");
fprintf(stdout, "\n");
fflush(stdout);
f_NetworkAgent_restartSystem(_instance);

}
break;
}
case NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_RESTARTNETWORK_STATE:{
_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_retries_var = _instance->NetworkAgent_NetworkAgentSC_ConnectionLost_retries_var + 1;
if(_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_retries_var <= _instance->NetworkAgent_LOST_MAX_RETRY_var) {
fprintf(stdout, "Network lost. Running restart_network script. Attempt #");
fprintf(stdout, "%i",_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_retries_var);
fprintf(stdout, ".");
fprintf(stdout, "\n");
fflush(stdout);
f_NetworkAgent_restartNetwork(_instance);

} else {
fprintf(stdout, "Network lost. Reached maximum number of attempts. Restarting system.");
fprintf(stdout, "\n");
fflush(stdout);
f_NetworkAgent_restartSystem(_instance);

}
break;
}
case NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_CHECKNETWORK_STATE:{
if(f_NetworkAgent_checkNetwork(_instance) == 0) {
_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_connected_var = 1;

}
break;
}
default: break;
}
}

// On Exit Actions:
void NetworkAgent_NetworkAgentSC_OnExit(int state, struct NetworkAgent_Instance *_instance) {
switch(state) {
case NETWORKAGENT_NETWORKAGENTSC_STATE:{
NetworkAgent_NetworkAgentSC_OnExit(_instance->NetworkAgent_NetworkAgentSC_State, _instance);
break;}
case NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_STATE:{
NetworkAgent_NetworkAgentSC_OnExit(_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_State, _instance);
break;}
case NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_STATE:{
NetworkAgent_NetworkAgentSC_OnExit(_instance->NetworkAgent_NetworkAgentSC_NeverConnected_State, _instance);
break;}
case NETWORKAGENT_NETWORKAGENTSC_MONITORING_STATE:{
NetworkAgent_NetworkAgentSC_OnExit(_instance->NetworkAgent_NetworkAgentSC_Monitoring_State, _instance);
break;}
case NETWORKAGENT_NETWORKAGENTSC_MONITORING_CHECKNETWORK_STATE:{
break;}
case NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_CHECKNETWORK_STATE:{
break;}
case NETWORKAGENT_NETWORKAGENTSC_INITDELAY_STATE:{
break;}
case NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_WAITING_STATE:{
break;}
case NETWORKAGENT_NETWORKAGENTSC_MONITORING_WAITING_STATE:{
break;}
case NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_WAITING_STATE:{
break;}
case NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_RESTARTNETWORK_STATE:{
break;}
case NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_RESTARTNETWORK_STATE:{
break;}
case NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_CHECKNETWORK_STATE:{
break;}
default: break;
}
}

// Event Handlers for incoming messages:
void NetworkAgent_handle_clock_timer_timeout(struct NetworkAgent_Instance *_instance, uint8_t id) {
if(!(_instance->active)) return;
//Region NetworkAgentSC
uint8_t NetworkAgent_NetworkAgentSC_State_event_consumed = 0;
if (_instance->NetworkAgent_NetworkAgentSC_State == NETWORKAGENT_NETWORKAGENTSC_INITDELAY_STATE) {
if (NetworkAgent_NetworkAgentSC_State_event_consumed == 0 && id == _instance->NetworkAgent_timer_id_var) {
_instance->NetworkAgent_NetworkAgentSC_InitDelay_sec_count_var = _instance->NetworkAgent_NetworkAgentSC_InitDelay_sec_count_var + 1;
fprintf(stdout, "NetworkAgent sec_count: ");
fprintf(stdout, "%i",_instance->NetworkAgent_NetworkAgentSC_InitDelay_sec_count_var);
fprintf(stdout, "\n");
fflush(stdout);
NetworkAgent_send_clock_timer_start(_instance, _instance->NetworkAgent_timer_id_var, 1000);
NetworkAgent_NetworkAgentSC_State_event_consumed = 1;
}
}
else if (_instance->NetworkAgent_NetworkAgentSC_State == NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_STATE) {
//Region NeverConnected
uint8_t NetworkAgent_NetworkAgentSC_NeverConnected_State_event_consumed = 0;
if (_instance->NetworkAgent_NetworkAgentSC_NeverConnected_State == NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_WAITING_STATE) {
if (NetworkAgent_NetworkAgentSC_NeverConnected_State_event_consumed == 0 && id == _instance->NetworkAgent_timer_id_var) {
_instance->NetworkAgent_NetworkAgentSC_NeverConnected_Waiting_sec_count_var = _instance->NetworkAgent_NetworkAgentSC_NeverConnected_Waiting_sec_count_var + 1;
NetworkAgent_send_clock_timer_start(_instance, _instance->NetworkAgent_timer_id_var, 1000);
NetworkAgent_NetworkAgentSC_NeverConnected_State_event_consumed = 1;
}
}
//End Region NeverConnected
NetworkAgent_NetworkAgentSC_State_event_consumed = 0 | NetworkAgent_NetworkAgentSC_NeverConnected_State_event_consumed ;
//End dsregion NeverConnected
}
else if (_instance->NetworkAgent_NetworkAgentSC_State == NETWORKAGENT_NETWORKAGENTSC_MONITORING_STATE) {
//Region Monitoring
uint8_t NetworkAgent_NetworkAgentSC_Monitoring_State_event_consumed = 0;
if (_instance->NetworkAgent_NetworkAgentSC_Monitoring_State == NETWORKAGENT_NETWORKAGENTSC_MONITORING_WAITING_STATE) {
if (NetworkAgent_NetworkAgentSC_Monitoring_State_event_consumed == 0 && id == _instance->NetworkAgent_timer_id_var) {
_instance->NetworkAgent_NetworkAgentSC_Monitoring_Waiting_sec_count_var = _instance->NetworkAgent_NetworkAgentSC_Monitoring_Waiting_sec_count_var + 1;
NetworkAgent_send_clock_timer_start(_instance, _instance->NetworkAgent_timer_id_var, 1000);
NetworkAgent_NetworkAgentSC_Monitoring_State_event_consumed = 1;
}
}
//End Region Monitoring
NetworkAgent_NetworkAgentSC_State_event_consumed = 0 | NetworkAgent_NetworkAgentSC_Monitoring_State_event_consumed ;
//End dsregion Monitoring
}
else if (_instance->NetworkAgent_NetworkAgentSC_State == NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_STATE) {
//Region ConnectionLost
uint8_t NetworkAgent_NetworkAgentSC_ConnectionLost_State_event_consumed = 0;
if (_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_State == NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_WAITING_STATE) {
if (NetworkAgent_NetworkAgentSC_ConnectionLost_State_event_consumed == 0 && id == _instance->NetworkAgent_timer_id_var) {
_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_Waiting_sec_count_var = _instance->NetworkAgent_NetworkAgentSC_ConnectionLost_Waiting_sec_count_var + 1;
NetworkAgent_send_clock_timer_start(_instance, _instance->NetworkAgent_timer_id_var, 1000);
NetworkAgent_NetworkAgentSC_ConnectionLost_State_event_consumed = 1;
}
}
//End Region ConnectionLost
NetworkAgent_NetworkAgentSC_State_event_consumed = 0 | NetworkAgent_NetworkAgentSC_ConnectionLost_State_event_consumed ;
//End dsregion ConnectionLost
}
//End Region NetworkAgentSC
//End dsregion NetworkAgentSC
//Session list: 
}
int NetworkAgent_handle_empty_event(struct NetworkAgent_Instance *_instance) {
 uint8_t empty_event_consumed = 0;
if(!(_instance->active)) return 0;
//Region NetworkAgentSC
if (_instance->NetworkAgent_NetworkAgentSC_State == NETWORKAGENT_NETWORKAGENTSC_INITDELAY_STATE) {
if (_instance->NetworkAgent_NetworkAgentSC_InitDelay_sec_count_var >= _instance->NetworkAgent_NetworkAgentSC_InitDelay_seconds_var) {
NetworkAgent_NetworkAgentSC_OnExit(NETWORKAGENT_NETWORKAGENTSC_INITDELAY_STATE, _instance);
_instance->NetworkAgent_NetworkAgentSC_State = NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_STATE;
NetworkAgent_send_clock_timer_cancel(_instance, _instance->NetworkAgent_timer_id_var);
fprintf(stdout, "NetworkAgent starting...");
fprintf(stdout, "\n");
fflush(stdout);
NetworkAgent_NetworkAgentSC_OnEntry(NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_STATE, _instance);
return 1;
}
}
else if (_instance->NetworkAgent_NetworkAgentSC_State == NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_STATE) {
//Region NeverConnected
if (_instance->NetworkAgent_NetworkAgentSC_NeverConnected_State == NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_CHECKNETWORK_STATE) {
if ( !(_instance->NetworkAgent_NetworkAgentSC_NeverConnected_connected_var)) {
NetworkAgent_NetworkAgentSC_OnExit(NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_CHECKNETWORK_STATE, _instance);
_instance->NetworkAgent_NetworkAgentSC_NeverConnected_State = NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_RESTARTNETWORK_STATE;
NetworkAgent_NetworkAgentSC_OnEntry(NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_RESTARTNETWORK_STATE, _instance);
return 1;
}
}
else if (_instance->NetworkAgent_NetworkAgentSC_NeverConnected_State == NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_RESTARTNETWORK_STATE) {
if (1) {
NetworkAgent_NetworkAgentSC_OnExit(NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_RESTARTNETWORK_STATE, _instance);
_instance->NetworkAgent_NetworkAgentSC_NeverConnected_State = NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_WAITING_STATE;
NetworkAgent_NetworkAgentSC_OnEntry(NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_WAITING_STATE, _instance);
return 1;
}
}
else if (_instance->NetworkAgent_NetworkAgentSC_NeverConnected_State == NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_WAITING_STATE) {
if (_instance->NetworkAgent_NetworkAgentSC_NeverConnected_Waiting_sec_count_var >= _instance->NetworkAgent_NetworkAgentSC_NeverConnected_Waiting_seconds_var) {
NetworkAgent_NetworkAgentSC_OnExit(NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_WAITING_STATE, _instance);
_instance->NetworkAgent_NetworkAgentSC_NeverConnected_State = NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_CHECKNETWORK_STATE;
NetworkAgent_send_clock_timer_cancel(_instance, _instance->NetworkAgent_timer_id_var);
NetworkAgent_NetworkAgentSC_OnEntry(NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_CHECKNETWORK_STATE, _instance);
return 1;
}
}
if (_instance->NetworkAgent_NetworkAgentSC_NeverConnected_connected_var) {
NetworkAgent_NetworkAgentSC_OnExit(NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_STATE, _instance);
_instance->NetworkAgent_NetworkAgentSC_State = NETWORKAGENT_NETWORKAGENTSC_MONITORING_STATE;
NetworkAgent_NetworkAgentSC_OnEntry(NETWORKAGENT_NETWORKAGENTSC_MONITORING_STATE, _instance);
return 1;
}
}
else if (_instance->NetworkAgent_NetworkAgentSC_State == NETWORKAGENT_NETWORKAGENTSC_MONITORING_STATE) {
//Region Monitoring
if (_instance->NetworkAgent_NetworkAgentSC_Monitoring_State == NETWORKAGENT_NETWORKAGENTSC_MONITORING_WAITING_STATE) {
if (_instance->NetworkAgent_NetworkAgentSC_Monitoring_Waiting_sec_count_var >= _instance->NetworkAgent_NetworkAgentSC_Monitoring_Waiting_seconds_var) {
NetworkAgent_NetworkAgentSC_OnExit(NETWORKAGENT_NETWORKAGENTSC_MONITORING_WAITING_STATE, _instance);
_instance->NetworkAgent_NetworkAgentSC_Monitoring_State = NETWORKAGENT_NETWORKAGENTSC_MONITORING_CHECKNETWORK_STATE;
NetworkAgent_send_clock_timer_cancel(_instance, _instance->NetworkAgent_timer_id_var);
NetworkAgent_NetworkAgentSC_OnEntry(NETWORKAGENT_NETWORKAGENTSC_MONITORING_CHECKNETWORK_STATE, _instance);
return 1;
}
}
else if (_instance->NetworkAgent_NetworkAgentSC_Monitoring_State == NETWORKAGENT_NETWORKAGENTSC_MONITORING_CHECKNETWORK_STATE) {
if (1) {
NetworkAgent_NetworkAgentSC_OnExit(NETWORKAGENT_NETWORKAGENTSC_MONITORING_CHECKNETWORK_STATE, _instance);
_instance->NetworkAgent_NetworkAgentSC_Monitoring_State = NETWORKAGENT_NETWORKAGENTSC_MONITORING_WAITING_STATE;
NetworkAgent_NetworkAgentSC_OnEntry(NETWORKAGENT_NETWORKAGENTSC_MONITORING_WAITING_STATE, _instance);
return 1;
}
}
if (_instance->NetworkAgent_NetworkAgentSC_Monitoring_error_count_var > _instance->NetworkAgent_MONITORING_ERROR_THRESHOLD_var) {
NetworkAgent_NetworkAgentSC_OnExit(NETWORKAGENT_NETWORKAGENTSC_MONITORING_STATE, _instance);
_instance->NetworkAgent_NetworkAgentSC_State = NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_STATE;
NetworkAgent_NetworkAgentSC_OnEntry(NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_STATE, _instance);
return 1;
}
}
else if (_instance->NetworkAgent_NetworkAgentSC_State == NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_STATE) {
//Region ConnectionLost
if (_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_State == NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_CHECKNETWORK_STATE) {
if ( !(_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_connected_var)) {
NetworkAgent_NetworkAgentSC_OnExit(NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_CHECKNETWORK_STATE, _instance);
_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_State = NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_RESTARTNETWORK_STATE;
NetworkAgent_NetworkAgentSC_OnEntry(NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_RESTARTNETWORK_STATE, _instance);
return 1;
}
}
else if (_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_State == NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_RESTARTNETWORK_STATE) {
if (1) {
NetworkAgent_NetworkAgentSC_OnExit(NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_RESTARTNETWORK_STATE, _instance);
_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_State = NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_WAITING_STATE;
NetworkAgent_NetworkAgentSC_OnEntry(NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_WAITING_STATE, _instance);
return 1;
}
}
else if (_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_State == NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_WAITING_STATE) {
if (_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_Waiting_sec_count_var >= _instance->NetworkAgent_NetworkAgentSC_ConnectionLost_Waiting_seconds_var) {
NetworkAgent_NetworkAgentSC_OnExit(NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_WAITING_STATE, _instance);
_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_State = NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_CHECKNETWORK_STATE;
NetworkAgent_send_clock_timer_cancel(_instance, _instance->NetworkAgent_timer_id_var);
NetworkAgent_NetworkAgentSC_OnEntry(NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_CHECKNETWORK_STATE, _instance);
return 1;
}
}
if (_instance->NetworkAgent_NetworkAgentSC_ConnectionLost_connected_var) {
NetworkAgent_NetworkAgentSC_OnExit(NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_STATE, _instance);
_instance->NetworkAgent_NetworkAgentSC_State = NETWORKAGENT_NETWORKAGENTSC_MONITORING_STATE;
NetworkAgent_NetworkAgentSC_OnEntry(NETWORKAGENT_NETWORKAGENTSC_MONITORING_STATE, _instance);
return 1;
}
}
//begin dispatchEmptyToSession
//end dispatchEmptyToSession
return empty_event_consumed;
}

// Observers for outgoing messages:
void (*external_NetworkAgent_send_clock_timer_start_listener)(struct NetworkAgent_Instance *, uint8_t, uint16_t)= 0x0;
void (*NetworkAgent_send_clock_timer_start_listener)(struct NetworkAgent_Instance *, uint8_t, uint16_t)= 0x0;
void register_external_NetworkAgent_send_clock_timer_start_listener(void (*_listener)(struct NetworkAgent_Instance *, uint8_t, uint16_t)){
external_NetworkAgent_send_clock_timer_start_listener = _listener;
}
void register_NetworkAgent_send_clock_timer_start_listener(void (*_listener)(struct NetworkAgent_Instance *, uint8_t, uint16_t)){
NetworkAgent_send_clock_timer_start_listener = _listener;
}
void NetworkAgent_send_clock_timer_start(struct NetworkAgent_Instance *_instance, uint8_t id, uint16_t time){
if (NetworkAgent_send_clock_timer_start_listener != 0x0) NetworkAgent_send_clock_timer_start_listener(_instance, id, time);
if (external_NetworkAgent_send_clock_timer_start_listener != 0x0) external_NetworkAgent_send_clock_timer_start_listener(_instance, id, time);
;
}
void (*external_NetworkAgent_send_clock_timer_cancel_listener)(struct NetworkAgent_Instance *, uint8_t)= 0x0;
void (*NetworkAgent_send_clock_timer_cancel_listener)(struct NetworkAgent_Instance *, uint8_t)= 0x0;
void register_external_NetworkAgent_send_clock_timer_cancel_listener(void (*_listener)(struct NetworkAgent_Instance *, uint8_t)){
external_NetworkAgent_send_clock_timer_cancel_listener = _listener;
}
void register_NetworkAgent_send_clock_timer_cancel_listener(void (*_listener)(struct NetworkAgent_Instance *, uint8_t)){
NetworkAgent_send_clock_timer_cancel_listener = _listener;
}
void NetworkAgent_send_clock_timer_cancel(struct NetworkAgent_Instance *_instance, uint8_t id){
if (NetworkAgent_send_clock_timer_cancel_listener != 0x0) NetworkAgent_send_clock_timer_cancel_listener(_instance, id);
if (external_NetworkAgent_send_clock_timer_cancel_listener != 0x0) external_NetworkAgent_send_clock_timer_cancel_listener(_instance, id);
;
}



