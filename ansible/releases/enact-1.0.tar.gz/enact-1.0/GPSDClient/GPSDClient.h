/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *           Header for Thing GPSDClient
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#ifndef GPSDClient_H_
#define GPSDClient_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "thingml_typedefs.h"

/*****************************************************************************
 * Headers for type : GPSDClient
 *****************************************************************************/


// BEGIN: Code from the c_header annotation GPSDClient
#include <gps.h>"
#include <math.h>
// END: Code from the c_header annotation GPSDClient

// Definition of the instance struct:
struct GPSDClient_Instance {

// Instances of different sessions
bool active;
// Variables for the ID of the ports of the instance
uint16_t id_local;
uint16_t id_timer;
uint16_t id_mqtt;
// Variables for the current instance state
int GPSDClient_State;
// Variables for the properties of the instance
uint16_t GPSDClient_broker_port_var;
char * GPSDClient_client_id_var;
uint8_t GPSDClient_timer_id_var;
char * GPSDClient_broker_host_var;

};
// Declaration of prototypes outgoing messages :
void GPSDClient_OnEntry(int state, struct GPSDClient_Instance *_instance);
void GPSDClient_handle_timer_timer_timeout(struct GPSDClient_Instance *_instance, uint8_t id);
// Declaration of callbacks for incoming messages:
void register_GPSDClient_send_local_gps_status_listener(void (*_listener)(struct GPSDClient_Instance *, uint32_t, uint8_t, uint8_t, uint8_t));
void register_external_GPSDClient_send_local_gps_status_listener(void (*_listener)(struct GPSDClient_Instance *, uint32_t, uint8_t, uint8_t, uint8_t));
void register_GPSDClient_send_local_gps_position_listener(void (*_listener)(struct GPSDClient_Instance *, uint32_t, uint32_t, double, double, double, double, double, double, double, double));
void register_external_GPSDClient_send_local_gps_position_listener(void (*_listener)(struct GPSDClient_Instance *, uint32_t, uint32_t, double, double, double, double, double, double, double, double));
void register_GPSDClient_send_local_gps_altitude_listener(void (*_listener)(struct GPSDClient_Instance *, uint32_t, double, double, double, double));
void register_external_GPSDClient_send_local_gps_altitude_listener(void (*_listener)(struct GPSDClient_Instance *, uint32_t, double, double, double, double));
void register_GPSDClient_send_timer_timer_start_listener(void (*_listener)(struct GPSDClient_Instance *, uint8_t, uint16_t));
void register_external_GPSDClient_send_timer_timer_start_listener(void (*_listener)(struct GPSDClient_Instance *, uint8_t, uint16_t));
void register_GPSDClient_send_timer_timer_cancel_listener(void (*_listener)(struct GPSDClient_Instance *, uint8_t));
void register_external_GPSDClient_send_timer_timer_cancel_listener(void (*_listener)(struct GPSDClient_Instance *, uint8_t));
void register_GPSDClient_send_mqtt_mqtt_connect_listener(void (*_listener)(struct GPSDClient_Instance *, char *, char *, uint16_t, bool));
void register_external_GPSDClient_send_mqtt_mqtt_connect_listener(void (*_listener)(struct GPSDClient_Instance *, char *, char *, uint16_t, bool));
void register_GPSDClient_send_mqtt_mqtt_disconnect_listener(void (*_listener)(struct GPSDClient_Instance *));
void register_external_GPSDClient_send_mqtt_mqtt_disconnect_listener(void (*_listener)(struct GPSDClient_Instance *));
void register_GPSDClient_send_mqtt_mqtt_set_credentials_listener(void (*_listener)(struct GPSDClient_Instance *, char *, char *));
void register_external_GPSDClient_send_mqtt_mqtt_set_credentials_listener(void (*_listener)(struct GPSDClient_Instance *, char *, char *));
void register_GPSDClient_send_mqtt_mqtt_set_tls_certificates_listener(void (*_listener)(struct GPSDClient_Instance *, char *, char *, char *, char *));
void register_external_GPSDClient_send_mqtt_mqtt_set_tls_certificates_listener(void (*_listener)(struct GPSDClient_Instance *, char *, char *, char *, char *));
void register_GPSDClient_send_mqtt_mqtt_set_prefix_listener(void (*_listener)(struct GPSDClient_Instance *, char *));
void register_external_GPSDClient_send_mqtt_mqtt_set_prefix_listener(void (*_listener)(struct GPSDClient_Instance *, char *));

// Definition of the states:
#define GPSDCLIENT_STATE 0
#define GPSDCLIENT_NULL_READGPS_STATE 1
#define GPSDCLIENT_NULL_WAIT_STATE 2



#ifdef __cplusplus
}
#endif

#endif //GPSDClient_H_
