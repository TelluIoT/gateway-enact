/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *      Implementation for Application Prometheus
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include <signal.h>
#include <pthread.h>
#include "thingml_typedefs.h"
#include "runtime.h"
#include "LocalPortExt_PosixMqttJson_Impl.h"
#include "Prometheus.h"
#include "PosixMQTTAdapter.h"
#include "TimerPosix.h"





/*****************************************************************************
 * Definitions for configuration : Prometheus
 *****************************************************************************/

uint16_t array_main_Prometheus_arduino_adc_var[4];
//Declaration of instance variables
//Instance gwserializer
// Variables for the properties of the instance
struct LocalPortExt_PosixMqttJson_Impl_Instance gwserializer_var;
// Variables for the sessions of the instance
//Instance main
// Variables for the properties of the instance
struct Prometheus_Instance main_var;
// Variables for the sessions of the instance
//Instance localmqttadapter
// Variables for the properties of the instance
struct PosixMQTTAdapter_Instance localmqttadapter_var;
// Variables for the sessions of the instance
//Instance timer
// Variables for the properties of the instance
struct TimerPosix_Instance timer_var;
// Variables for the sessions of the instance


// Enqueue of messages LocalPortExt_PosixMqttJson_Impl::localext::adc_values
void enqueue_LocalPortExt_PosixMqttJson_Impl_send_localext_adc_values(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, uint16_t a0, uint16_t a1, uint16_t a2, uint16_t a3){
fifo_lock();
if ( fifo_byte_available() > 12 ) {

_fifo_enqueue( (94 >> 8) & 0xFF );
_fifo_enqueue( 94 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_localext >> 8) & 0xFF );
_fifo_enqueue( _instance->id_localext & 0xFF );

// parameter a0
union u_a0_t {
uint16_t p;
byte bytebuffer[2];
} u_a0;
u_a0.p = a0;
_fifo_enqueue(u_a0.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_a0.bytebuffer[1] & 0xFF );

// parameter a1
union u_a1_t {
uint16_t p;
byte bytebuffer[2];
} u_a1;
u_a1.p = a1;
_fifo_enqueue(u_a1.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_a1.bytebuffer[1] & 0xFF );

// parameter a2
union u_a2_t {
uint16_t p;
byte bytebuffer[2];
} u_a2;
u_a2.p = a2;
_fifo_enqueue(u_a2.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_a2.bytebuffer[1] & 0xFF );

// parameter a3
union u_a3_t {
uint16_t p;
byte bytebuffer[2];
} u_a3;
u_a3.p = a3;
_fifo_enqueue(u_a3.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_a3.bytebuffer[1] & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages LocalPortExt_PosixMqttJson_Impl::localext::gps_status
void enqueue_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_status(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, uint32_t timestamp, uint8_t status, uint8_t satellites_visible, uint8_t satellites_used){
fifo_lock();
if ( fifo_byte_available() > 11 ) {

_fifo_enqueue( (1 >> 8) & 0xFF );
_fifo_enqueue( 1 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_localext >> 8) & 0xFF );
_fifo_enqueue( _instance->id_localext & 0xFF );

// parameter timestamp
union u_timestamp_t {
uint32_t p;
byte bytebuffer[4];
} u_timestamp;
u_timestamp.p = timestamp;
_fifo_enqueue(u_timestamp.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_timestamp.bytebuffer[1] & 0xFF );
_fifo_enqueue(u_timestamp.bytebuffer[2] & 0xFF );
_fifo_enqueue(u_timestamp.bytebuffer[3] & 0xFF );

// parameter status
union u_status_t {
uint8_t p;
byte bytebuffer[1];
} u_status;
u_status.p = status;
_fifo_enqueue(u_status.bytebuffer[0] & 0xFF );

// parameter satellites_visible
union u_satellites_visible_t {
uint8_t p;
byte bytebuffer[1];
} u_satellites_visible;
u_satellites_visible.p = satellites_visible;
_fifo_enqueue(u_satellites_visible.bytebuffer[0] & 0xFF );

// parameter satellites_used
union u_satellites_used_t {
uint8_t p;
byte bytebuffer[1];
} u_satellites_used;
u_satellites_used.p = satellites_used;
_fifo_enqueue(u_satellites_used.bytebuffer[0] & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages LocalPortExt_PosixMqttJson_Impl::localext::gps_position
void enqueue_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_position(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, uint32_t timestamp, uint32_t gpstime, double latitude, double latitude_err, double longitude, double longitude_err, double speed, double speed_err, double track, double track_err){
fifo_lock();
if ( fifo_byte_available() > 76 ) {

_fifo_enqueue( (2 >> 8) & 0xFF );
_fifo_enqueue( 2 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_localext >> 8) & 0xFF );
_fifo_enqueue( _instance->id_localext & 0xFF );

// parameter timestamp
union u_timestamp_t {
uint32_t p;
byte bytebuffer[4];
} u_timestamp;
u_timestamp.p = timestamp;
_fifo_enqueue(u_timestamp.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_timestamp.bytebuffer[1] & 0xFF );
_fifo_enqueue(u_timestamp.bytebuffer[2] & 0xFF );
_fifo_enqueue(u_timestamp.bytebuffer[3] & 0xFF );

// parameter gpstime
union u_gpstime_t {
uint32_t p;
byte bytebuffer[4];
} u_gpstime;
u_gpstime.p = gpstime;
_fifo_enqueue(u_gpstime.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_gpstime.bytebuffer[1] & 0xFF );
_fifo_enqueue(u_gpstime.bytebuffer[2] & 0xFF );
_fifo_enqueue(u_gpstime.bytebuffer[3] & 0xFF );

// parameter latitude
union u_latitude_t {
double p;
byte bytebuffer[8];
} u_latitude;
u_latitude.p = latitude;
_fifo_enqueue(u_latitude.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_latitude.bytebuffer[1] & 0xFF );
_fifo_enqueue(u_latitude.bytebuffer[2] & 0xFF );
_fifo_enqueue(u_latitude.bytebuffer[3] & 0xFF );
_fifo_enqueue(u_latitude.bytebuffer[4] & 0xFF );
_fifo_enqueue(u_latitude.bytebuffer[5] & 0xFF );
_fifo_enqueue(u_latitude.bytebuffer[6] & 0xFF );
_fifo_enqueue(u_latitude.bytebuffer[7] & 0xFF );

// parameter latitude_err
union u_latitude_err_t {
double p;
byte bytebuffer[8];
} u_latitude_err;
u_latitude_err.p = latitude_err;
_fifo_enqueue(u_latitude_err.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_latitude_err.bytebuffer[1] & 0xFF );
_fifo_enqueue(u_latitude_err.bytebuffer[2] & 0xFF );
_fifo_enqueue(u_latitude_err.bytebuffer[3] & 0xFF );
_fifo_enqueue(u_latitude_err.bytebuffer[4] & 0xFF );
_fifo_enqueue(u_latitude_err.bytebuffer[5] & 0xFF );
_fifo_enqueue(u_latitude_err.bytebuffer[6] & 0xFF );
_fifo_enqueue(u_latitude_err.bytebuffer[7] & 0xFF );

// parameter longitude
union u_longitude_t {
double p;
byte bytebuffer[8];
} u_longitude;
u_longitude.p = longitude;
_fifo_enqueue(u_longitude.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_longitude.bytebuffer[1] & 0xFF );
_fifo_enqueue(u_longitude.bytebuffer[2] & 0xFF );
_fifo_enqueue(u_longitude.bytebuffer[3] & 0xFF );
_fifo_enqueue(u_longitude.bytebuffer[4] & 0xFF );
_fifo_enqueue(u_longitude.bytebuffer[5] & 0xFF );
_fifo_enqueue(u_longitude.bytebuffer[6] & 0xFF );
_fifo_enqueue(u_longitude.bytebuffer[7] & 0xFF );

// parameter longitude_err
union u_longitude_err_t {
double p;
byte bytebuffer[8];
} u_longitude_err;
u_longitude_err.p = longitude_err;
_fifo_enqueue(u_longitude_err.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_longitude_err.bytebuffer[1] & 0xFF );
_fifo_enqueue(u_longitude_err.bytebuffer[2] & 0xFF );
_fifo_enqueue(u_longitude_err.bytebuffer[3] & 0xFF );
_fifo_enqueue(u_longitude_err.bytebuffer[4] & 0xFF );
_fifo_enqueue(u_longitude_err.bytebuffer[5] & 0xFF );
_fifo_enqueue(u_longitude_err.bytebuffer[6] & 0xFF );
_fifo_enqueue(u_longitude_err.bytebuffer[7] & 0xFF );

// parameter speed
union u_speed_t {
double p;
byte bytebuffer[8];
} u_speed;
u_speed.p = speed;
_fifo_enqueue(u_speed.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_speed.bytebuffer[1] & 0xFF );
_fifo_enqueue(u_speed.bytebuffer[2] & 0xFF );
_fifo_enqueue(u_speed.bytebuffer[3] & 0xFF );
_fifo_enqueue(u_speed.bytebuffer[4] & 0xFF );
_fifo_enqueue(u_speed.bytebuffer[5] & 0xFF );
_fifo_enqueue(u_speed.bytebuffer[6] & 0xFF );
_fifo_enqueue(u_speed.bytebuffer[7] & 0xFF );

// parameter speed_err
union u_speed_err_t {
double p;
byte bytebuffer[8];
} u_speed_err;
u_speed_err.p = speed_err;
_fifo_enqueue(u_speed_err.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_speed_err.bytebuffer[1] & 0xFF );
_fifo_enqueue(u_speed_err.bytebuffer[2] & 0xFF );
_fifo_enqueue(u_speed_err.bytebuffer[3] & 0xFF );
_fifo_enqueue(u_speed_err.bytebuffer[4] & 0xFF );
_fifo_enqueue(u_speed_err.bytebuffer[5] & 0xFF );
_fifo_enqueue(u_speed_err.bytebuffer[6] & 0xFF );
_fifo_enqueue(u_speed_err.bytebuffer[7] & 0xFF );

// parameter track
union u_track_t {
double p;
byte bytebuffer[8];
} u_track;
u_track.p = track;
_fifo_enqueue(u_track.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_track.bytebuffer[1] & 0xFF );
_fifo_enqueue(u_track.bytebuffer[2] & 0xFF );
_fifo_enqueue(u_track.bytebuffer[3] & 0xFF );
_fifo_enqueue(u_track.bytebuffer[4] & 0xFF );
_fifo_enqueue(u_track.bytebuffer[5] & 0xFF );
_fifo_enqueue(u_track.bytebuffer[6] & 0xFF );
_fifo_enqueue(u_track.bytebuffer[7] & 0xFF );

// parameter track_err
union u_track_err_t {
double p;
byte bytebuffer[8];
} u_track_err;
u_track_err.p = track_err;
_fifo_enqueue(u_track_err.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_track_err.bytebuffer[1] & 0xFF );
_fifo_enqueue(u_track_err.bytebuffer[2] & 0xFF );
_fifo_enqueue(u_track_err.bytebuffer[3] & 0xFF );
_fifo_enqueue(u_track_err.bytebuffer[4] & 0xFF );
_fifo_enqueue(u_track_err.bytebuffer[5] & 0xFF );
_fifo_enqueue(u_track_err.bytebuffer[6] & 0xFF );
_fifo_enqueue(u_track_err.bytebuffer[7] & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages LocalPortExt_PosixMqttJson_Impl::localext::front_panel_hwmonitor
void enqueue_LocalPortExt_PosixMqttJson_Impl_send_localext_front_panel_hwmonitor(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, int8_t temp, uint16_t voltage){
fifo_lock();
if ( fifo_byte_available() > 7 ) {

_fifo_enqueue( (85 >> 8) & 0xFF );
_fifo_enqueue( 85 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_localext >> 8) & 0xFF );
_fifo_enqueue( _instance->id_localext & 0xFF );

// parameter temp
union u_temp_t {
int8_t p;
byte bytebuffer[1];
} u_temp;
u_temp.p = temp;
_fifo_enqueue(u_temp.bytebuffer[0] & 0xFF );

// parameter voltage
union u_voltage_t {
uint16_t p;
byte bytebuffer[2];
} u_voltage;
u_voltage.p = voltage;
_fifo_enqueue(u_voltage.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_voltage.bytebuffer[1] & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages LocalPortExt_PosixMqttJson_Impl::localext::ruuvi_measurement
void enqueue_LocalPortExt_PosixMqttJson_Impl_send_localext_ruuvi_measurement(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, uint32_t timestamp, char * blemac, uint32_t deviceID, uint8_t humidity, int32_t temperature, int32_t pressure, int16_t ax, int16_t ay, int16_t az, uint16_t battery, int8_t rssi){
fifo_lock();
if ( fifo_byte_available() > (30 + sizeof(void *)) ) {

_fifo_enqueue( (3 >> 8) & 0xFF );
_fifo_enqueue( 3 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_localext >> 8) & 0xFF );
_fifo_enqueue( _instance->id_localext & 0xFF );

// parameter timestamp
union u_timestamp_t {
uint32_t p;
byte bytebuffer[4];
} u_timestamp;
u_timestamp.p = timestamp;
_fifo_enqueue(u_timestamp.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_timestamp.bytebuffer[1] & 0xFF );
_fifo_enqueue(u_timestamp.bytebuffer[2] & 0xFF );
_fifo_enqueue(u_timestamp.bytebuffer[3] & 0xFF );

// parameter blemac
// Enqueue the pointer to a dynamically allocated copy of the String
char * _blemac_strcpy = _malloc_string_copy(blemac);
_fifo_enqueue_ptr(_blemac_strcpy);


// parameter deviceID
union u_deviceID_t {
uint32_t p;
byte bytebuffer[4];
} u_deviceID;
u_deviceID.p = deviceID;
_fifo_enqueue(u_deviceID.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_deviceID.bytebuffer[1] & 0xFF );
_fifo_enqueue(u_deviceID.bytebuffer[2] & 0xFF );
_fifo_enqueue(u_deviceID.bytebuffer[3] & 0xFF );

// parameter humidity
union u_humidity_t {
uint8_t p;
byte bytebuffer[1];
} u_humidity;
u_humidity.p = humidity;
_fifo_enqueue(u_humidity.bytebuffer[0] & 0xFF );

// parameter temperature
union u_temperature_t {
int32_t p;
byte bytebuffer[4];
} u_temperature;
u_temperature.p = temperature;
_fifo_enqueue(u_temperature.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_temperature.bytebuffer[1] & 0xFF );
_fifo_enqueue(u_temperature.bytebuffer[2] & 0xFF );
_fifo_enqueue(u_temperature.bytebuffer[3] & 0xFF );

// parameter pressure
union u_pressure_t {
int32_t p;
byte bytebuffer[4];
} u_pressure;
u_pressure.p = pressure;
_fifo_enqueue(u_pressure.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_pressure.bytebuffer[1] & 0xFF );
_fifo_enqueue(u_pressure.bytebuffer[2] & 0xFF );
_fifo_enqueue(u_pressure.bytebuffer[3] & 0xFF );

// parameter ax
union u_ax_t {
int16_t p;
byte bytebuffer[2];
} u_ax;
u_ax.p = ax;
_fifo_enqueue(u_ax.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_ax.bytebuffer[1] & 0xFF );

// parameter ay
union u_ay_t {
int16_t p;
byte bytebuffer[2];
} u_ay;
u_ay.p = ay;
_fifo_enqueue(u_ay.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_ay.bytebuffer[1] & 0xFF );

// parameter az
union u_az_t {
int16_t p;
byte bytebuffer[2];
} u_az;
u_az.p = az;
_fifo_enqueue(u_az.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_az.bytebuffer[1] & 0xFF );

// parameter battery
union u_battery_t {
uint16_t p;
byte bytebuffer[2];
} u_battery;
u_battery.p = battery;
_fifo_enqueue(u_battery.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_battery.bytebuffer[1] & 0xFF );

// parameter rssi
union u_rssi_t {
int8_t p;
byte bytebuffer[1];
} u_rssi;
u_rssi.p = rssi;
_fifo_enqueue(u_rssi.bytebuffer[0] & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages LocalPortExt_PosixMqttJson_Impl::localext::gps_altitude
void enqueue_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_altitude(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, uint32_t timestamp, double altitude, double altitude_err, double vspeed, double vspeed_err){
fifo_lock();
if ( fifo_byte_available() > 40 ) {

_fifo_enqueue( (4 >> 8) & 0xFF );
_fifo_enqueue( 4 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_localext >> 8) & 0xFF );
_fifo_enqueue( _instance->id_localext & 0xFF );

// parameter timestamp
union u_timestamp_t {
uint32_t p;
byte bytebuffer[4];
} u_timestamp;
u_timestamp.p = timestamp;
_fifo_enqueue(u_timestamp.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_timestamp.bytebuffer[1] & 0xFF );
_fifo_enqueue(u_timestamp.bytebuffer[2] & 0xFF );
_fifo_enqueue(u_timestamp.bytebuffer[3] & 0xFF );

// parameter altitude
union u_altitude_t {
double p;
byte bytebuffer[8];
} u_altitude;
u_altitude.p = altitude;
_fifo_enqueue(u_altitude.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_altitude.bytebuffer[1] & 0xFF );
_fifo_enqueue(u_altitude.bytebuffer[2] & 0xFF );
_fifo_enqueue(u_altitude.bytebuffer[3] & 0xFF );
_fifo_enqueue(u_altitude.bytebuffer[4] & 0xFF );
_fifo_enqueue(u_altitude.bytebuffer[5] & 0xFF );
_fifo_enqueue(u_altitude.bytebuffer[6] & 0xFF );
_fifo_enqueue(u_altitude.bytebuffer[7] & 0xFF );

// parameter altitude_err
union u_altitude_err_t {
double p;
byte bytebuffer[8];
} u_altitude_err;
u_altitude_err.p = altitude_err;
_fifo_enqueue(u_altitude_err.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_altitude_err.bytebuffer[1] & 0xFF );
_fifo_enqueue(u_altitude_err.bytebuffer[2] & 0xFF );
_fifo_enqueue(u_altitude_err.bytebuffer[3] & 0xFF );
_fifo_enqueue(u_altitude_err.bytebuffer[4] & 0xFF );
_fifo_enqueue(u_altitude_err.bytebuffer[5] & 0xFF );
_fifo_enqueue(u_altitude_err.bytebuffer[6] & 0xFF );
_fifo_enqueue(u_altitude_err.bytebuffer[7] & 0xFF );

// parameter vspeed
union u_vspeed_t {
double p;
byte bytebuffer[8];
} u_vspeed;
u_vspeed.p = vspeed;
_fifo_enqueue(u_vspeed.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_vspeed.bytebuffer[1] & 0xFF );
_fifo_enqueue(u_vspeed.bytebuffer[2] & 0xFF );
_fifo_enqueue(u_vspeed.bytebuffer[3] & 0xFF );
_fifo_enqueue(u_vspeed.bytebuffer[4] & 0xFF );
_fifo_enqueue(u_vspeed.bytebuffer[5] & 0xFF );
_fifo_enqueue(u_vspeed.bytebuffer[6] & 0xFF );
_fifo_enqueue(u_vspeed.bytebuffer[7] & 0xFF );

// parameter vspeed_err
union u_vspeed_err_t {
double p;
byte bytebuffer[8];
} u_vspeed_err;
u_vspeed_err.p = vspeed_err;
_fifo_enqueue(u_vspeed_err.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_vspeed_err.bytebuffer[1] & 0xFF );
_fifo_enqueue(u_vspeed_err.bytebuffer[2] & 0xFF );
_fifo_enqueue(u_vspeed_err.bytebuffer[3] & 0xFF );
_fifo_enqueue(u_vspeed_err.bytebuffer[4] & 0xFF );
_fifo_enqueue(u_vspeed_err.bytebuffer[5] & 0xFF );
_fifo_enqueue(u_vspeed_err.bytebuffer[6] & 0xFF );
_fifo_enqueue(u_vspeed_err.bytebuffer[7] & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages Prometheus::clock::timer_cancel
void enqueue_Prometheus_send_clock_timer_cancel(struct Prometheus_Instance *_instance, uint8_t id){
fifo_lock();
if ( fifo_byte_available() > 5 ) {

_fifo_enqueue( (5 >> 8) & 0xFF );
_fifo_enqueue( 5 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_clock >> 8) & 0xFF );
_fifo_enqueue( _instance->id_clock & 0xFF );

// parameter id
union u_id_t {
uint8_t p;
byte bytebuffer[1];
} u_id;
u_id.p = id;
_fifo_enqueue(u_id.bytebuffer[0] & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages Prometheus::clock::timer_start
void enqueue_Prometheus_send_clock_timer_start(struct Prometheus_Instance *_instance, uint8_t id, uint16_t time){
fifo_lock();
if ( fifo_byte_available() > 7 ) {

_fifo_enqueue( (6 >> 8) & 0xFF );
_fifo_enqueue( 6 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_clock >> 8) & 0xFF );
_fifo_enqueue( _instance->id_clock & 0xFF );

// parameter id
union u_id_t {
uint8_t p;
byte bytebuffer[1];
} u_id;
u_id.p = id;
_fifo_enqueue(u_id.bytebuffer[0] & 0xFF );

// parameter time
union u_time_t {
uint16_t p;
byte bytebuffer[2];
} u_time;
u_time.p = time;
_fifo_enqueue(u_time.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_time.bytebuffer[1] & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages TimerPosix::timer::timer_timeout
void enqueue_TimerPosix_send_timer_timer_timeout(struct TimerPosix_Instance *_instance, uint8_t id){
fifo_lock();
if ( fifo_byte_available() > 5 ) {

_fifo_enqueue( (7 >> 8) & 0xFF );
_fifo_enqueue( 7 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_timer >> 8) & 0xFF );
_fifo_enqueue( _instance->id_timer & 0xFF );

// parameter id
union u_id_t {
uint8_t p;
byte bytebuffer[1];
} u_id;
u_id.p = id;
_fifo_enqueue(u_id.bytebuffer[0] & 0xFF );
}
fifo_unlock_and_notify();
}


//New dispatcher for messages
void dispatch_mqtt_message_published(uint16_t sender) {
if (sender == localmqttadapter_var.id_mqtt) {

}

}

void sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_message_published(struct PosixMQTTAdapter_Instance *_instance){
dispatch_mqtt_message_published(_instance->id_mqtt);
}

//New dispatcher for messages
void dispatch_front_panel_hwmonitor(uint16_t sender, int8_t param_temp, uint16_t param_voltage) {
if (sender == gwserializer_var.id_localext) {
Prometheus_handle_local_front_panel_hwmonitor(&main_var, param_temp, param_voltage);

}

}


//New dispatcher for messages
void dispatch_ruuvi_measurement(uint16_t sender, uint32_t param_timestamp, char * param_blemac, uint32_t param_deviceID, uint8_t param_humidity, int32_t param_temperature, int32_t param_pressure, int16_t param_ax, int16_t param_ay, int16_t param_az, uint16_t param_battery, int8_t param_rssi) {
if (sender == gwserializer_var.id_localext) {
Prometheus_handle_local_ruuvi_measurement(&main_var, param_timestamp, param_blemac, param_deviceID, param_humidity, param_temperature, param_pressure, param_ax, param_ay, param_az, param_battery, param_rssi);

}

}


//New dispatcher for messages
void dispatch_mqtt_message(uint16_t sender, char * param_topic, uint8_t * param_payload, uint32_t param_size) {
if (sender == localmqttadapter_var.id_mqtt) {
LocalPortExt_PosixMqttJson_Impl_handle_posixmqtt_mqtt_message(&gwserializer_var, param_topic, param_payload, param_size);

}

}

void sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_message(struct PosixMQTTAdapter_Instance *_instance, char * topic, uint8_t * payload, uint32_t size){
dispatch_mqtt_message(_instance->id_mqtt, topic, payload, size);
}

//New dispatcher for messages
void dispatch_timer_cancel(uint16_t sender, uint8_t param_id) {
if (sender == main_var.id_clock) {
TimerPosix_handle_timer_timer_cancel(&timer_var, param_id);

}

}


//New dispatcher for messages
void dispatch_mqtt_publish(uint16_t sender, char * param_topic, uint8_t * param_payload, uint32_t param_size) {
if (sender == gwserializer_var.id_posixmqtt) {
PosixMQTTAdapter_handle_mqtt_mqtt_publish(&localmqttadapter_var, param_topic, param_payload, param_size);

}

}

void sync_dispatch_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic, uint8_t * payload, uint32_t size){
dispatch_mqtt_publish(_instance->id_posixmqtt, topic, payload, size);
}

//New dispatcher for messages
void dispatch_timer_start(uint16_t sender, uint8_t param_id, uint16_t param_time) {
if (sender == main_var.id_clock) {
TimerPosix_handle_timer_timer_start(&timer_var, param_id, param_time);

}

}


//New dispatcher for messages
void dispatch_timer_timeout(uint16_t sender, uint8_t param_id) {
if (sender == timer_var.id_timer) {
Prometheus_handle_clock_timer_timeout(&main_var, param_id);

}

}


//New dispatcher for messages
void dispatch_gps_altitude(uint16_t sender, uint32_t param_timestamp, double param_altitude, double param_altitude_err, double param_vspeed, double param_vspeed_err) {
if (sender == gwserializer_var.id_localext) {
Prometheus_handle_local_gps_altitude(&main_var, param_timestamp, param_altitude, param_altitude_err, param_vspeed, param_vspeed_err);

}

}


//New dispatcher for messages
void dispatch_mqtt_connected(uint16_t sender) {
if (sender == localmqttadapter_var.id_mqtt) {
LocalPortExt_PosixMqttJson_Impl_handle_posixmqtt_mqtt_connected(&gwserializer_var);
Prometheus_handle_localmqtt_mqtt_connected(&main_var);

}

}

void sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_connected(struct PosixMQTTAdapter_Instance *_instance){
dispatch_mqtt_connected(_instance->id_mqtt);
}

//New dispatcher for messages
void dispatch_mqtt_set_credentials(uint16_t sender, char * param_usr, char * param_pwd) {
if (sender == main_var.id_localmqtt) {
PosixMQTTAdapter_handle_mqtt_mqtt_set_credentials(&localmqttadapter_var, param_usr, param_pwd);

}

}

void sync_dispatch_Prometheus_send_localmqtt_mqtt_set_credentials(struct Prometheus_Instance *_instance, char * usr, char * pwd){
dispatch_mqtt_set_credentials(_instance->id_localmqtt, usr, pwd);
}

//New dispatcher for messages
void dispatch_mqtt_disconnect(uint16_t sender) {
if (sender == main_var.id_localmqtt) {

}

}

void sync_dispatch_Prometheus_send_localmqtt_mqtt_disconnect(struct Prometheus_Instance *_instance){
dispatch_mqtt_disconnect(_instance->id_localmqtt);
}

//New dispatcher for messages
void dispatch_mqtt_set_prefix(uint16_t sender, char * param_prefix) {
if (sender == main_var.id_localmqtt) {
PosixMQTTAdapter_handle_mqtt_mqtt_set_prefix(&localmqttadapter_var, param_prefix);

}

}

void sync_dispatch_Prometheus_send_localmqtt_mqtt_set_prefix(struct Prometheus_Instance *_instance, char * prefix){
dispatch_mqtt_set_prefix(_instance->id_localmqtt, prefix);
}

//New dispatcher for messages
void dispatch_gps_position(uint16_t sender, uint32_t param_timestamp, uint32_t param_gpstime, double param_latitude, double param_latitude_err, double param_longitude, double param_longitude_err, double param_speed, double param_speed_err, double param_track, double param_track_err) {
if (sender == gwserializer_var.id_localext) {
Prometheus_handle_local_gps_position(&main_var, param_timestamp, param_gpstime, param_latitude, param_latitude_err, param_longitude, param_longitude_err, param_speed, param_speed_err, param_track, param_track_err);

}

}


//New dispatcher for messages
void dispatch_mqtt_subscribe(uint16_t sender, char * param_topic) {
if (sender == gwserializer_var.id_posixmqtt) {
PosixMQTTAdapter_handle_mqtt_mqtt_subscribe(&localmqttadapter_var, param_topic);

}

}

void sync_dispatch_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic){
dispatch_mqtt_subscribe(_instance->id_posixmqtt, topic);
}

//New dispatcher for messages
void dispatch_adc_values(uint16_t sender, uint16_t param_a0, uint16_t param_a1, uint16_t param_a2, uint16_t param_a3) {
if (sender == gwserializer_var.id_localext) {
Prometheus_handle_local_adc_values(&main_var, param_a0, param_a1, param_a2, param_a3);

}

}


//New dispatcher for messages
void dispatch_mqtt_connect(uint16_t sender, char * param_client_id, char * param_host, uint16_t param_portno, bool param_tls) {
if (sender == main_var.id_localmqtt) {
PosixMQTTAdapter_handle_mqtt_mqtt_connect(&localmqttadapter_var, param_client_id, param_host, param_portno, param_tls);

}

}

void sync_dispatch_Prometheus_send_localmqtt_mqtt_connect(struct Prometheus_Instance *_instance, char * client_id, char * host, uint16_t portno, bool tls){
dispatch_mqtt_connect(_instance->id_localmqtt, client_id, host, portno, tls);
}

//New dispatcher for messages
void dispatch_mqtt_topic_subscribed(uint16_t sender) {
if (sender == localmqttadapter_var.id_mqtt) {

}

}

void sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_topic_subscribed(struct PosixMQTTAdapter_Instance *_instance){
dispatch_mqtt_topic_subscribed(_instance->id_mqtt);
}

//New dispatcher for messages
void dispatch_mqtt_disconnected(uint16_t sender) {
if (sender == localmqttadapter_var.id_mqtt) {
Prometheus_handle_localmqtt_mqtt_disconnected(&main_var);

}

}

void sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_disconnected(struct PosixMQTTAdapter_Instance *_instance){
dispatch_mqtt_disconnected(_instance->id_mqtt);
}

//New dispatcher for messages
void dispatch_gps_status(uint16_t sender, uint32_t param_timestamp, uint8_t param_status, uint8_t param_satellites_visible, uint8_t param_satellites_used) {
if (sender == gwserializer_var.id_localext) {
Prometheus_handle_local_gps_status(&main_var, param_timestamp, param_status, param_satellites_visible, param_satellites_used);

}

}


//New dispatcher for messages
void dispatch_mqtt_error(uint16_t sender) {
if (sender == localmqttadapter_var.id_mqtt) {

}

}

void sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_error(struct PosixMQTTAdapter_Instance *_instance){
dispatch_mqtt_error(_instance->id_mqtt);
}

int processMessageQueue() {
fifo_lock();
while (fifo_empty()) fifo_wait();
uint8_t mbufi = 0;

// Read the code of the next port/message in the queue
uint16_t code = fifo_dequeue() << 8;

code += fifo_dequeue();

// Switch to call the appropriate handler
switch(code) {
case 94:{
byte mbuf[12 - 2];
while (mbufi < (12 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_adc_values = 2;
union u_adc_values_a0_t {
uint16_t p;
byte bytebuffer[2];
} u_adc_values_a0;
u_adc_values_a0.bytebuffer[0] = mbuf[mbufi_adc_values + 0];
u_adc_values_a0.bytebuffer[1] = mbuf[mbufi_adc_values + 1];
mbufi_adc_values += 2;
union u_adc_values_a1_t {
uint16_t p;
byte bytebuffer[2];
} u_adc_values_a1;
u_adc_values_a1.bytebuffer[0] = mbuf[mbufi_adc_values + 0];
u_adc_values_a1.bytebuffer[1] = mbuf[mbufi_adc_values + 1];
mbufi_adc_values += 2;
union u_adc_values_a2_t {
uint16_t p;
byte bytebuffer[2];
} u_adc_values_a2;
u_adc_values_a2.bytebuffer[0] = mbuf[mbufi_adc_values + 0];
u_adc_values_a2.bytebuffer[1] = mbuf[mbufi_adc_values + 1];
mbufi_adc_values += 2;
union u_adc_values_a3_t {
uint16_t p;
byte bytebuffer[2];
} u_adc_values_a3;
u_adc_values_a3.bytebuffer[0] = mbuf[mbufi_adc_values + 0];
u_adc_values_a3.bytebuffer[1] = mbuf[mbufi_adc_values + 1];
mbufi_adc_values += 2;
dispatch_adc_values((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_adc_values_a0.p /* a0 */ ,
 u_adc_values_a1.p /* a1 */ ,
 u_adc_values_a2.p /* a2 */ ,
 u_adc_values_a3.p /* a3 */ );
break;
}
case 5:{
byte mbuf[5 - 2];
while (mbufi < (5 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_timer_cancel = 2;
union u_timer_cancel_id_t {
uint8_t p;
byte bytebuffer[1];
} u_timer_cancel_id;
u_timer_cancel_id.bytebuffer[0] = mbuf[mbufi_timer_cancel + 0];
mbufi_timer_cancel += 1;
dispatch_timer_cancel((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_timer_cancel_id.p /* id */ );
break;
}
case 1:{
byte mbuf[11 - 2];
while (mbufi < (11 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_gps_status = 2;
union u_gps_status_timestamp_t {
uint32_t p;
byte bytebuffer[4];
} u_gps_status_timestamp;
u_gps_status_timestamp.bytebuffer[0] = mbuf[mbufi_gps_status + 0];
u_gps_status_timestamp.bytebuffer[1] = mbuf[mbufi_gps_status + 1];
u_gps_status_timestamp.bytebuffer[2] = mbuf[mbufi_gps_status + 2];
u_gps_status_timestamp.bytebuffer[3] = mbuf[mbufi_gps_status + 3];
mbufi_gps_status += 4;
union u_gps_status_status_t {
uint8_t p;
byte bytebuffer[1];
} u_gps_status_status;
u_gps_status_status.bytebuffer[0] = mbuf[mbufi_gps_status + 0];
mbufi_gps_status += 1;
union u_gps_status_satellites_visible_t {
uint8_t p;
byte bytebuffer[1];
} u_gps_status_satellites_visible;
u_gps_status_satellites_visible.bytebuffer[0] = mbuf[mbufi_gps_status + 0];
mbufi_gps_status += 1;
union u_gps_status_satellites_used_t {
uint8_t p;
byte bytebuffer[1];
} u_gps_status_satellites_used;
u_gps_status_satellites_used.bytebuffer[0] = mbuf[mbufi_gps_status + 0];
mbufi_gps_status += 1;
dispatch_gps_status((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_gps_status_timestamp.p /* timestamp */ ,
 u_gps_status_status.p /* status */ ,
 u_gps_status_satellites_visible.p /* satellites_visible */ ,
 u_gps_status_satellites_used.p /* satellites_used */ );
break;
}
case 2:{
byte mbuf[76 - 2];
while (mbufi < (76 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_gps_position = 2;
union u_gps_position_timestamp_t {
uint32_t p;
byte bytebuffer[4];
} u_gps_position_timestamp;
u_gps_position_timestamp.bytebuffer[0] = mbuf[mbufi_gps_position + 0];
u_gps_position_timestamp.bytebuffer[1] = mbuf[mbufi_gps_position + 1];
u_gps_position_timestamp.bytebuffer[2] = mbuf[mbufi_gps_position + 2];
u_gps_position_timestamp.bytebuffer[3] = mbuf[mbufi_gps_position + 3];
mbufi_gps_position += 4;
union u_gps_position_gpstime_t {
uint32_t p;
byte bytebuffer[4];
} u_gps_position_gpstime;
u_gps_position_gpstime.bytebuffer[0] = mbuf[mbufi_gps_position + 0];
u_gps_position_gpstime.bytebuffer[1] = mbuf[mbufi_gps_position + 1];
u_gps_position_gpstime.bytebuffer[2] = mbuf[mbufi_gps_position + 2];
u_gps_position_gpstime.bytebuffer[3] = mbuf[mbufi_gps_position + 3];
mbufi_gps_position += 4;
union u_gps_position_latitude_t {
double p;
byte bytebuffer[8];
} u_gps_position_latitude;
u_gps_position_latitude.bytebuffer[0] = mbuf[mbufi_gps_position + 0];
u_gps_position_latitude.bytebuffer[1] = mbuf[mbufi_gps_position + 1];
u_gps_position_latitude.bytebuffer[2] = mbuf[mbufi_gps_position + 2];
u_gps_position_latitude.bytebuffer[3] = mbuf[mbufi_gps_position + 3];
u_gps_position_latitude.bytebuffer[4] = mbuf[mbufi_gps_position + 4];
u_gps_position_latitude.bytebuffer[5] = mbuf[mbufi_gps_position + 5];
u_gps_position_latitude.bytebuffer[6] = mbuf[mbufi_gps_position + 6];
u_gps_position_latitude.bytebuffer[7] = mbuf[mbufi_gps_position + 7];
mbufi_gps_position += 8;
union u_gps_position_latitude_err_t {
double p;
byte bytebuffer[8];
} u_gps_position_latitude_err;
u_gps_position_latitude_err.bytebuffer[0] = mbuf[mbufi_gps_position + 0];
u_gps_position_latitude_err.bytebuffer[1] = mbuf[mbufi_gps_position + 1];
u_gps_position_latitude_err.bytebuffer[2] = mbuf[mbufi_gps_position + 2];
u_gps_position_latitude_err.bytebuffer[3] = mbuf[mbufi_gps_position + 3];
u_gps_position_latitude_err.bytebuffer[4] = mbuf[mbufi_gps_position + 4];
u_gps_position_latitude_err.bytebuffer[5] = mbuf[mbufi_gps_position + 5];
u_gps_position_latitude_err.bytebuffer[6] = mbuf[mbufi_gps_position + 6];
u_gps_position_latitude_err.bytebuffer[7] = mbuf[mbufi_gps_position + 7];
mbufi_gps_position += 8;
union u_gps_position_longitude_t {
double p;
byte bytebuffer[8];
} u_gps_position_longitude;
u_gps_position_longitude.bytebuffer[0] = mbuf[mbufi_gps_position + 0];
u_gps_position_longitude.bytebuffer[1] = mbuf[mbufi_gps_position + 1];
u_gps_position_longitude.bytebuffer[2] = mbuf[mbufi_gps_position + 2];
u_gps_position_longitude.bytebuffer[3] = mbuf[mbufi_gps_position + 3];
u_gps_position_longitude.bytebuffer[4] = mbuf[mbufi_gps_position + 4];
u_gps_position_longitude.bytebuffer[5] = mbuf[mbufi_gps_position + 5];
u_gps_position_longitude.bytebuffer[6] = mbuf[mbufi_gps_position + 6];
u_gps_position_longitude.bytebuffer[7] = mbuf[mbufi_gps_position + 7];
mbufi_gps_position += 8;
union u_gps_position_longitude_err_t {
double p;
byte bytebuffer[8];
} u_gps_position_longitude_err;
u_gps_position_longitude_err.bytebuffer[0] = mbuf[mbufi_gps_position + 0];
u_gps_position_longitude_err.bytebuffer[1] = mbuf[mbufi_gps_position + 1];
u_gps_position_longitude_err.bytebuffer[2] = mbuf[mbufi_gps_position + 2];
u_gps_position_longitude_err.bytebuffer[3] = mbuf[mbufi_gps_position + 3];
u_gps_position_longitude_err.bytebuffer[4] = mbuf[mbufi_gps_position + 4];
u_gps_position_longitude_err.bytebuffer[5] = mbuf[mbufi_gps_position + 5];
u_gps_position_longitude_err.bytebuffer[6] = mbuf[mbufi_gps_position + 6];
u_gps_position_longitude_err.bytebuffer[7] = mbuf[mbufi_gps_position + 7];
mbufi_gps_position += 8;
union u_gps_position_speed_t {
double p;
byte bytebuffer[8];
} u_gps_position_speed;
u_gps_position_speed.bytebuffer[0] = mbuf[mbufi_gps_position + 0];
u_gps_position_speed.bytebuffer[1] = mbuf[mbufi_gps_position + 1];
u_gps_position_speed.bytebuffer[2] = mbuf[mbufi_gps_position + 2];
u_gps_position_speed.bytebuffer[3] = mbuf[mbufi_gps_position + 3];
u_gps_position_speed.bytebuffer[4] = mbuf[mbufi_gps_position + 4];
u_gps_position_speed.bytebuffer[5] = mbuf[mbufi_gps_position + 5];
u_gps_position_speed.bytebuffer[6] = mbuf[mbufi_gps_position + 6];
u_gps_position_speed.bytebuffer[7] = mbuf[mbufi_gps_position + 7];
mbufi_gps_position += 8;
union u_gps_position_speed_err_t {
double p;
byte bytebuffer[8];
} u_gps_position_speed_err;
u_gps_position_speed_err.bytebuffer[0] = mbuf[mbufi_gps_position + 0];
u_gps_position_speed_err.bytebuffer[1] = mbuf[mbufi_gps_position + 1];
u_gps_position_speed_err.bytebuffer[2] = mbuf[mbufi_gps_position + 2];
u_gps_position_speed_err.bytebuffer[3] = mbuf[mbufi_gps_position + 3];
u_gps_position_speed_err.bytebuffer[4] = mbuf[mbufi_gps_position + 4];
u_gps_position_speed_err.bytebuffer[5] = mbuf[mbufi_gps_position + 5];
u_gps_position_speed_err.bytebuffer[6] = mbuf[mbufi_gps_position + 6];
u_gps_position_speed_err.bytebuffer[7] = mbuf[mbufi_gps_position + 7];
mbufi_gps_position += 8;
union u_gps_position_track_t {
double p;
byte bytebuffer[8];
} u_gps_position_track;
u_gps_position_track.bytebuffer[0] = mbuf[mbufi_gps_position + 0];
u_gps_position_track.bytebuffer[1] = mbuf[mbufi_gps_position + 1];
u_gps_position_track.bytebuffer[2] = mbuf[mbufi_gps_position + 2];
u_gps_position_track.bytebuffer[3] = mbuf[mbufi_gps_position + 3];
u_gps_position_track.bytebuffer[4] = mbuf[mbufi_gps_position + 4];
u_gps_position_track.bytebuffer[5] = mbuf[mbufi_gps_position + 5];
u_gps_position_track.bytebuffer[6] = mbuf[mbufi_gps_position + 6];
u_gps_position_track.bytebuffer[7] = mbuf[mbufi_gps_position + 7];
mbufi_gps_position += 8;
union u_gps_position_track_err_t {
double p;
byte bytebuffer[8];
} u_gps_position_track_err;
u_gps_position_track_err.bytebuffer[0] = mbuf[mbufi_gps_position + 0];
u_gps_position_track_err.bytebuffer[1] = mbuf[mbufi_gps_position + 1];
u_gps_position_track_err.bytebuffer[2] = mbuf[mbufi_gps_position + 2];
u_gps_position_track_err.bytebuffer[3] = mbuf[mbufi_gps_position + 3];
u_gps_position_track_err.bytebuffer[4] = mbuf[mbufi_gps_position + 4];
u_gps_position_track_err.bytebuffer[5] = mbuf[mbufi_gps_position + 5];
u_gps_position_track_err.bytebuffer[6] = mbuf[mbufi_gps_position + 6];
u_gps_position_track_err.bytebuffer[7] = mbuf[mbufi_gps_position + 7];
mbufi_gps_position += 8;
dispatch_gps_position((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_gps_position_timestamp.p /* timestamp */ ,
 u_gps_position_gpstime.p /* gpstime */ ,
 u_gps_position_latitude.p /* latitude */ ,
 u_gps_position_latitude_err.p /* latitude_err */ ,
 u_gps_position_longitude.p /* longitude */ ,
 u_gps_position_longitude_err.p /* longitude_err */ ,
 u_gps_position_speed.p /* speed */ ,
 u_gps_position_speed_err.p /* speed_err */ ,
 u_gps_position_track.p /* track */ ,
 u_gps_position_track_err.p /* track_err */ );
break;
}
case 85:{
byte mbuf[7 - 2];
while (mbufi < (7 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_front_panel_hwmonitor = 2;
union u_front_panel_hwmonitor_temp_t {
int8_t p;
byte bytebuffer[1];
} u_front_panel_hwmonitor_temp;
u_front_panel_hwmonitor_temp.bytebuffer[0] = mbuf[mbufi_front_panel_hwmonitor + 0];
mbufi_front_panel_hwmonitor += 1;
union u_front_panel_hwmonitor_voltage_t {
uint16_t p;
byte bytebuffer[2];
} u_front_panel_hwmonitor_voltage;
u_front_panel_hwmonitor_voltage.bytebuffer[0] = mbuf[mbufi_front_panel_hwmonitor + 0];
u_front_panel_hwmonitor_voltage.bytebuffer[1] = mbuf[mbufi_front_panel_hwmonitor + 1];
mbufi_front_panel_hwmonitor += 2;
dispatch_front_panel_hwmonitor((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_front_panel_hwmonitor_temp.p /* temp */ ,
 u_front_panel_hwmonitor_voltage.p /* voltage */ );
break;
}
case 6:{
byte mbuf[7 - 2];
while (mbufi < (7 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_timer_start = 2;
union u_timer_start_id_t {
uint8_t p;
byte bytebuffer[1];
} u_timer_start_id;
u_timer_start_id.bytebuffer[0] = mbuf[mbufi_timer_start + 0];
mbufi_timer_start += 1;
union u_timer_start_time_t {
uint16_t p;
byte bytebuffer[2];
} u_timer_start_time;
u_timer_start_time.bytebuffer[0] = mbuf[mbufi_timer_start + 0];
u_timer_start_time.bytebuffer[1] = mbuf[mbufi_timer_start + 1];
mbufi_timer_start += 2;
dispatch_timer_start((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_timer_start_id.p /* id */ ,
 u_timer_start_time.p /* time */ );
break;
}
case 7:{
byte mbuf[5 - 2];
while (mbufi < (5 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_timer_timeout = 2;
union u_timer_timeout_id_t {
uint8_t p;
byte bytebuffer[1];
} u_timer_timeout_id;
u_timer_timeout_id.bytebuffer[0] = mbuf[mbufi_timer_timeout + 0];
mbufi_timer_timeout += 1;
dispatch_timer_timeout((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_timer_timeout_id.p /* id */ );
break;
}
case 3:{
byte mbuf[(30 + sizeof(void *)) - 2];
while (mbufi < ((30 + sizeof(void *)) - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_ruuvi_measurement = 2;
union u_ruuvi_measurement_timestamp_t {
uint32_t p;
byte bytebuffer[4];
} u_ruuvi_measurement_timestamp;
u_ruuvi_measurement_timestamp.bytebuffer[0] = mbuf[mbufi_ruuvi_measurement + 0];
u_ruuvi_measurement_timestamp.bytebuffer[1] = mbuf[mbufi_ruuvi_measurement + 1];
u_ruuvi_measurement_timestamp.bytebuffer[2] = mbuf[mbufi_ruuvi_measurement + 2];
u_ruuvi_measurement_timestamp.bytebuffer[3] = mbuf[mbufi_ruuvi_measurement + 3];
mbufi_ruuvi_measurement += 4;
union u_ruuvi_measurement_blemac_t {
char * p;
byte bytebuffer[sizeof(void *)];
} u_ruuvi_measurement_blemac;
for (uint8_t ___i=0; ___i<sizeof(void *); ___i++)
  u_ruuvi_measurement_blemac.bytebuffer[___i] = mbuf[mbufi_ruuvi_measurement + ___i];
mbufi_ruuvi_measurement += sizeof(void *);
union u_ruuvi_measurement_deviceID_t {
uint32_t p;
byte bytebuffer[4];
} u_ruuvi_measurement_deviceID;
u_ruuvi_measurement_deviceID.bytebuffer[0] = mbuf[mbufi_ruuvi_measurement + 0];
u_ruuvi_measurement_deviceID.bytebuffer[1] = mbuf[mbufi_ruuvi_measurement + 1];
u_ruuvi_measurement_deviceID.bytebuffer[2] = mbuf[mbufi_ruuvi_measurement + 2];
u_ruuvi_measurement_deviceID.bytebuffer[3] = mbuf[mbufi_ruuvi_measurement + 3];
mbufi_ruuvi_measurement += 4;
union u_ruuvi_measurement_humidity_t {
uint8_t p;
byte bytebuffer[1];
} u_ruuvi_measurement_humidity;
u_ruuvi_measurement_humidity.bytebuffer[0] = mbuf[mbufi_ruuvi_measurement + 0];
mbufi_ruuvi_measurement += 1;
union u_ruuvi_measurement_temperature_t {
int32_t p;
byte bytebuffer[4];
} u_ruuvi_measurement_temperature;
u_ruuvi_measurement_temperature.bytebuffer[0] = mbuf[mbufi_ruuvi_measurement + 0];
u_ruuvi_measurement_temperature.bytebuffer[1] = mbuf[mbufi_ruuvi_measurement + 1];
u_ruuvi_measurement_temperature.bytebuffer[2] = mbuf[mbufi_ruuvi_measurement + 2];
u_ruuvi_measurement_temperature.bytebuffer[3] = mbuf[mbufi_ruuvi_measurement + 3];
mbufi_ruuvi_measurement += 4;
union u_ruuvi_measurement_pressure_t {
int32_t p;
byte bytebuffer[4];
} u_ruuvi_measurement_pressure;
u_ruuvi_measurement_pressure.bytebuffer[0] = mbuf[mbufi_ruuvi_measurement + 0];
u_ruuvi_measurement_pressure.bytebuffer[1] = mbuf[mbufi_ruuvi_measurement + 1];
u_ruuvi_measurement_pressure.bytebuffer[2] = mbuf[mbufi_ruuvi_measurement + 2];
u_ruuvi_measurement_pressure.bytebuffer[3] = mbuf[mbufi_ruuvi_measurement + 3];
mbufi_ruuvi_measurement += 4;
union u_ruuvi_measurement_ax_t {
int16_t p;
byte bytebuffer[2];
} u_ruuvi_measurement_ax;
u_ruuvi_measurement_ax.bytebuffer[0] = mbuf[mbufi_ruuvi_measurement + 0];
u_ruuvi_measurement_ax.bytebuffer[1] = mbuf[mbufi_ruuvi_measurement + 1];
mbufi_ruuvi_measurement += 2;
union u_ruuvi_measurement_ay_t {
int16_t p;
byte bytebuffer[2];
} u_ruuvi_measurement_ay;
u_ruuvi_measurement_ay.bytebuffer[0] = mbuf[mbufi_ruuvi_measurement + 0];
u_ruuvi_measurement_ay.bytebuffer[1] = mbuf[mbufi_ruuvi_measurement + 1];
mbufi_ruuvi_measurement += 2;
union u_ruuvi_measurement_az_t {
int16_t p;
byte bytebuffer[2];
} u_ruuvi_measurement_az;
u_ruuvi_measurement_az.bytebuffer[0] = mbuf[mbufi_ruuvi_measurement + 0];
u_ruuvi_measurement_az.bytebuffer[1] = mbuf[mbufi_ruuvi_measurement + 1];
mbufi_ruuvi_measurement += 2;
union u_ruuvi_measurement_battery_t {
uint16_t p;
byte bytebuffer[2];
} u_ruuvi_measurement_battery;
u_ruuvi_measurement_battery.bytebuffer[0] = mbuf[mbufi_ruuvi_measurement + 0];
u_ruuvi_measurement_battery.bytebuffer[1] = mbuf[mbufi_ruuvi_measurement + 1];
mbufi_ruuvi_measurement += 2;
union u_ruuvi_measurement_rssi_t {
int8_t p;
byte bytebuffer[1];
} u_ruuvi_measurement_rssi;
u_ruuvi_measurement_rssi.bytebuffer[0] = mbuf[mbufi_ruuvi_measurement + 0];
mbufi_ruuvi_measurement += 1;
dispatch_ruuvi_measurement((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_ruuvi_measurement_timestamp.p /* timestamp */ ,
 u_ruuvi_measurement_blemac.p /* blemac */ ,
 u_ruuvi_measurement_deviceID.p /* deviceID */ ,
 u_ruuvi_measurement_humidity.p /* humidity */ ,
 u_ruuvi_measurement_temperature.p /* temperature */ ,
 u_ruuvi_measurement_pressure.p /* pressure */ ,
 u_ruuvi_measurement_ax.p /* ax */ ,
 u_ruuvi_measurement_ay.p /* ay */ ,
 u_ruuvi_measurement_az.p /* az */ ,
 u_ruuvi_measurement_battery.p /* battery */ ,
 u_ruuvi_measurement_rssi.p /* rssi */ );
 _free_string_copy(u_ruuvi_measurement_blemac.p);
break;
}
case 4:{
byte mbuf[40 - 2];
while (mbufi < (40 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_gps_altitude = 2;
union u_gps_altitude_timestamp_t {
uint32_t p;
byte bytebuffer[4];
} u_gps_altitude_timestamp;
u_gps_altitude_timestamp.bytebuffer[0] = mbuf[mbufi_gps_altitude + 0];
u_gps_altitude_timestamp.bytebuffer[1] = mbuf[mbufi_gps_altitude + 1];
u_gps_altitude_timestamp.bytebuffer[2] = mbuf[mbufi_gps_altitude + 2];
u_gps_altitude_timestamp.bytebuffer[3] = mbuf[mbufi_gps_altitude + 3];
mbufi_gps_altitude += 4;
union u_gps_altitude_altitude_t {
double p;
byte bytebuffer[8];
} u_gps_altitude_altitude;
u_gps_altitude_altitude.bytebuffer[0] = mbuf[mbufi_gps_altitude + 0];
u_gps_altitude_altitude.bytebuffer[1] = mbuf[mbufi_gps_altitude + 1];
u_gps_altitude_altitude.bytebuffer[2] = mbuf[mbufi_gps_altitude + 2];
u_gps_altitude_altitude.bytebuffer[3] = mbuf[mbufi_gps_altitude + 3];
u_gps_altitude_altitude.bytebuffer[4] = mbuf[mbufi_gps_altitude + 4];
u_gps_altitude_altitude.bytebuffer[5] = mbuf[mbufi_gps_altitude + 5];
u_gps_altitude_altitude.bytebuffer[6] = mbuf[mbufi_gps_altitude + 6];
u_gps_altitude_altitude.bytebuffer[7] = mbuf[mbufi_gps_altitude + 7];
mbufi_gps_altitude += 8;
union u_gps_altitude_altitude_err_t {
double p;
byte bytebuffer[8];
} u_gps_altitude_altitude_err;
u_gps_altitude_altitude_err.bytebuffer[0] = mbuf[mbufi_gps_altitude + 0];
u_gps_altitude_altitude_err.bytebuffer[1] = mbuf[mbufi_gps_altitude + 1];
u_gps_altitude_altitude_err.bytebuffer[2] = mbuf[mbufi_gps_altitude + 2];
u_gps_altitude_altitude_err.bytebuffer[3] = mbuf[mbufi_gps_altitude + 3];
u_gps_altitude_altitude_err.bytebuffer[4] = mbuf[mbufi_gps_altitude + 4];
u_gps_altitude_altitude_err.bytebuffer[5] = mbuf[mbufi_gps_altitude + 5];
u_gps_altitude_altitude_err.bytebuffer[6] = mbuf[mbufi_gps_altitude + 6];
u_gps_altitude_altitude_err.bytebuffer[7] = mbuf[mbufi_gps_altitude + 7];
mbufi_gps_altitude += 8;
union u_gps_altitude_vspeed_t {
double p;
byte bytebuffer[8];
} u_gps_altitude_vspeed;
u_gps_altitude_vspeed.bytebuffer[0] = mbuf[mbufi_gps_altitude + 0];
u_gps_altitude_vspeed.bytebuffer[1] = mbuf[mbufi_gps_altitude + 1];
u_gps_altitude_vspeed.bytebuffer[2] = mbuf[mbufi_gps_altitude + 2];
u_gps_altitude_vspeed.bytebuffer[3] = mbuf[mbufi_gps_altitude + 3];
u_gps_altitude_vspeed.bytebuffer[4] = mbuf[mbufi_gps_altitude + 4];
u_gps_altitude_vspeed.bytebuffer[5] = mbuf[mbufi_gps_altitude + 5];
u_gps_altitude_vspeed.bytebuffer[6] = mbuf[mbufi_gps_altitude + 6];
u_gps_altitude_vspeed.bytebuffer[7] = mbuf[mbufi_gps_altitude + 7];
mbufi_gps_altitude += 8;
union u_gps_altitude_vspeed_err_t {
double p;
byte bytebuffer[8];
} u_gps_altitude_vspeed_err;
u_gps_altitude_vspeed_err.bytebuffer[0] = mbuf[mbufi_gps_altitude + 0];
u_gps_altitude_vspeed_err.bytebuffer[1] = mbuf[mbufi_gps_altitude + 1];
u_gps_altitude_vspeed_err.bytebuffer[2] = mbuf[mbufi_gps_altitude + 2];
u_gps_altitude_vspeed_err.bytebuffer[3] = mbuf[mbufi_gps_altitude + 3];
u_gps_altitude_vspeed_err.bytebuffer[4] = mbuf[mbufi_gps_altitude + 4];
u_gps_altitude_vspeed_err.bytebuffer[5] = mbuf[mbufi_gps_altitude + 5];
u_gps_altitude_vspeed_err.bytebuffer[6] = mbuf[mbufi_gps_altitude + 6];
u_gps_altitude_vspeed_err.bytebuffer[7] = mbuf[mbufi_gps_altitude + 7];
mbufi_gps_altitude += 8;
dispatch_gps_altitude((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_gps_altitude_timestamp.p /* timestamp */ ,
 u_gps_altitude_altitude.p /* altitude */ ,
 u_gps_altitude_altitude_err.p /* altitude_err */ ,
 u_gps_altitude_vspeed.p /* vspeed */ ,
 u_gps_altitude_vspeed_err.p /* vspeed_err */ );
break;
}
}
return 1;
}


//external Message enqueue

void initialize_configuration_Prometheus() {
// Initialize connectors
register_LocalPortExt_PosixMqttJson_Impl_send_localext_adc_values_listener(&enqueue_LocalPortExt_PosixMqttJson_Impl_send_localext_adc_values);
register_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_status_listener(&enqueue_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_status);
register_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_position_listener(&enqueue_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_position);
register_LocalPortExt_PosixMqttJson_Impl_send_localext_front_panel_hwmonitor_listener(&enqueue_LocalPortExt_PosixMqttJson_Impl_send_localext_front_panel_hwmonitor);
register_LocalPortExt_PosixMqttJson_Impl_send_localext_ruuvi_measurement_listener(&enqueue_LocalPortExt_PosixMqttJson_Impl_send_localext_ruuvi_measurement);
register_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_altitude_listener(&enqueue_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_altitude);
register_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(&sync_dispatch_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish);
register_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(&sync_dispatch_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe);
register_Prometheus_send_clock_timer_cancel_listener(&enqueue_Prometheus_send_clock_timer_cancel);
register_Prometheus_send_clock_timer_start_listener(&enqueue_Prometheus_send_clock_timer_start);
register_Prometheus_send_localmqtt_mqtt_connect_listener(&sync_dispatch_Prometheus_send_localmqtt_mqtt_connect);
register_Prometheus_send_localmqtt_mqtt_set_credentials_listener(&sync_dispatch_Prometheus_send_localmqtt_mqtt_set_credentials);
register_Prometheus_send_localmqtt_mqtt_disconnect_listener(&sync_dispatch_Prometheus_send_localmqtt_mqtt_disconnect);
register_Prometheus_send_localmqtt_mqtt_set_prefix_listener(&sync_dispatch_Prometheus_send_localmqtt_mqtt_set_prefix);
register_PosixMQTTAdapter_send_mqtt_mqtt_connected_listener(&sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_connected);
register_PosixMQTTAdapter_send_mqtt_mqtt_message_listener(&sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_message);
register_PosixMQTTAdapter_send_mqtt_mqtt_disconnected_listener(&sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_disconnected);
register_TimerPosix_send_timer_timer_timeout_listener(&enqueue_TimerPosix_send_timer_timer_timeout);


// Network Initialization
// End Network Initialization

// Init the ID, state variables and properties for instance localmqttadapter
localmqttadapter_var.active = true;
localmqttadapter_var.id_mqtt = add_instance( (void*) &localmqttadapter_var);
localmqttadapter_var.PosixMQTTAdapter_MQTTAdapterThing_State = POSIXMQTTADAPTER_MQTTADAPTERTHING_START_STATE;
localmqttadapter_var.AbstractMQTTAdapter_enable_tls_certificates_var = 0;
localmqttadapter_var.PosixMQTTAdapter_client_var = NULL;
localmqttadapter_var.PosixMQTTAdapter_debug_log_var = 0;
localmqttadapter_var.AbstractMQTTAdapter_enable_user_credentials_var = 0;
localmqttadapter_var.AbstractMQTTAdapter_enable_tls_var = 0;

PosixMQTTAdapter_MQTTAdapterThing_OnEntry(POSIXMQTTADAPTER_MQTTADAPTERTHING_STATE, &localmqttadapter_var);
// Init the ID, state variables and properties for instance gwserializer
gwserializer_var.active = true;
gwserializer_var.id_localext = add_instance( (void*) &gwserializer_var);
gwserializer_var.id_posixmqtt = add_instance( (void*) &gwserializer_var);
gwserializer_var.LocalPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State = LOCALPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_RUNNING_STATE;
gwserializer_var.LocalPortExt_PosixMqttJson_Impl_mqtt_topic_name_var = "TelluGW";

LocalPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_OnEntry(LOCALPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_STATE, &gwserializer_var);
// Init the ID, state variables and properties for instance timer
timer_var.active = true;
timer_var.id_timer = add_instance( (void*) &timer_var);
timer_var.TimerPosix_SoftTimer_State = TIMERPOSIX_SOFTTIMER_DEFAULT_STATE;
timer_var.TimerPosix_NB_SOFT_TIMERS_var = NB_SOFT_TIMERS;
timer_var.TimerPosix_SOFT_TIMER_PERIOD_var = 50;

TimerPosix_SoftTimer_OnEntry(TIMERPOSIX_SOFTTIMER_STATE, &timer_var);
// Init the ID, state variables and properties for instance main
main_var.active = true;
main_var.id_local = add_instance( (void*) &main_var);
main_var.id_clock = add_instance( (void*) &main_var);
main_var.id_localmqtt = add_instance( (void*) &main_var);
main_var.Prometheus_PC_State = PROMETHEUS_PC_CONNECT_STATE;
main_var.Prometheus_build_version_var = "enact-1.0";
main_var.Prometheus_arduino_temp_var = 5000;
main_var.Prometheus_local_client_id_var = "P4Prometheus";
main_var.Prometheus_ruuvi_timeout_sec_var = 30;
main_var.Prometheus_local_broker_host_var = "localhost";
main_var.Prometheus_local_broker_port_var = 1883;
main_var.Prometheus_arduino_psu_var = 5000;
main_var.Prometheus_timer_id_var = 1;
main_var.Prometheus_gateway_psu_sensor_cal_var = 3937;
main_var.Prometheus_arduino_adc_var = array_main_Prometheus_arduino_adc_var;
main_var.Prometheus_arduino_adc_var_size = 4;

Prometheus_PC_OnEntry(PROMETHEUS_PC_STATE, &main_var);
}




void term(int signum)
{
    

    fflush(stdout);
    fflush(stderr);
    exit(signum);
}


int main(int argc, char *argv[]) {
    struct sigaction action;
    memset(&action, 0, sizeof(struct sigaction));
    action.sa_handler = term;
    sigaction(SIGINT, &action, NULL);
    sigaction(SIGTERM, &action, NULL);

    init_runtime();
    
    initialize_configuration_Prometheus();

    while (1) {
        
// Network Listener// End Network Listener

int emptyEventConsumed = 1;
while (emptyEventConsumed != 0) {
emptyEventConsumed = 0;
}

        processMessageQueue();
  }
}