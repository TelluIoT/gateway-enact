/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *           Header for Thing Prometheus
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#ifndef Prometheus_H_
#define Prometheus_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "thingml_typedefs.h"

/*****************************************************************************
 * Headers for type : Prometheus
 *****************************************************************************/


// BEGIN: Code from the c_header annotation Prometheus
#include <microhttpd.h>"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "uthash.h"
#include <errno.h>
#include <linux/unistd.h>       /* for _syscallX macros/related stuff */
#include <linux/kernel.h>       /* for struct sysinfo */
#include <sys/sysinfo.h>
#include <sys/statvfs.h>
// END: Code from the c_header annotation Prometheus

// Definition of the instance struct:
struct Prometheus_Instance {

// Instances of different sessions
bool active;
// Variables for the ID of the ports of the instance
uint16_t id_local;
uint16_t id_clock;
uint16_t id_localmqtt;
// Variables for the current instance state
int Prometheus_PC_State;
// Variables for the properties of the instance
uint8_t Prometheus_gpsstatus_var;
uint16_t Prometheus_psu_voltage_var;
char * Prometheus_build_version_var;
uint32_t Prometheus_gpsstatus_timestamp_var;
uint16_t Prometheus_arduino_temp_var;
char * Prometheus_local_client_id_var;
double Prometheus_latitude_var;
uint32_t Prometheus_altitude_timestamp_var;
uint32_t Prometheus_arduino_timestamp_var;
double Prometheus_speed_var;
uint32_t Prometheus_adc_timestamp_var;
uint8_t Prometheus_satellites_visible_var;
uint16_t Prometheus_ruuvi_timeout_sec_var;
char * Prometheus_local_broker_host_var;
uint16_t Prometheus_local_broker_port_var;
double Prometheus_altitude_var;
double Prometheus_longitude_var;
uint16_t Prometheus_arduino_psu_var;
double Prometheus_altitude_vspeed_var;
uint16_t * Prometheus_arduino_adc_var;
uint16_t Prometheus_arduino_adc_var_size;
uint8_t Prometheus_timer_id_var;
uint8_t Prometheus_satellites_used_var;
uint16_t Prometheus_gateway_psu_sensor_cal_var;
uint32_t Prometheus_position_timestamp_var;

};
// Declaration of prototypes outgoing messages :
void Prometheus_PC_OnEntry(int state, struct Prometheus_Instance *_instance);
void Prometheus_handle_clock_timer_timeout(struct Prometheus_Instance *_instance, uint8_t id);
void Prometheus_handle_local_adc_values(struct Prometheus_Instance *_instance, uint16_t a0, uint16_t a1, uint16_t a2, uint16_t a3);
void Prometheus_handle_local_gps_status(struct Prometheus_Instance *_instance, uint32_t timestamp, uint8_t status, uint8_t satellites_visible, uint8_t satellites_used);
void Prometheus_handle_local_gps_position(struct Prometheus_Instance *_instance, uint32_t timestamp, uint32_t gpstime, double latitude, double latitude_err, double longitude, double longitude_err, double speed, double speed_err, double track, double track_err);
void Prometheus_handle_local_front_panel_hwmonitor(struct Prometheus_Instance *_instance, int8_t temp, uint16_t voltage);
void Prometheus_handle_local_ruuvi_measurement(struct Prometheus_Instance *_instance, uint32_t timestamp, char * blemac, uint32_t deviceID, uint8_t humidity, int32_t temperature, int32_t pressure, int16_t ax, int16_t ay, int16_t az, uint16_t battery, int8_t rssi);
void Prometheus_handle_local_gps_altitude(struct Prometheus_Instance *_instance, uint32_t timestamp, double altitude, double altitude_err, double vspeed, double vspeed_err);
void Prometheus_handle_localmqtt_mqtt_connected(struct Prometheus_Instance *_instance);
void Prometheus_handle_localmqtt_mqtt_disconnected(struct Prometheus_Instance *_instance);
// Declaration of callbacks for incoming messages:
void register_Prometheus_send_clock_timer_start_listener(void (*_listener)(struct Prometheus_Instance *, uint8_t, uint16_t));
void register_external_Prometheus_send_clock_timer_start_listener(void (*_listener)(struct Prometheus_Instance *, uint8_t, uint16_t));
void register_Prometheus_send_clock_timer_cancel_listener(void (*_listener)(struct Prometheus_Instance *, uint8_t));
void register_external_Prometheus_send_clock_timer_cancel_listener(void (*_listener)(struct Prometheus_Instance *, uint8_t));
void register_Prometheus_send_localmqtt_mqtt_connect_listener(void (*_listener)(struct Prometheus_Instance *, char *, char *, uint16_t, bool));
void register_external_Prometheus_send_localmqtt_mqtt_connect_listener(void (*_listener)(struct Prometheus_Instance *, char *, char *, uint16_t, bool));
void register_Prometheus_send_localmqtt_mqtt_disconnect_listener(void (*_listener)(struct Prometheus_Instance *));
void register_external_Prometheus_send_localmqtt_mqtt_disconnect_listener(void (*_listener)(struct Prometheus_Instance *));
void register_Prometheus_send_localmqtt_mqtt_set_credentials_listener(void (*_listener)(struct Prometheus_Instance *, char *, char *));
void register_external_Prometheus_send_localmqtt_mqtt_set_credentials_listener(void (*_listener)(struct Prometheus_Instance *, char *, char *));
void register_Prometheus_send_localmqtt_mqtt_set_prefix_listener(void (*_listener)(struct Prometheus_Instance *, char *));
void register_external_Prometheus_send_localmqtt_mqtt_set_prefix_listener(void (*_listener)(struct Prometheus_Instance *, char *));

// Definition of the states:
#define PROMETHEUS_PC_STATE 0
#define PROMETHEUS_PC_MQTTCONNECTED_STATE 1
#define PROMETHEUS_PC_CONNECT_STATE 2



#ifdef __cplusplus
}
#endif

#endif //Prometheus_H_
