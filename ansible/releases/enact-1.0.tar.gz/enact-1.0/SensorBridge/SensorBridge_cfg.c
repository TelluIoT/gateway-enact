/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *      Implementation for Application SensorBridge
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include <signal.h>
#include <pthread.h>
#include "thingml_typedefs.h"
#include "runtime.h"
#include "TimerPosix.h"
#include "PosixMQTTAdapter.h"
#include "SensorBridge.h"
#include "SensorBridgeAdapterPort_PosixMqttJson_Impl.h"
#include "NetworkMonitor.h"

#include "Serial.h"




/*****************************************************************************
 * Definitions for configuration : SensorBridge
 *****************************************************************************/

//Declaration of instance variables
//Instance t
// Variables for the properties of the instance
struct TimerPosix_Instance t_var;
// Variables for the sessions of the instance
//Instance mqttadapter
// Variables for the properties of the instance
struct PosixMQTTAdapter_Instance mqttadapter_var;
// Variables for the sessions of the instance
//Instance bridge
// Variables for the properties of the instance
struct SensorBridge_Instance bridge_var;
// Variables for the sessions of the instance
//Instance mqttserializer
// Variables for the properties of the instance
struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance mqttserializer_var;
// Variables for the sessions of the instance
//Instance mon
// Variables for the properties of the instance
struct NetworkMonitor_Instance mon_var;
// Variables for the sessions of the instance


// Enqueue of messages TimerPosix::timer::timer_timeout
void enqueue_TimerPosix_send_timer_timer_timeout(struct TimerPosix_Instance *_instance, uint8_t id){
fifo_lock();
if ( fifo_byte_available() > 5 ) {

_fifo_enqueue( (1 >> 8) & 0xFF );
_fifo_enqueue( 1 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_timer >> 8) & 0xFF );
_fifo_enqueue( _instance->id_timer & 0xFF );

// parameter id
union u_id_t {
uint8_t p;
byte bytebuffer[1];
} u_id;
u_id.p = id;
_fifo_enqueue(u_id.bytebuffer[0] & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages SensorBridge::fpmqtt::adc_values
void enqueue_SensorBridge_send_fpmqtt_adc_values(struct SensorBridge_Instance *_instance, uint16_t a0, uint16_t a1, uint16_t a2, uint16_t a3){
fifo_lock();
if ( fifo_byte_available() > 12 ) {

_fifo_enqueue( (94 >> 8) & 0xFF );
_fifo_enqueue( 94 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_fpmqtt >> 8) & 0xFF );
_fifo_enqueue( _instance->id_fpmqtt & 0xFF );

// parameter a0
union u_a0_t {
uint16_t p;
byte bytebuffer[2];
} u_a0;
u_a0.p = a0;
_fifo_enqueue(u_a0.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_a0.bytebuffer[1] & 0xFF );

// parameter a1
union u_a1_t {
uint16_t p;
byte bytebuffer[2];
} u_a1;
u_a1.p = a1;
_fifo_enqueue(u_a1.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_a1.bytebuffer[1] & 0xFF );

// parameter a2
union u_a2_t {
uint16_t p;
byte bytebuffer[2];
} u_a2;
u_a2.p = a2;
_fifo_enqueue(u_a2.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_a2.bytebuffer[1] & 0xFF );

// parameter a3
union u_a3_t {
uint16_t p;
byte bytebuffer[2];
} u_a3;
u_a3.p = a3;
_fifo_enqueue(u_a3.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_a3.bytebuffer[1] & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages SensorBridge::fpmqtt::heartbeat_network
void enqueue_SensorBridge_send_fpmqtt_heartbeat_network(struct SensorBridge_Instance *_instance, bool stable, uint8_t interval){
fifo_lock();
if ( fifo_byte_available() > 6 ) {

_fifo_enqueue( (87 >> 8) & 0xFF );
_fifo_enqueue( 87 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_fpmqtt >> 8) & 0xFF );
_fifo_enqueue( _instance->id_fpmqtt & 0xFF );

// parameter stable
union u_stable_t {
bool p;
byte bytebuffer[1];
} u_stable;
u_stable.p = stable;
_fifo_enqueue(u_stable.bytebuffer[0] & 0xFF );

// parameter interval
union u_interval_t {
uint8_t p;
byte bytebuffer[1];
} u_interval;
u_interval.p = interval;
_fifo_enqueue(u_interval.bytebuffer[0] & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages SensorBridge::fpmqtt::front_panel_hwmonitor
void enqueue_SensorBridge_send_fpmqtt_front_panel_hwmonitor(struct SensorBridge_Instance *_instance, int8_t temp, uint16_t voltage){
fifo_lock();
if ( fifo_byte_available() > 7 ) {

_fifo_enqueue( (85 >> 8) & 0xFF );
_fifo_enqueue( 85 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_fpmqtt >> 8) & 0xFF );
_fifo_enqueue( _instance->id_fpmqtt & 0xFF );

// parameter temp
union u_temp_t {
int8_t p;
byte bytebuffer[1];
} u_temp;
u_temp.p = temp;
_fifo_enqueue(u_temp.bytebuffer[0] & 0xFF );

// parameter voltage
union u_voltage_t {
uint16_t p;
byte bytebuffer[2];
} u_voltage;
u_voltage.p = voltage;
_fifo_enqueue(u_voltage.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_voltage.bytebuffer[1] & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages SensorBridge::clock::timer_start
void enqueue_SensorBridge_send_clock_timer_start(struct SensorBridge_Instance *_instance, uint8_t id, uint16_t time){
fifo_lock();
if ( fifo_byte_available() > 7 ) {

_fifo_enqueue( (2 >> 8) & 0xFF );
_fifo_enqueue( 2 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_clock >> 8) & 0xFF );
_fifo_enqueue( _instance->id_clock & 0xFF );

// parameter id
union u_id_t {
uint8_t p;
byte bytebuffer[1];
} u_id;
u_id.p = id;
_fifo_enqueue(u_id.bytebuffer[0] & 0xFF );

// parameter time
union u_time_t {
uint16_t p;
byte bytebuffer[2];
} u_time;
u_time.p = time;
_fifo_enqueue(u_time.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_time.bytebuffer[1] & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages SensorBridge::clock::timer_cancel
void enqueue_SensorBridge_send_clock_timer_cancel(struct SensorBridge_Instance *_instance, uint8_t id){
fifo_lock();
if ( fifo_byte_available() > 5 ) {

_fifo_enqueue( (3 >> 8) & 0xFF );
_fifo_enqueue( 3 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_clock >> 8) & 0xFF );
_fifo_enqueue( _instance->id_clock & 0xFF );

// parameter id
union u_id_t {
uint8_t p;
byte bytebuffer[1];
} u_id;
u_id.p = id;
_fifo_enqueue(u_id.bytebuffer[0] & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages SensorBridge::netmon::start_netmonitor
void enqueue_SensorBridge_send_netmon_start_netmonitor(struct SensorBridge_Instance *_instance, uint8_t interval){
fifo_lock();
if ( fifo_byte_available() > 5 ) {

_fifo_enqueue( (4 >> 8) & 0xFF );
_fifo_enqueue( 4 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_netmon >> 8) & 0xFF );
_fifo_enqueue( _instance->id_netmon & 0xFF );

// parameter interval
union u_interval_t {
uint8_t p;
byte bytebuffer[1];
} u_interval;
u_interval.p = interval;
_fifo_enqueue(u_interval.bytebuffer[0] & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages SensorBridge::netmon::stop_netmonitor
void enqueue_SensorBridge_send_netmon_stop_netmonitor(struct SensorBridge_Instance *_instance){
fifo_lock();
if ( fifo_byte_available() > 4 ) {

_fifo_enqueue( (5 >> 8) & 0xFF );
_fifo_enqueue( 5 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_netmon >> 8) & 0xFF );
_fifo_enqueue( _instance->id_netmon & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages SensorBridgeAdapterPort_PosixMqttJson_Impl::fpmqtt::set_sensor_rate
void enqueue_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_sensor_rate(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, uint16_t ms){
fifo_lock();
if ( fifo_byte_available() > 6 ) {

_fifo_enqueue( (96 >> 8) & 0xFF );
_fifo_enqueue( 96 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_fpmqtt >> 8) & 0xFF );
_fifo_enqueue( _instance->id_fpmqtt & 0xFF );

// parameter ms
union u_ms_t {
uint16_t p;
byte bytebuffer[2];
} u_ms;
u_ms.p = ms;
_fifo_enqueue(u_ms.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_ms.bytebuffer[1] & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages NetworkMonitor::clock::timer_start
void enqueue_NetworkMonitor_send_clock_timer_start(struct NetworkMonitor_Instance *_instance, uint8_t id, uint16_t time){
fifo_lock();
if ( fifo_byte_available() > 7 ) {

_fifo_enqueue( (2 >> 8) & 0xFF );
_fifo_enqueue( 2 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_clock >> 8) & 0xFF );
_fifo_enqueue( _instance->id_clock & 0xFF );

// parameter id
union u_id_t {
uint8_t p;
byte bytebuffer[1];
} u_id;
u_id.p = id;
_fifo_enqueue(u_id.bytebuffer[0] & 0xFF );

// parameter time
union u_time_t {
uint16_t p;
byte bytebuffer[2];
} u_time;
u_time.p = time;
_fifo_enqueue(u_time.bytebuffer[0] & 0xFF );
_fifo_enqueue(u_time.bytebuffer[1] & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages NetworkMonitor::clock::timer_cancel
void enqueue_NetworkMonitor_send_clock_timer_cancel(struct NetworkMonitor_Instance *_instance, uint8_t id){
fifo_lock();
if ( fifo_byte_available() > 5 ) {

_fifo_enqueue( (3 >> 8) & 0xFF );
_fifo_enqueue( 3 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_clock >> 8) & 0xFF );
_fifo_enqueue( _instance->id_clock & 0xFF );

// parameter id
union u_id_t {
uint8_t p;
byte bytebuffer[1];
} u_id;
u_id.p = id;
_fifo_enqueue(u_id.bytebuffer[0] & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages NetworkMonitor::monitor::network_connected
void enqueue_NetworkMonitor_send_monitor_network_connected(struct NetworkMonitor_Instance *_instance){
fifo_lock();
if ( fifo_byte_available() > 4 ) {

_fifo_enqueue( (6 >> 8) & 0xFF );
_fifo_enqueue( 6 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_monitor >> 8) & 0xFF );
_fifo_enqueue( _instance->id_monitor & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages NetworkMonitor::monitor::network_heartbeat
void enqueue_NetworkMonitor_send_monitor_network_heartbeat(struct NetworkMonitor_Instance *_instance){
fifo_lock();
if ( fifo_byte_available() > 4 ) {

_fifo_enqueue( (7 >> 8) & 0xFF );
_fifo_enqueue( 7 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_monitor >> 8) & 0xFF );
_fifo_enqueue( _instance->id_monitor & 0xFF );
}
fifo_unlock_and_notify();
}
// Enqueue of messages NetworkMonitor::monitor::network_disconnected
void enqueue_NetworkMonitor_send_monitor_network_disconnected(struct NetworkMonitor_Instance *_instance){
fifo_lock();
if ( fifo_byte_available() > 4 ) {

_fifo_enqueue( (8 >> 8) & 0xFF );
_fifo_enqueue( 8 & 0xFF );

// ID of the source port of the instance
_fifo_enqueue( (_instance->id_monitor >> 8) & 0xFF );
_fifo_enqueue( _instance->id_monitor & 0xFF );
}
fifo_unlock_and_notify();
}


//New dispatcher for messages
void dispatch_mqtt_disconnect(uint16_t sender) {
if (sender == bridge_var.id_mqtt) {

}

}

void sync_dispatch_SensorBridge_send_mqtt_mqtt_disconnect(struct SensorBridge_Instance *_instance){
dispatch_mqtt_disconnect(_instance->id_mqtt);
}

//New dispatcher for messages
void dispatch_mqtt_connect(uint16_t sender, char * param_client_id, char * param_host, uint16_t param_portno, bool param_tls) {
if (sender == bridge_var.id_mqtt) {
PosixMQTTAdapter_handle_mqtt_mqtt_connect(&mqttadapter_var, param_client_id, param_host, param_portno, param_tls);

}

}

void sync_dispatch_SensorBridge_send_mqtt_mqtt_connect(struct SensorBridge_Instance *_instance, char * client_id, char * host, uint16_t portno, bool tls){
dispatch_mqtt_connect(_instance->id_mqtt, client_id, host, portno, tls);
}

//New dispatcher for messages
void dispatch_set_sensor_rate(uint16_t sender, uint16_t param_ms) {
if (sender == mqttserializer_var.id_fpmqtt) {
SensorBridge_handle_fpmqtt_set_sensor_rate(&bridge_var, param_ms);

}

}


//New dispatcher for messages
void dispatch_mqtt_set_prefix(uint16_t sender, char * param_prefix) {
if (sender == bridge_var.id_mqtt) {
PosixMQTTAdapter_handle_mqtt_mqtt_set_prefix(&mqttadapter_var, param_prefix);

}

}

void sync_dispatch_SensorBridge_send_mqtt_mqtt_set_prefix(struct SensorBridge_Instance *_instance, char * prefix){
dispatch_mqtt_set_prefix(_instance->id_mqtt, prefix);
}

//New dispatcher for messages
void dispatch_mqtt_topic_subscribed(uint16_t sender) {
if (sender == mqttadapter_var.id_mqtt) {

}

}

void sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_topic_subscribed(struct PosixMQTTAdapter_Instance *_instance){
dispatch_mqtt_topic_subscribed(_instance->id_mqtt);
}

//New dispatcher for messages
void dispatch_mqtt_message_published(uint16_t sender) {
if (sender == mqttadapter_var.id_mqtt) {

}

}

void sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_message_published(struct PosixMQTTAdapter_Instance *_instance){
dispatch_mqtt_message_published(_instance->id_mqtt);
}

//New dispatcher for messages
void dispatch_heartbeat_network(uint16_t sender, bool param_stable, uint8_t param_interval) {
if (sender == bridge_var.id_fpmqtt) {
SensorBridgeAdapterPort_PosixMqttJson_Impl_handle_fpmqtt_heartbeat_network(&mqttserializer_var, param_stable, param_interval);

}

}


//New dispatcher for messages
void dispatch_start_netmonitor(uint16_t sender, uint8_t param_interval) {
if (sender == bridge_var.id_netmon) {
NetworkMonitor_handle_monitor_start_netmonitor(&mon_var, param_interval);

}

}


//New dispatcher for messages
void dispatch_network_heartbeat(uint16_t sender) {
if (sender == mon_var.id_monitor) {
SensorBridge_handle_netmon_network_heartbeat(&bridge_var);

}

}


//New dispatcher for messages
void dispatch_timer_cancel(uint16_t sender, uint8_t param_id) {
if (sender == bridge_var.id_clock) {
TimerPosix_handle_timer_timer_cancel(&t_var, param_id);

}
if (sender == mon_var.id_clock) {
TimerPosix_handle_timer_timer_cancel(&t_var, param_id);

}

}


//New dispatcher for messages
void dispatch_network_disconnected(uint16_t sender) {
if (sender == mon_var.id_monitor) {

}

}


//New dispatcher for messages
void dispatch_mqtt_message(uint16_t sender, char * param_topic, uint8_t * param_payload, uint32_t param_size) {
if (sender == mqttadapter_var.id_mqtt) {
SensorBridgeAdapterPort_PosixMqttJson_Impl_handle_posixmqtt_mqtt_message(&mqttserializer_var, param_topic, param_payload, param_size);

}

}

void sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_message(struct PosixMQTTAdapter_Instance *_instance, char * topic, uint8_t * payload, uint32_t size){
dispatch_mqtt_message(_instance->id_mqtt, topic, payload, size);
}

//New dispatcher for messages
void dispatch_timer_timeout(uint16_t sender, uint8_t param_id) {
if (sender == t_var.id_timer) {
SensorBridge_handle_clock_timer_timeout(&bridge_var, param_id);

}

}


//New dispatcher for messages
void dispatch_front_panel_hwmonitor(uint16_t sender, int8_t param_temp, uint16_t param_voltage) {
if (sender == bridge_var.id_fpmqtt) {
SensorBridgeAdapterPort_PosixMqttJson_Impl_handle_fpmqtt_front_panel_hwmonitor(&mqttserializer_var, param_temp, param_voltage);

}
if (sender == Serial_instance.listener_id) {
SensorBridge_handle_fpserial_front_panel_hwmonitor(&bridge_var, param_temp, param_voltage);

}

}


//New dispatcher for messages
void dispatch_network_connected(uint16_t sender) {
if (sender == mon_var.id_monitor) {

}

}


//New dispatcher for messages
void dispatch_mqtt_disconnected(uint16_t sender) {
if (sender == mqttadapter_var.id_mqtt) {
SensorBridge_handle_mqtt_mqtt_disconnected(&bridge_var);

}

}

void sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_disconnected(struct PosixMQTTAdapter_Instance *_instance){
dispatch_mqtt_disconnected(_instance->id_mqtt);
}

//New dispatcher for messages
void dispatch_adc_values(uint16_t sender, uint16_t param_a0, uint16_t param_a1, uint16_t param_a2, uint16_t param_a3) {
if (sender == bridge_var.id_fpmqtt) {
SensorBridgeAdapterPort_PosixMqttJson_Impl_handle_fpmqtt_adc_values(&mqttserializer_var, param_a0, param_a1, param_a2, param_a3);

}
if (sender == Serial_instance.listener_id) {
SensorBridge_handle_fpserial_adc_values(&bridge_var, param_a0, param_a1, param_a2, param_a3);

}

}


//New dispatcher for messages
void dispatch_mqtt_set_tls_certificates(uint16_t sender, char * param_cafile, char * param_capath, char * param_certfile, char * param_keyfile) {
if (sender == bridge_var.id_mqtt) {
PosixMQTTAdapter_handle_mqtt_mqtt_set_tls_certificates(&mqttadapter_var, param_cafile, param_capath, param_certfile, param_keyfile);

}

}

void sync_dispatch_SensorBridge_send_mqtt_mqtt_set_tls_certificates(struct SensorBridge_Instance *_instance, char * cafile, char * capath, char * certfile, char * keyfile){
dispatch_mqtt_set_tls_certificates(_instance->id_mqtt, cafile, capath, certfile, keyfile);
}

//New dispatcher for messages
void dispatch_mqtt_set_credentials(uint16_t sender, char * param_usr, char * param_pwd) {
if (sender == bridge_var.id_mqtt) {
PosixMQTTAdapter_handle_mqtt_mqtt_set_credentials(&mqttadapter_var, param_usr, param_pwd);

}

}

void sync_dispatch_SensorBridge_send_mqtt_mqtt_set_credentials(struct SensorBridge_Instance *_instance, char * usr, char * pwd){
dispatch_mqtt_set_credentials(_instance->id_mqtt, usr, pwd);
}

//New dispatcher for messages
void dispatch_mqtt_connected(uint16_t sender) {
if (sender == mqttadapter_var.id_mqtt) {
SensorBridgeAdapterPort_PosixMqttJson_Impl_handle_posixmqtt_mqtt_connected(&mqttserializer_var);
SensorBridge_handle_mqtt_mqtt_connected(&bridge_var);

}

}

void sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_connected(struct PosixMQTTAdapter_Instance *_instance){
dispatch_mqtt_connected(_instance->id_mqtt);
}

//New dispatcher for messages
void dispatch_ping_serial(uint16_t sender, uint16_t param_seq) {
if (sender == Serial_instance.listener_id) {
SensorBridge_handle_fpserial_ping_serial(&bridge_var, param_seq);

}

}


//New dispatcher for messages
void dispatch_timer_start(uint16_t sender, uint8_t param_id, uint16_t param_time) {
if (sender == bridge_var.id_clock) {
TimerPosix_handle_timer_timer_start(&t_var, param_id, param_time);

}
if (sender == mon_var.id_clock) {
TimerPosix_handle_timer_timer_start(&t_var, param_id, param_time);

}

}


//New dispatcher for messages
void dispatch_mqtt_error(uint16_t sender) {
if (sender == mqttadapter_var.id_mqtt) {

}

}

void sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_error(struct PosixMQTTAdapter_Instance *_instance){
dispatch_mqtt_error(_instance->id_mqtt);
}

//New dispatcher for messages
void dispatch_stop_netmonitor(uint16_t sender) {
if (sender == bridge_var.id_netmon) {
NetworkMonitor_handle_monitor_stop_netmonitor(&mon_var);

}

}


//New dispatcher for messages
void dispatch_mqtt_publish(uint16_t sender, char * param_topic, uint8_t * param_payload, uint32_t param_size) {
if (sender == mqttserializer_var.id_posixmqtt) {
PosixMQTTAdapter_handle_mqtt_mqtt_publish(&mqttadapter_var, param_topic, param_payload, param_size);

}

}

void sync_dispatch_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, char * topic, uint8_t * payload, uint32_t size){
dispatch_mqtt_publish(_instance->id_posixmqtt, topic, payload, size);
}

//New dispatcher for messages
void dispatch_mqtt_subscribe(uint16_t sender, char * param_topic) {
if (sender == mqttserializer_var.id_posixmqtt) {
PosixMQTTAdapter_handle_mqtt_mqtt_subscribe(&mqttadapter_var, param_topic);

}

}

void sync_dispatch_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, char * topic){
dispatch_mqtt_subscribe(_instance->id_posixmqtt, topic);
}

int processMessageQueue() {
fifo_lock();
while (fifo_empty()) fifo_wait();
uint8_t mbufi = 0;

// Read the code of the next port/message in the queue
uint16_t code = fifo_dequeue() << 8;

code += fifo_dequeue();

// Switch to call the appropriate handler
switch(code) {
case 6:{
byte mbuf[4 - 2];
while (mbufi < (4 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_network_connected = 2;
dispatch_network_connected((mbuf[0] << 8) + mbuf[1] /* instance port*/);
break;
}
case 94:{
byte mbuf[12 - 2];
while (mbufi < (12 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_adc_values = 2;
union u_adc_values_a0_t {
uint16_t p;
byte bytebuffer[2];
} u_adc_values_a0;
u_adc_values_a0.bytebuffer[0] = mbuf[mbufi_adc_values + 0];
u_adc_values_a0.bytebuffer[1] = mbuf[mbufi_adc_values + 1];
mbufi_adc_values += 2;
union u_adc_values_a1_t {
uint16_t p;
byte bytebuffer[2];
} u_adc_values_a1;
u_adc_values_a1.bytebuffer[0] = mbuf[mbufi_adc_values + 0];
u_adc_values_a1.bytebuffer[1] = mbuf[mbufi_adc_values + 1];
mbufi_adc_values += 2;
union u_adc_values_a2_t {
uint16_t p;
byte bytebuffer[2];
} u_adc_values_a2;
u_adc_values_a2.bytebuffer[0] = mbuf[mbufi_adc_values + 0];
u_adc_values_a2.bytebuffer[1] = mbuf[mbufi_adc_values + 1];
mbufi_adc_values += 2;
union u_adc_values_a3_t {
uint16_t p;
byte bytebuffer[2];
} u_adc_values_a3;
u_adc_values_a3.bytebuffer[0] = mbuf[mbufi_adc_values + 0];
u_adc_values_a3.bytebuffer[1] = mbuf[mbufi_adc_values + 1];
mbufi_adc_values += 2;
dispatch_adc_values((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_adc_values_a0.p /* a0 */ ,
 u_adc_values_a1.p /* a1 */ ,
 u_adc_values_a2.p /* a2 */ ,
 u_adc_values_a3.p /* a3 */ );
break;
}
case 96:{
byte mbuf[6 - 2];
while (mbufi < (6 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_set_sensor_rate = 2;
union u_set_sensor_rate_ms_t {
uint16_t p;
byte bytebuffer[2];
} u_set_sensor_rate_ms;
u_set_sensor_rate_ms.bytebuffer[0] = mbuf[mbufi_set_sensor_rate + 0];
u_set_sensor_rate_ms.bytebuffer[1] = mbuf[mbufi_set_sensor_rate + 1];
mbufi_set_sensor_rate += 2;
dispatch_set_sensor_rate((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_set_sensor_rate_ms.p /* ms */ );
break;
}
case 80:{
byte mbuf[6 - 2];
while (mbufi < (6 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_ping_serial = 2;
union u_ping_serial_seq_t {
uint16_t p;
byte bytebuffer[2];
} u_ping_serial_seq;
u_ping_serial_seq.bytebuffer[0] = mbuf[mbufi_ping_serial + 0];
u_ping_serial_seq.bytebuffer[1] = mbuf[mbufi_ping_serial + 1];
mbufi_ping_serial += 2;
dispatch_ping_serial((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_ping_serial_seq.p /* seq */ );
break;
}
case 87:{
byte mbuf[6 - 2];
while (mbufi < (6 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_heartbeat_network = 2;
union u_heartbeat_network_stable_t {
bool p;
byte bytebuffer[1];
} u_heartbeat_network_stable;
u_heartbeat_network_stable.bytebuffer[0] = mbuf[mbufi_heartbeat_network + 0];
mbufi_heartbeat_network += 1;
union u_heartbeat_network_interval_t {
uint8_t p;
byte bytebuffer[1];
} u_heartbeat_network_interval;
u_heartbeat_network_interval.bytebuffer[0] = mbuf[mbufi_heartbeat_network + 0];
mbufi_heartbeat_network += 1;
dispatch_heartbeat_network((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_heartbeat_network_stable.p /* stable */ ,
 u_heartbeat_network_interval.p /* interval */ );
break;
}
case 4:{
byte mbuf[5 - 2];
while (mbufi < (5 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_start_netmonitor = 2;
union u_start_netmonitor_interval_t {
uint8_t p;
byte bytebuffer[1];
} u_start_netmonitor_interval;
u_start_netmonitor_interval.bytebuffer[0] = mbuf[mbufi_start_netmonitor + 0];
mbufi_start_netmonitor += 1;
dispatch_start_netmonitor((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_start_netmonitor_interval.p /* interval */ );
break;
}
case 2:{
byte mbuf[7 - 2];
while (mbufi < (7 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_timer_start = 2;
union u_timer_start_id_t {
uint8_t p;
byte bytebuffer[1];
} u_timer_start_id;
u_timer_start_id.bytebuffer[0] = mbuf[mbufi_timer_start + 0];
mbufi_timer_start += 1;
union u_timer_start_time_t {
uint16_t p;
byte bytebuffer[2];
} u_timer_start_time;
u_timer_start_time.bytebuffer[0] = mbuf[mbufi_timer_start + 0];
u_timer_start_time.bytebuffer[1] = mbuf[mbufi_timer_start + 1];
mbufi_timer_start += 2;
dispatch_timer_start((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_timer_start_id.p /* id */ ,
 u_timer_start_time.p /* time */ );
break;
}
case 7:{
byte mbuf[4 - 2];
while (mbufi < (4 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_network_heartbeat = 2;
dispatch_network_heartbeat((mbuf[0] << 8) + mbuf[1] /* instance port*/);
break;
}
case 3:{
byte mbuf[5 - 2];
while (mbufi < (5 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_timer_cancel = 2;
union u_timer_cancel_id_t {
uint8_t p;
byte bytebuffer[1];
} u_timer_cancel_id;
u_timer_cancel_id.bytebuffer[0] = mbuf[mbufi_timer_cancel + 0];
mbufi_timer_cancel += 1;
dispatch_timer_cancel((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_timer_cancel_id.p /* id */ );
break;
}
case 5:{
byte mbuf[4 - 2];
while (mbufi < (4 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_stop_netmonitor = 2;
dispatch_stop_netmonitor((mbuf[0] << 8) + mbuf[1] /* instance port*/);
break;
}
case 8:{
byte mbuf[4 - 2];
while (mbufi < (4 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_network_disconnected = 2;
dispatch_network_disconnected((mbuf[0] << 8) + mbuf[1] /* instance port*/);
break;
}
case 1:{
byte mbuf[5 - 2];
while (mbufi < (5 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_timer_timeout = 2;
union u_timer_timeout_id_t {
uint8_t p;
byte bytebuffer[1];
} u_timer_timeout_id;
u_timer_timeout_id.bytebuffer[0] = mbuf[mbufi_timer_timeout + 0];
mbufi_timer_timeout += 1;
dispatch_timer_timeout((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_timer_timeout_id.p /* id */ );
break;
}
case 85:{
byte mbuf[7 - 2];
while (mbufi < (7 - 2)) mbuf[mbufi++] = fifo_dequeue();
fifo_unlock();
uint8_t mbufi_front_panel_hwmonitor = 2;
union u_front_panel_hwmonitor_temp_t {
int8_t p;
byte bytebuffer[1];
} u_front_panel_hwmonitor_temp;
u_front_panel_hwmonitor_temp.bytebuffer[0] = mbuf[mbufi_front_panel_hwmonitor + 0];
mbufi_front_panel_hwmonitor += 1;
union u_front_panel_hwmonitor_voltage_t {
uint16_t p;
byte bytebuffer[2];
} u_front_panel_hwmonitor_voltage;
u_front_panel_hwmonitor_voltage.bytebuffer[0] = mbuf[mbufi_front_panel_hwmonitor + 0];
u_front_panel_hwmonitor_voltage.bytebuffer[1] = mbuf[mbufi_front_panel_hwmonitor + 1];
mbufi_front_panel_hwmonitor += 2;
dispatch_front_panel_hwmonitor((mbuf[0] << 8) + mbuf[1] /* instance port*/,
 u_front_panel_hwmonitor_temp.p /* temp */ ,
 u_front_panel_hwmonitor_voltage.p /* voltage */ );
break;
}
}
return 1;
}

void forward_SensorBridge_send_fpserial_pong_serial(struct SensorBridge_Instance *_instance, uint16_t seq){
if(_instance->id_fpserial == bridge_var.id_fpserial) {
forward_Serial_SensorBridge_send_fpserial_pong_serial(_instance, seq);
}
}
void forward_SensorBridge_send_fpserial_set_sensor_rate(struct SensorBridge_Instance *_instance, uint16_t ms){
if(_instance->id_fpserial == bridge_var.id_fpserial) {
forward_Serial_SensorBridge_send_fpserial_set_sensor_rate(_instance, ms);
}
}
void forward_SensorBridge_send_fpserial_heartbeat_network(struct SensorBridge_Instance *_instance, bool stable, uint8_t interval){
if(_instance->id_fpserial == bridge_var.id_fpserial) {
forward_Serial_SensorBridge_send_fpserial_heartbeat_network(_instance, stable, interval);
}
}
void forward_SensorBridge_send_fpserial_heartbeat_gateway(struct SensorBridge_Instance *_instance, uint8_t interval){
if(_instance->id_fpserial == bridge_var.id_fpserial) {
forward_Serial_SensorBridge_send_fpserial_heartbeat_gateway(_instance, interval);
}
}

//external Message enqueue
void externalMessageEnqueue(uint8_t * msg, uint8_t msgSize, uint16_t listener_id) {
if ((msgSize >= 2) && (msg != NULL)) {
uint8_t msgSizeOK = 0;
switch(msg[0] * 256 + msg[1]) {
case 94:
if(msgSize == 10) {
msgSizeOK = 1;}
break;
case 85:
if(msgSize == 5) {
msgSizeOK = 1;}
break;
case 80:
if(msgSize == 4) {
msgSizeOK = 1;}
break;
}

if(msgSizeOK == 1) {
fifo_lock();
if ( fifo_byte_available() > (msgSize + 2) ) {
	uint8_t i;
	for (i = 0; i < 2; i++) {
		_fifo_enqueue(msg[i]);
	}
	_fifo_enqueue((listener_id >> 8) & 0xFF);
	_fifo_enqueue(listener_id & 0xFF);
	for (i = 2; i < msgSize; i++) {
		_fifo_enqueue(msg[i]);
	}
}
fifo_unlock_and_notify();
}
}
}

void initialize_configuration_SensorBridge() {
// Initialize connectors
register_external_SensorBridge_send_fpserial_pong_serial_listener(&forward_SensorBridge_send_fpserial_pong_serial);
register_external_SensorBridge_send_fpserial_heartbeat_gateway_listener(&forward_SensorBridge_send_fpserial_heartbeat_gateway);
register_external_SensorBridge_send_fpserial_heartbeat_network_listener(&forward_SensorBridge_send_fpserial_heartbeat_network);
register_external_SensorBridge_send_fpserial_set_sensor_rate_listener(&forward_SensorBridge_send_fpserial_set_sensor_rate);
register_TimerPosix_send_timer_timer_timeout_listener(&enqueue_TimerPosix_send_timer_timer_timeout);
register_PosixMQTTAdapter_send_mqtt_mqtt_disconnected_listener(&sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_disconnected);
register_PosixMQTTAdapter_send_mqtt_mqtt_message_published_listener(&sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_message_published);
register_PosixMQTTAdapter_send_mqtt_mqtt_error_listener(&sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_error);
register_PosixMQTTAdapter_send_mqtt_mqtt_message_listener(&sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_message);
register_PosixMQTTAdapter_send_mqtt_mqtt_connected_listener(&sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_connected);
register_PosixMQTTAdapter_send_mqtt_mqtt_topic_subscribed_listener(&sync_dispatch_PosixMQTTAdapter_send_mqtt_mqtt_topic_subscribed);
register_SensorBridge_send_fpmqtt_adc_values_listener(&enqueue_SensorBridge_send_fpmqtt_adc_values);
register_SensorBridge_send_fpmqtt_heartbeat_network_listener(&enqueue_SensorBridge_send_fpmqtt_heartbeat_network);
register_SensorBridge_send_fpmqtt_front_panel_hwmonitor_listener(&enqueue_SensorBridge_send_fpmqtt_front_panel_hwmonitor);
register_SensorBridge_send_mqtt_mqtt_disconnect_listener(&sync_dispatch_SensorBridge_send_mqtt_mqtt_disconnect);
register_SensorBridge_send_mqtt_mqtt_connect_listener(&sync_dispatch_SensorBridge_send_mqtt_mqtt_connect);
register_SensorBridge_send_mqtt_mqtt_set_prefix_listener(&sync_dispatch_SensorBridge_send_mqtt_mqtt_set_prefix);
register_SensorBridge_send_mqtt_mqtt_set_tls_certificates_listener(&sync_dispatch_SensorBridge_send_mqtt_mqtt_set_tls_certificates);
register_SensorBridge_send_mqtt_mqtt_set_credentials_listener(&sync_dispatch_SensorBridge_send_mqtt_mqtt_set_credentials);
register_SensorBridge_send_clock_timer_start_listener(&enqueue_SensorBridge_send_clock_timer_start);
register_SensorBridge_send_clock_timer_cancel_listener(&enqueue_SensorBridge_send_clock_timer_cancel);
register_SensorBridge_send_netmon_start_netmonitor_listener(&enqueue_SensorBridge_send_netmon_start_netmonitor);
register_SensorBridge_send_netmon_stop_netmonitor_listener(&enqueue_SensorBridge_send_netmon_stop_netmonitor);
register_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_sensor_rate_listener(&enqueue_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_sensor_rate);
register_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(&sync_dispatch_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish);
register_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(&sync_dispatch_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe);
register_NetworkMonitor_send_clock_timer_start_listener(&enqueue_NetworkMonitor_send_clock_timer_start);
register_NetworkMonitor_send_clock_timer_cancel_listener(&enqueue_NetworkMonitor_send_clock_timer_cancel);
register_NetworkMonitor_send_monitor_network_connected_listener(&enqueue_NetworkMonitor_send_monitor_network_connected);
register_NetworkMonitor_send_monitor_network_heartbeat_listener(&enqueue_NetworkMonitor_send_monitor_network_heartbeat);
register_NetworkMonitor_send_monitor_network_disconnected_listener(&enqueue_NetworkMonitor_send_monitor_network_disconnected);

// Init the ID, state variables and properties for external connector Serial

// Network Initialization

Serial_instance.listener_id = add_instance(&Serial_instance);

//Serial:
Serial_setup();
pthread_t thread_Serial;
pthread_create( &thread_Serial, NULL, Serial_start_receiver_process, NULL);

// End Network Initialization

// Init the ID, state variables and properties for instance t
t_var.active = true;
t_var.id_timer = add_instance( (void*) &t_var);
t_var.TimerPosix_SoftTimer_State = TIMERPOSIX_SOFTTIMER_DEFAULT_STATE;
t_var.TimerPosix_SOFT_TIMER_PERIOD_var = 50;
t_var.TimerPosix_NB_SOFT_TIMERS_var = NB_SOFT_TIMERS;

TimerPosix_SoftTimer_OnEntry(TIMERPOSIX_SOFTTIMER_STATE, &t_var);
// Init the ID, state variables and properties for instance mqttadapter
mqttadapter_var.active = true;
mqttadapter_var.id_mqtt = add_instance( (void*) &mqttadapter_var);
mqttadapter_var.PosixMQTTAdapter_MQTTAdapterThing_State = POSIXMQTTADAPTER_MQTTADAPTERTHING_START_STATE;
mqttadapter_var.AbstractMQTTAdapter_enable_tls_var = 0;
mqttadapter_var.PosixMQTTAdapter_debug_log_var = 0;
mqttadapter_var.AbstractMQTTAdapter_enable_tls_certificates_var = 0;
mqttadapter_var.PosixMQTTAdapter_client_var = NULL;
mqttadapter_var.AbstractMQTTAdapter_enable_user_credentials_var = 0;

PosixMQTTAdapter_MQTTAdapterThing_OnEntry(POSIXMQTTADAPTER_MQTTADAPTERTHING_STATE, &mqttadapter_var);
// Init the ID, state variables and properties for instance mon
mon_var.active = true;
mon_var.id_clock = add_instance( (void*) &mon_var);
mon_var.id_monitor = add_instance( (void*) &mon_var);
mon_var.NetworkMonitor_NetworkMonitorSC_State = NETWORKMONITOR_NETWORKMONITORSC_IDLE_STATE;
mon_var.NetworkMonitor_timer_id_var = 2;
mon_var.NetworkMonitor_delay_var = 5;
mon_var.NetworkMonitor_stoploop_var = 0;

NetworkMonitor_NetworkMonitorSC_OnEntry(NETWORKMONITOR_NETWORKMONITORSC_STATE, &mon_var);
// Init the ID, state variables and properties for instance mqttserializer
mqttserializer_var.active = true;
mqttserializer_var.id_fpmqtt = add_instance( (void*) &mqttserializer_var);
mqttserializer_var.id_posixmqtt = add_instance( (void*) &mqttserializer_var);
mqttserializer_var.SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_State = SENSORBRIDGEADAPTERPORT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_RUNNING_STATE;
mqttserializer_var.SensorBridgeAdapterPort_PosixMqttJson_Impl_mqtt_topic_name_var = "TelluGW";

SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_OnEntry(SENSORBRIDGEADAPTERPORT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_STATE, &mqttserializer_var);
// Init the ID, state variables and properties for instance bridge
bridge_var.active = true;
bridge_var.id_fpmqtt = add_instance( (void*) &bridge_var);
bridge_var.id_fpserial = add_instance( (void*) &bridge_var);
bridge_var.id_mqtt = add_instance( (void*) &bridge_var);
bridge_var.id_clock = add_instance( (void*) &bridge_var);
bridge_var.id_netmon = add_instance( (void*) &bridge_var);
bridge_var.SensorBridge_FrontPanelBridgeSC_State = SENSORBRIDGE_FRONTPANELBRIDGESC_BRIDGING_STATE;
bridge_var.SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State = SENSORBRIDGE_FRONTPANELBRIDGESC_LOCALMQTTMONITOR_DISCONNECTED_STATE;
bridge_var.SensorBridge_FrontPanelBridgeSC_NetworkMonitor_State = SENSORBRIDGE_FRONTPANELBRIDGESC_NETWORKMONITOR_ACTIVE_STATE;
bridge_var.SensorBridge_client_id_var = "FrontPanelBridge";
bridge_var.SensorBridge_broker_host_var = "localhost";
bridge_var.SensorBridge_build_version_var = "enact-1.0";
bridge_var.SensorBridge_broker_port_var = 1883;
bridge_var.SensorBridge_timer_id_var = 1;

SensorBridge_FrontPanelBridgeSC_OnEntry(SENSORBRIDGE_FRONTPANELBRIDGESC_STATE, &bridge_var);
}




void term(int signum)
{
    

    fflush(stdout);
    fflush(stderr);
    exit(signum);
}


int main(int argc, char *argv[]) {
    struct sigaction action;
    memset(&action, 0, sizeof(struct sigaction));
    action.sa_handler = term;
    sigaction(SIGINT, &action, NULL);
    sigaction(SIGTERM, &action, NULL);

    init_runtime();
    
    initialize_configuration_SensorBridge();

    while (1) {
        
// Network Listener// End Network Listener

int emptyEventConsumed = 1;
while (emptyEventConsumed != 0) {
emptyEventConsumed = 0;
}

        processMessageQueue();
  }
}