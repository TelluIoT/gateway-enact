/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *           Header for Thing NetworkMonitor
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#ifndef NetworkMonitor_H_
#define NetworkMonitor_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "thingml_typedefs.h"

/*****************************************************************************
 * Headers for type : NetworkMonitor
 *****************************************************************************/


// BEGIN: Code from the c_header annotation NetworkMonitor

#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

// END: Code from the c_header annotation NetworkMonitor

// Definition of the instance struct:
struct NetworkMonitor_Instance {

// Instances of different sessions
bool active;
// Variables for the ID of the ports of the instance
uint16_t id_clock;
uint16_t id_monitor;
// Variables for the current instance state
int NetworkMonitor_NetworkMonitorSC_State;
// Variables for the properties of the instance
uint8_t NetworkMonitor_timer_id_var;
uint8_t NetworkMonitor_delay_var;
bool NetworkMonitor_stoploop_var;

};
// Declaration of prototypes outgoing messages :
void NetworkMonitor_NetworkMonitorSC_OnEntry(int state, struct NetworkMonitor_Instance *_instance);
void NetworkMonitor_handle_monitor_start_netmonitor(struct NetworkMonitor_Instance *_instance, uint8_t interval);
void NetworkMonitor_handle_monitor_stop_netmonitor(struct NetworkMonitor_Instance *_instance);
// Declaration of callbacks for incoming messages:
void register_NetworkMonitor_send_clock_timer_start_listener(void (*_listener)(struct NetworkMonitor_Instance *, uint8_t, uint16_t));
void register_external_NetworkMonitor_send_clock_timer_start_listener(void (*_listener)(struct NetworkMonitor_Instance *, uint8_t, uint16_t));
void register_NetworkMonitor_send_clock_timer_cancel_listener(void (*_listener)(struct NetworkMonitor_Instance *, uint8_t));
void register_external_NetworkMonitor_send_clock_timer_cancel_listener(void (*_listener)(struct NetworkMonitor_Instance *, uint8_t));
void register_NetworkMonitor_send_monitor_network_heartbeat_listener(void (*_listener)(struct NetworkMonitor_Instance *));
void register_external_NetworkMonitor_send_monitor_network_heartbeat_listener(void (*_listener)(struct NetworkMonitor_Instance *));
void register_NetworkMonitor_send_monitor_network_connected_listener(void (*_listener)(struct NetworkMonitor_Instance *));
void register_external_NetworkMonitor_send_monitor_network_connected_listener(void (*_listener)(struct NetworkMonitor_Instance *));
void register_NetworkMonitor_send_monitor_network_disconnected_listener(void (*_listener)(struct NetworkMonitor_Instance *));
void register_external_NetworkMonitor_send_monitor_network_disconnected_listener(void (*_listener)(struct NetworkMonitor_Instance *));

// Definition of the states:
#define NETWORKMONITOR_NETWORKMONITORSC_ACTIVE_STATE 0
#define NETWORKMONITOR_NETWORKMONITORSC_STATE 1
#define NETWORKMONITOR_NETWORKMONITORSC_IDLE_STATE 2



#ifdef __cplusplus
}
#endif

#endif //NetworkMonitor_H_
