/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *           Header for Thing SensorBridgeAdapterPort_PosixMqttJson_Impl
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#ifndef SensorBridgeAdapterPort_PosixMqttJson_Impl_H_
#define SensorBridgeAdapterPort_PosixMqttJson_Impl_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "thingml_typedefs.h"

/*****************************************************************************
 * Headers for type : SensorBridgeAdapterPort_PosixMqttJson_Impl
 *****************************************************************************/


// BEGIN: Code from the c_header annotation SensorBridgeAdapterPort_PosixMqttJson_Impl
#include "jsmn.h"
// END: Code from the c_header annotation SensorBridgeAdapterPort_PosixMqttJson_Impl

// Definition of the instance struct:
struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance {

// Instances of different sessions
bool active;
// Variables for the ID of the ports of the instance
uint16_t id_fpmqtt;
uint16_t id_posixmqtt;
// Variables for the current instance state
int SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_State;
// Variables for the properties of the instance
char * SensorBridgeAdapterPort_PosixMqttJson_Impl_mqtt_topic_name_var;

};
// Declaration of prototypes outgoing messages :
void SensorBridgeAdapterPort_PosixMqttJson_Impl_PosixMQTTJSonSC_OnEntry(int state, struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance);
void SensorBridgeAdapterPort_PosixMqttJson_Impl_handle_fpmqtt_adc_values(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, uint16_t a0, uint16_t a1, uint16_t a2, uint16_t a3);
void SensorBridgeAdapterPort_PosixMqttJson_Impl_handle_fpmqtt_heartbeat_network(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, bool stable, uint8_t interval);
void SensorBridgeAdapterPort_PosixMqttJson_Impl_handle_fpmqtt_front_panel_hwmonitor(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, int8_t temp, uint16_t voltage);
void SensorBridgeAdapterPort_PosixMqttJson_Impl_handle_posixmqtt_mqtt_message(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance, char * topic, uint8_t * payload, uint32_t size);
void SensorBridgeAdapterPort_PosixMqttJson_Impl_handle_posixmqtt_mqtt_connected(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *_instance);
// Declaration of callbacks for incoming messages:
void register_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_sensor_rate_listener(void (*_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, uint16_t));
void register_external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_fpmqtt_set_sensor_rate_listener(void (*_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, uint16_t));
void register_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(void (*_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t));
void register_external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(void (*_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t));
void register_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(void (*_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, char *));
void register_external_SensorBridgeAdapterPort_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(void (*_listener)(struct SensorBridgeAdapterPort_PosixMqttJson_Impl_Instance *, char *));

// Definition of the states:
#define SENSORBRIDGEADAPTERPORT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_STATE 0
#define SENSORBRIDGEADAPTERPORT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_RUNNING_STATE 1



#ifdef __cplusplus
}
#endif

#endif //SensorBridgeAdapterPort_PosixMqttJson_Impl_H_
