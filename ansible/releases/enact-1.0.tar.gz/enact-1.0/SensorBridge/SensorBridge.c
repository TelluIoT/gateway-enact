/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *        Implementation for Thing SensorBridge
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#include "SensorBridge.h"

/*****************************************************************************
 * Implementation for type : SensorBridge
 *****************************************************************************/

// Declaration of prototypes:
//Prototypes: State Machine
void SensorBridge_FrontPanelBridgeSC_OnExit(int state, struct SensorBridge_Instance *_instance);
//Prototypes: Message Sending
void SensorBridge_send_fpmqtt_front_panel_hwmonitor(struct SensorBridge_Instance *_instance, int8_t temp, uint16_t voltage);
void SensorBridge_send_fpmqtt_heartbeat_network(struct SensorBridge_Instance *_instance, bool stable, uint8_t interval);
void SensorBridge_send_fpmqtt_adc_values(struct SensorBridge_Instance *_instance, uint16_t a0, uint16_t a1, uint16_t a2, uint16_t a3);
void SensorBridge_send_fpserial_pong_serial(struct SensorBridge_Instance *_instance, uint16_t seq);
void SensorBridge_send_fpserial_heartbeat_gateway(struct SensorBridge_Instance *_instance, uint8_t interval);
void SensorBridge_send_fpserial_heartbeat_network(struct SensorBridge_Instance *_instance, bool stable, uint8_t interval);
void SensorBridge_send_fpserial_set_sensor_rate(struct SensorBridge_Instance *_instance, uint16_t ms);
void SensorBridge_send_mqtt_mqtt_connect(struct SensorBridge_Instance *_instance, char * client_id, char * host, uint16_t portno, bool tls);
void SensorBridge_send_mqtt_mqtt_disconnect(struct SensorBridge_Instance *_instance);
void SensorBridge_send_mqtt_mqtt_set_credentials(struct SensorBridge_Instance *_instance, char * usr, char * pwd);
void SensorBridge_send_mqtt_mqtt_set_tls_certificates(struct SensorBridge_Instance *_instance, char * cafile, char * capath, char * certfile, char * keyfile);
void SensorBridge_send_mqtt_mqtt_set_prefix(struct SensorBridge_Instance *_instance, char * prefix);
void SensorBridge_send_clock_timer_start(struct SensorBridge_Instance *_instance, uint8_t id, uint16_t time);
void SensorBridge_send_clock_timer_cancel(struct SensorBridge_Instance *_instance, uint8_t id);
void SensorBridge_send_netmon_start_netmonitor(struct SensorBridge_Instance *_instance, uint8_t interval);
void SensorBridge_send_netmon_stop_netmonitor(struct SensorBridge_Instance *_instance);
//Prototypes: Function
// Declaration of functions:

// Sessions functionss:


// On Entry Actions:
void SensorBridge_FrontPanelBridgeSC_OnEntry(int state, struct SensorBridge_Instance *_instance) {
switch(state) {
case SENSORBRIDGE_FRONTPANELBRIDGESC_STATE:{
_instance->SensorBridge_FrontPanelBridgeSC_State = SENSORBRIDGE_FRONTPANELBRIDGESC_BRIDGING_STATE;
_instance->SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State = SENSORBRIDGE_FRONTPANELBRIDGESC_LOCALMQTTMONITOR_DISCONNECTED_STATE;
_instance->SensorBridge_FrontPanelBridgeSC_NetworkMonitor_State = SENSORBRIDGE_FRONTPANELBRIDGESC_NETWORKMONITOR_ACTIVE_STATE;
SensorBridge_send_mqtt_mqtt_connect(_instance, _instance->SensorBridge_client_id_var, _instance->SensorBridge_broker_host_var, _instance->SensorBridge_broker_port_var, 0);
SensorBridge_FrontPanelBridgeSC_OnEntry(_instance->SensorBridge_FrontPanelBridgeSC_State, _instance);
SensorBridge_FrontPanelBridgeSC_OnEntry(_instance->SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State, _instance);
SensorBridge_FrontPanelBridgeSC_OnEntry(_instance->SensorBridge_FrontPanelBridgeSC_NetworkMonitor_State, _instance);
break;
}
case SENSORBRIDGE_FRONTPANELBRIDGESC_LOCALMQTTMONITOR_DISCONNECTED_STATE:{
break;
}
case SENSORBRIDGE_FRONTPANELBRIDGESC_BRIDGING_STATE:{
break;
}
case SENSORBRIDGE_FRONTPANELBRIDGESC_LOCALMQTTMONITOR_CONNECTED_STATE:{
SensorBridge_send_fpserial_heartbeat_gateway(_instance, 1);
SensorBridge_send_clock_timer_start(_instance, _instance->SensorBridge_timer_id_var, 800);
break;
}
case SENSORBRIDGE_FRONTPANELBRIDGESC_NETWORKMONITOR_ACTIVE_STATE:{
SensorBridge_send_netmon_start_netmonitor(_instance, 5);
break;
}
default: break;
}
}

// On Exit Actions:
void SensorBridge_FrontPanelBridgeSC_OnExit(int state, struct SensorBridge_Instance *_instance) {
switch(state) {
case SENSORBRIDGE_FRONTPANELBRIDGESC_STATE:{
SensorBridge_FrontPanelBridgeSC_OnExit(_instance->SensorBridge_FrontPanelBridgeSC_State, _instance);
SensorBridge_FrontPanelBridgeSC_OnExit(_instance->SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State, _instance);
SensorBridge_FrontPanelBridgeSC_OnExit(_instance->SensorBridge_FrontPanelBridgeSC_NetworkMonitor_State, _instance);
break;}
case SENSORBRIDGE_FRONTPANELBRIDGESC_LOCALMQTTMONITOR_DISCONNECTED_STATE:{
break;}
case SENSORBRIDGE_FRONTPANELBRIDGESC_BRIDGING_STATE:{
break;}
case SENSORBRIDGE_FRONTPANELBRIDGESC_LOCALMQTTMONITOR_CONNECTED_STATE:{
break;}
case SENSORBRIDGE_FRONTPANELBRIDGESC_NETWORKMONITOR_ACTIVE_STATE:{
break;}
default: break;
}
}

// Event Handlers for incoming messages:
void SensorBridge_handle_netmon_network_heartbeat(struct SensorBridge_Instance *_instance) {
if(!(_instance->active)) return;
//Region FrontPanelBridgeSC
uint8_t SensorBridge_FrontPanelBridgeSC_State_event_consumed = 0;
//End Region FrontPanelBridgeSC
//Region LocalMQTTMonitor
uint8_t SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State_event_consumed = 0;
//End Region LocalMQTTMonitor
//Region NetworkMonitor
uint8_t SensorBridge_FrontPanelBridgeSC_NetworkMonitor_State_event_consumed = 0;
if (_instance->SensorBridge_FrontPanelBridgeSC_NetworkMonitor_State == SENSORBRIDGE_FRONTPANELBRIDGESC_NETWORKMONITOR_ACTIVE_STATE) {
if (SensorBridge_FrontPanelBridgeSC_NetworkMonitor_State_event_consumed == 0 && 1) {
SensorBridge_send_fpserial_heartbeat_network(_instance, 1, 6);
SensorBridge_send_fpmqtt_heartbeat_network(_instance, 1, 6);
SensorBridge_FrontPanelBridgeSC_NetworkMonitor_State_event_consumed = 1;
}
}
//End Region NetworkMonitor
//End dsregion FrontPanelBridgeSC
//Session list: 
}
void SensorBridge_handle_clock_timer_timeout(struct SensorBridge_Instance *_instance, uint8_t id) {
if(!(_instance->active)) return;
//Region FrontPanelBridgeSC
uint8_t SensorBridge_FrontPanelBridgeSC_State_event_consumed = 0;
//End Region FrontPanelBridgeSC
//Region LocalMQTTMonitor
uint8_t SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State_event_consumed = 0;
if (_instance->SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State == SENSORBRIDGE_FRONTPANELBRIDGESC_LOCALMQTTMONITOR_CONNECTED_STATE) {
if (SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State_event_consumed == 0 && id == _instance->SensorBridge_timer_id_var) {
SensorBridge_FrontPanelBridgeSC_OnExit(SENSORBRIDGE_FRONTPANELBRIDGESC_LOCALMQTTMONITOR_CONNECTED_STATE, _instance);
_instance->SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State = SENSORBRIDGE_FRONTPANELBRIDGESC_LOCALMQTTMONITOR_CONNECTED_STATE;
SensorBridge_FrontPanelBridgeSC_OnEntry(SENSORBRIDGE_FRONTPANELBRIDGESC_LOCALMQTTMONITOR_CONNECTED_STATE, _instance);
SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State_event_consumed = 1;
}
}
//End Region LocalMQTTMonitor
//Region NetworkMonitor
uint8_t SensorBridge_FrontPanelBridgeSC_NetworkMonitor_State_event_consumed = 0;
//End Region NetworkMonitor
//End dsregion FrontPanelBridgeSC
//Session list: 
}
void SensorBridge_handle_mqtt_mqtt_disconnected(struct SensorBridge_Instance *_instance) {
if(!(_instance->active)) return;
//Region FrontPanelBridgeSC
uint8_t SensorBridge_FrontPanelBridgeSC_State_event_consumed = 0;
//End Region FrontPanelBridgeSC
//Region LocalMQTTMonitor
uint8_t SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State_event_consumed = 0;
if (_instance->SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State == SENSORBRIDGE_FRONTPANELBRIDGESC_LOCALMQTTMONITOR_CONNECTED_STATE) {
if (SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State_event_consumed == 0 && 1) {
SensorBridge_FrontPanelBridgeSC_OnExit(SENSORBRIDGE_FRONTPANELBRIDGESC_LOCALMQTTMONITOR_CONNECTED_STATE, _instance);
_instance->SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State = SENSORBRIDGE_FRONTPANELBRIDGESC_LOCALMQTTMONITOR_DISCONNECTED_STATE;
SensorBridge_FrontPanelBridgeSC_OnEntry(SENSORBRIDGE_FRONTPANELBRIDGESC_LOCALMQTTMONITOR_DISCONNECTED_STATE, _instance);
SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State_event_consumed = 1;
}
}
//End Region LocalMQTTMonitor
//Region NetworkMonitor
uint8_t SensorBridge_FrontPanelBridgeSC_NetworkMonitor_State_event_consumed = 0;
//End Region NetworkMonitor
//End dsregion FrontPanelBridgeSC
//Session list: 
}
void SensorBridge_handle_mqtt_mqtt_connected(struct SensorBridge_Instance *_instance) {
if(!(_instance->active)) return;
//Region FrontPanelBridgeSC
uint8_t SensorBridge_FrontPanelBridgeSC_State_event_consumed = 0;
//End Region FrontPanelBridgeSC
//Region LocalMQTTMonitor
uint8_t SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State_event_consumed = 0;
if (_instance->SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State == SENSORBRIDGE_FRONTPANELBRIDGESC_LOCALMQTTMONITOR_DISCONNECTED_STATE) {
if (SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State_event_consumed == 0 && 1) {
SensorBridge_FrontPanelBridgeSC_OnExit(SENSORBRIDGE_FRONTPANELBRIDGESC_LOCALMQTTMONITOR_DISCONNECTED_STATE, _instance);
_instance->SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State = SENSORBRIDGE_FRONTPANELBRIDGESC_LOCALMQTTMONITOR_CONNECTED_STATE;
SensorBridge_FrontPanelBridgeSC_OnEntry(SENSORBRIDGE_FRONTPANELBRIDGESC_LOCALMQTTMONITOR_CONNECTED_STATE, _instance);
SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State_event_consumed = 1;
}
}
//End Region LocalMQTTMonitor
//Region NetworkMonitor
uint8_t SensorBridge_FrontPanelBridgeSC_NetworkMonitor_State_event_consumed = 0;
//End Region NetworkMonitor
//End dsregion FrontPanelBridgeSC
//Session list: 
}
void SensorBridge_handle_fpserial_adc_values(struct SensorBridge_Instance *_instance, uint16_t a0, uint16_t a1, uint16_t a2, uint16_t a3) {
if(!(_instance->active)) return;
//Region FrontPanelBridgeSC
uint8_t SensorBridge_FrontPanelBridgeSC_State_event_consumed = 0;
if (_instance->SensorBridge_FrontPanelBridgeSC_State == SENSORBRIDGE_FRONTPANELBRIDGESC_BRIDGING_STATE) {
if (SensorBridge_FrontPanelBridgeSC_State_event_consumed == 0 && 1) {
SensorBridge_send_fpmqtt_adc_values(_instance, a0, a1, a2, a3);
SensorBridge_FrontPanelBridgeSC_State_event_consumed = 1;
}
}
//End Region FrontPanelBridgeSC
//Region LocalMQTTMonitor
uint8_t SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State_event_consumed = 0;
//End Region LocalMQTTMonitor
//Region NetworkMonitor
uint8_t SensorBridge_FrontPanelBridgeSC_NetworkMonitor_State_event_consumed = 0;
//End Region NetworkMonitor
//End dsregion FrontPanelBridgeSC
//Session list: 
}
void SensorBridge_handle_fpserial_front_panel_hwmonitor(struct SensorBridge_Instance *_instance, int8_t temp, uint16_t voltage) {
if(!(_instance->active)) return;
//Region FrontPanelBridgeSC
uint8_t SensorBridge_FrontPanelBridgeSC_State_event_consumed = 0;
if (_instance->SensorBridge_FrontPanelBridgeSC_State == SENSORBRIDGE_FRONTPANELBRIDGESC_BRIDGING_STATE) {
if (SensorBridge_FrontPanelBridgeSC_State_event_consumed == 0 && 1) {
SensorBridge_send_fpmqtt_front_panel_hwmonitor(_instance, temp, voltage);
SensorBridge_FrontPanelBridgeSC_State_event_consumed = 1;
}
}
//End Region FrontPanelBridgeSC
//Region LocalMQTTMonitor
uint8_t SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State_event_consumed = 0;
//End Region LocalMQTTMonitor
//Region NetworkMonitor
uint8_t SensorBridge_FrontPanelBridgeSC_NetworkMonitor_State_event_consumed = 0;
//End Region NetworkMonitor
//End dsregion FrontPanelBridgeSC
//Session list: 
}
void SensorBridge_handle_fpserial_ping_serial(struct SensorBridge_Instance *_instance, uint16_t seq) {
if(!(_instance->active)) return;
//Region FrontPanelBridgeSC
uint8_t SensorBridge_FrontPanelBridgeSC_State_event_consumed = 0;
//End Region FrontPanelBridgeSC
//Region LocalMQTTMonitor
uint8_t SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State_event_consumed = 0;
//End Region LocalMQTTMonitor
//Region NetworkMonitor
uint8_t SensorBridge_FrontPanelBridgeSC_NetworkMonitor_State_event_consumed = 0;
//End Region NetworkMonitor
//End dsregion FrontPanelBridgeSC
//Session list: 
if (1) {
SensorBridge_send_fpserial_pong_serial(_instance, seq + 1);
SensorBridge_FrontPanelBridgeSC_State_event_consumed = 1;
}
}
void SensorBridge_handle_fpmqtt_set_sensor_rate(struct SensorBridge_Instance *_instance, uint16_t ms) {
if(!(_instance->active)) return;
//Region FrontPanelBridgeSC
uint8_t SensorBridge_FrontPanelBridgeSC_State_event_consumed = 0;
if (_instance->SensorBridge_FrontPanelBridgeSC_State == SENSORBRIDGE_FRONTPANELBRIDGESC_BRIDGING_STATE) {
if (SensorBridge_FrontPanelBridgeSC_State_event_consumed == 0 && 1) {
SensorBridge_send_fpserial_set_sensor_rate(_instance, ms);
SensorBridge_FrontPanelBridgeSC_State_event_consumed = 1;
}
}
//End Region FrontPanelBridgeSC
//Region LocalMQTTMonitor
uint8_t SensorBridge_FrontPanelBridgeSC_LocalMQTTMonitor_State_event_consumed = 0;
//End Region LocalMQTTMonitor
//Region NetworkMonitor
uint8_t SensorBridge_FrontPanelBridgeSC_NetworkMonitor_State_event_consumed = 0;
//End Region NetworkMonitor
//End dsregion FrontPanelBridgeSC
//Session list: 
}

// Observers for outgoing messages:
void (*external_SensorBridge_send_fpmqtt_front_panel_hwmonitor_listener)(struct SensorBridge_Instance *, int8_t, uint16_t)= 0x0;
void (*SensorBridge_send_fpmqtt_front_panel_hwmonitor_listener)(struct SensorBridge_Instance *, int8_t, uint16_t)= 0x0;
void register_external_SensorBridge_send_fpmqtt_front_panel_hwmonitor_listener(void (*_listener)(struct SensorBridge_Instance *, int8_t, uint16_t)){
external_SensorBridge_send_fpmqtt_front_panel_hwmonitor_listener = _listener;
}
void register_SensorBridge_send_fpmqtt_front_panel_hwmonitor_listener(void (*_listener)(struct SensorBridge_Instance *, int8_t, uint16_t)){
SensorBridge_send_fpmqtt_front_panel_hwmonitor_listener = _listener;
}
void SensorBridge_send_fpmqtt_front_panel_hwmonitor(struct SensorBridge_Instance *_instance, int8_t temp, uint16_t voltage){
if (SensorBridge_send_fpmqtt_front_panel_hwmonitor_listener != 0x0) SensorBridge_send_fpmqtt_front_panel_hwmonitor_listener(_instance, temp, voltage);
if (external_SensorBridge_send_fpmqtt_front_panel_hwmonitor_listener != 0x0) external_SensorBridge_send_fpmqtt_front_panel_hwmonitor_listener(_instance, temp, voltage);
;
}
void (*external_SensorBridge_send_fpmqtt_heartbeat_network_listener)(struct SensorBridge_Instance *, bool, uint8_t)= 0x0;
void (*SensorBridge_send_fpmqtt_heartbeat_network_listener)(struct SensorBridge_Instance *, bool, uint8_t)= 0x0;
void register_external_SensorBridge_send_fpmqtt_heartbeat_network_listener(void (*_listener)(struct SensorBridge_Instance *, bool, uint8_t)){
external_SensorBridge_send_fpmqtt_heartbeat_network_listener = _listener;
}
void register_SensorBridge_send_fpmqtt_heartbeat_network_listener(void (*_listener)(struct SensorBridge_Instance *, bool, uint8_t)){
SensorBridge_send_fpmqtt_heartbeat_network_listener = _listener;
}
void SensorBridge_send_fpmqtt_heartbeat_network(struct SensorBridge_Instance *_instance, bool stable, uint8_t interval){
if (SensorBridge_send_fpmqtt_heartbeat_network_listener != 0x0) SensorBridge_send_fpmqtt_heartbeat_network_listener(_instance, stable, interval);
if (external_SensorBridge_send_fpmqtt_heartbeat_network_listener != 0x0) external_SensorBridge_send_fpmqtt_heartbeat_network_listener(_instance, stable, interval);
;
}
void (*external_SensorBridge_send_fpmqtt_adc_values_listener)(struct SensorBridge_Instance *, uint16_t, uint16_t, uint16_t, uint16_t)= 0x0;
void (*SensorBridge_send_fpmqtt_adc_values_listener)(struct SensorBridge_Instance *, uint16_t, uint16_t, uint16_t, uint16_t)= 0x0;
void register_external_SensorBridge_send_fpmqtt_adc_values_listener(void (*_listener)(struct SensorBridge_Instance *, uint16_t, uint16_t, uint16_t, uint16_t)){
external_SensorBridge_send_fpmqtt_adc_values_listener = _listener;
}
void register_SensorBridge_send_fpmqtt_adc_values_listener(void (*_listener)(struct SensorBridge_Instance *, uint16_t, uint16_t, uint16_t, uint16_t)){
SensorBridge_send_fpmqtt_adc_values_listener = _listener;
}
void SensorBridge_send_fpmqtt_adc_values(struct SensorBridge_Instance *_instance, uint16_t a0, uint16_t a1, uint16_t a2, uint16_t a3){
if (SensorBridge_send_fpmqtt_adc_values_listener != 0x0) SensorBridge_send_fpmqtt_adc_values_listener(_instance, a0, a1, a2, a3);
if (external_SensorBridge_send_fpmqtt_adc_values_listener != 0x0) external_SensorBridge_send_fpmqtt_adc_values_listener(_instance, a0, a1, a2, a3);
;
}
void (*external_SensorBridge_send_fpserial_pong_serial_listener)(struct SensorBridge_Instance *, uint16_t)= 0x0;
void (*SensorBridge_send_fpserial_pong_serial_listener)(struct SensorBridge_Instance *, uint16_t)= 0x0;
void register_external_SensorBridge_send_fpserial_pong_serial_listener(void (*_listener)(struct SensorBridge_Instance *, uint16_t)){
external_SensorBridge_send_fpserial_pong_serial_listener = _listener;
}
void register_SensorBridge_send_fpserial_pong_serial_listener(void (*_listener)(struct SensorBridge_Instance *, uint16_t)){
SensorBridge_send_fpserial_pong_serial_listener = _listener;
}
void SensorBridge_send_fpserial_pong_serial(struct SensorBridge_Instance *_instance, uint16_t seq){
if (SensorBridge_send_fpserial_pong_serial_listener != 0x0) SensorBridge_send_fpserial_pong_serial_listener(_instance, seq);
if (external_SensorBridge_send_fpserial_pong_serial_listener != 0x0) external_SensorBridge_send_fpserial_pong_serial_listener(_instance, seq);
;
}
void (*external_SensorBridge_send_fpserial_heartbeat_gateway_listener)(struct SensorBridge_Instance *, uint8_t)= 0x0;
void (*SensorBridge_send_fpserial_heartbeat_gateway_listener)(struct SensorBridge_Instance *, uint8_t)= 0x0;
void register_external_SensorBridge_send_fpserial_heartbeat_gateway_listener(void (*_listener)(struct SensorBridge_Instance *, uint8_t)){
external_SensorBridge_send_fpserial_heartbeat_gateway_listener = _listener;
}
void register_SensorBridge_send_fpserial_heartbeat_gateway_listener(void (*_listener)(struct SensorBridge_Instance *, uint8_t)){
SensorBridge_send_fpserial_heartbeat_gateway_listener = _listener;
}
void SensorBridge_send_fpserial_heartbeat_gateway(struct SensorBridge_Instance *_instance, uint8_t interval){
if (SensorBridge_send_fpserial_heartbeat_gateway_listener != 0x0) SensorBridge_send_fpserial_heartbeat_gateway_listener(_instance, interval);
if (external_SensorBridge_send_fpserial_heartbeat_gateway_listener != 0x0) external_SensorBridge_send_fpserial_heartbeat_gateway_listener(_instance, interval);
;
}
void (*external_SensorBridge_send_fpserial_heartbeat_network_listener)(struct SensorBridge_Instance *, bool, uint8_t)= 0x0;
void (*SensorBridge_send_fpserial_heartbeat_network_listener)(struct SensorBridge_Instance *, bool, uint8_t)= 0x0;
void register_external_SensorBridge_send_fpserial_heartbeat_network_listener(void (*_listener)(struct SensorBridge_Instance *, bool, uint8_t)){
external_SensorBridge_send_fpserial_heartbeat_network_listener = _listener;
}
void register_SensorBridge_send_fpserial_heartbeat_network_listener(void (*_listener)(struct SensorBridge_Instance *, bool, uint8_t)){
SensorBridge_send_fpserial_heartbeat_network_listener = _listener;
}
void SensorBridge_send_fpserial_heartbeat_network(struct SensorBridge_Instance *_instance, bool stable, uint8_t interval){
if (SensorBridge_send_fpserial_heartbeat_network_listener != 0x0) SensorBridge_send_fpserial_heartbeat_network_listener(_instance, stable, interval);
if (external_SensorBridge_send_fpserial_heartbeat_network_listener != 0x0) external_SensorBridge_send_fpserial_heartbeat_network_listener(_instance, stable, interval);
;
}
void (*external_SensorBridge_send_fpserial_set_sensor_rate_listener)(struct SensorBridge_Instance *, uint16_t)= 0x0;
void (*SensorBridge_send_fpserial_set_sensor_rate_listener)(struct SensorBridge_Instance *, uint16_t)= 0x0;
void register_external_SensorBridge_send_fpserial_set_sensor_rate_listener(void (*_listener)(struct SensorBridge_Instance *, uint16_t)){
external_SensorBridge_send_fpserial_set_sensor_rate_listener = _listener;
}
void register_SensorBridge_send_fpserial_set_sensor_rate_listener(void (*_listener)(struct SensorBridge_Instance *, uint16_t)){
SensorBridge_send_fpserial_set_sensor_rate_listener = _listener;
}
void SensorBridge_send_fpserial_set_sensor_rate(struct SensorBridge_Instance *_instance, uint16_t ms){
if (SensorBridge_send_fpserial_set_sensor_rate_listener != 0x0) SensorBridge_send_fpserial_set_sensor_rate_listener(_instance, ms);
if (external_SensorBridge_send_fpserial_set_sensor_rate_listener != 0x0) external_SensorBridge_send_fpserial_set_sensor_rate_listener(_instance, ms);
;
}
void (*external_SensorBridge_send_mqtt_mqtt_connect_listener)(struct SensorBridge_Instance *, char *, char *, uint16_t, bool)= 0x0;
void (*SensorBridge_send_mqtt_mqtt_connect_listener)(struct SensorBridge_Instance *, char *, char *, uint16_t, bool)= 0x0;
void register_external_SensorBridge_send_mqtt_mqtt_connect_listener(void (*_listener)(struct SensorBridge_Instance *, char *, char *, uint16_t, bool)){
external_SensorBridge_send_mqtt_mqtt_connect_listener = _listener;
}
void register_SensorBridge_send_mqtt_mqtt_connect_listener(void (*_listener)(struct SensorBridge_Instance *, char *, char *, uint16_t, bool)){
SensorBridge_send_mqtt_mqtt_connect_listener = _listener;
}
void SensorBridge_send_mqtt_mqtt_connect(struct SensorBridge_Instance *_instance, char * client_id, char * host, uint16_t portno, bool tls){
if (SensorBridge_send_mqtt_mqtt_connect_listener != 0x0) SensorBridge_send_mqtt_mqtt_connect_listener(_instance, client_id, host, portno, tls);
if (external_SensorBridge_send_mqtt_mqtt_connect_listener != 0x0) external_SensorBridge_send_mqtt_mqtt_connect_listener(_instance, client_id, host, portno, tls);
;
}
void (*external_SensorBridge_send_mqtt_mqtt_disconnect_listener)(struct SensorBridge_Instance *)= 0x0;
void (*SensorBridge_send_mqtt_mqtt_disconnect_listener)(struct SensorBridge_Instance *)= 0x0;
void register_external_SensorBridge_send_mqtt_mqtt_disconnect_listener(void (*_listener)(struct SensorBridge_Instance *)){
external_SensorBridge_send_mqtt_mqtt_disconnect_listener = _listener;
}
void register_SensorBridge_send_mqtt_mqtt_disconnect_listener(void (*_listener)(struct SensorBridge_Instance *)){
SensorBridge_send_mqtt_mqtt_disconnect_listener = _listener;
}
void SensorBridge_send_mqtt_mqtt_disconnect(struct SensorBridge_Instance *_instance){
if (SensorBridge_send_mqtt_mqtt_disconnect_listener != 0x0) SensorBridge_send_mqtt_mqtt_disconnect_listener(_instance);
if (external_SensorBridge_send_mqtt_mqtt_disconnect_listener != 0x0) external_SensorBridge_send_mqtt_mqtt_disconnect_listener(_instance);
;
}
void (*external_SensorBridge_send_mqtt_mqtt_set_credentials_listener)(struct SensorBridge_Instance *, char *, char *)= 0x0;
void (*SensorBridge_send_mqtt_mqtt_set_credentials_listener)(struct SensorBridge_Instance *, char *, char *)= 0x0;
void register_external_SensorBridge_send_mqtt_mqtt_set_credentials_listener(void (*_listener)(struct SensorBridge_Instance *, char *, char *)){
external_SensorBridge_send_mqtt_mqtt_set_credentials_listener = _listener;
}
void register_SensorBridge_send_mqtt_mqtt_set_credentials_listener(void (*_listener)(struct SensorBridge_Instance *, char *, char *)){
SensorBridge_send_mqtt_mqtt_set_credentials_listener = _listener;
}
void SensorBridge_send_mqtt_mqtt_set_credentials(struct SensorBridge_Instance *_instance, char * usr, char * pwd){
if (SensorBridge_send_mqtt_mqtt_set_credentials_listener != 0x0) SensorBridge_send_mqtt_mqtt_set_credentials_listener(_instance, usr, pwd);
if (external_SensorBridge_send_mqtt_mqtt_set_credentials_listener != 0x0) external_SensorBridge_send_mqtt_mqtt_set_credentials_listener(_instance, usr, pwd);
;
}
void (*external_SensorBridge_send_mqtt_mqtt_set_tls_certificates_listener)(struct SensorBridge_Instance *, char *, char *, char *, char *)= 0x0;
void (*SensorBridge_send_mqtt_mqtt_set_tls_certificates_listener)(struct SensorBridge_Instance *, char *, char *, char *, char *)= 0x0;
void register_external_SensorBridge_send_mqtt_mqtt_set_tls_certificates_listener(void (*_listener)(struct SensorBridge_Instance *, char *, char *, char *, char *)){
external_SensorBridge_send_mqtt_mqtt_set_tls_certificates_listener = _listener;
}
void register_SensorBridge_send_mqtt_mqtt_set_tls_certificates_listener(void (*_listener)(struct SensorBridge_Instance *, char *, char *, char *, char *)){
SensorBridge_send_mqtt_mqtt_set_tls_certificates_listener = _listener;
}
void SensorBridge_send_mqtt_mqtt_set_tls_certificates(struct SensorBridge_Instance *_instance, char * cafile, char * capath, char * certfile, char * keyfile){
if (SensorBridge_send_mqtt_mqtt_set_tls_certificates_listener != 0x0) SensorBridge_send_mqtt_mqtt_set_tls_certificates_listener(_instance, cafile, capath, certfile, keyfile);
if (external_SensorBridge_send_mqtt_mqtt_set_tls_certificates_listener != 0x0) external_SensorBridge_send_mqtt_mqtt_set_tls_certificates_listener(_instance, cafile, capath, certfile, keyfile);
;
}
void (*external_SensorBridge_send_mqtt_mqtt_set_prefix_listener)(struct SensorBridge_Instance *, char *)= 0x0;
void (*SensorBridge_send_mqtt_mqtt_set_prefix_listener)(struct SensorBridge_Instance *, char *)= 0x0;
void register_external_SensorBridge_send_mqtt_mqtt_set_prefix_listener(void (*_listener)(struct SensorBridge_Instance *, char *)){
external_SensorBridge_send_mqtt_mqtt_set_prefix_listener = _listener;
}
void register_SensorBridge_send_mqtt_mqtt_set_prefix_listener(void (*_listener)(struct SensorBridge_Instance *, char *)){
SensorBridge_send_mqtt_mqtt_set_prefix_listener = _listener;
}
void SensorBridge_send_mqtt_mqtt_set_prefix(struct SensorBridge_Instance *_instance, char * prefix){
if (SensorBridge_send_mqtt_mqtt_set_prefix_listener != 0x0) SensorBridge_send_mqtt_mqtt_set_prefix_listener(_instance, prefix);
if (external_SensorBridge_send_mqtt_mqtt_set_prefix_listener != 0x0) external_SensorBridge_send_mqtt_mqtt_set_prefix_listener(_instance, prefix);
;
}
void (*external_SensorBridge_send_clock_timer_start_listener)(struct SensorBridge_Instance *, uint8_t, uint16_t)= 0x0;
void (*SensorBridge_send_clock_timer_start_listener)(struct SensorBridge_Instance *, uint8_t, uint16_t)= 0x0;
void register_external_SensorBridge_send_clock_timer_start_listener(void (*_listener)(struct SensorBridge_Instance *, uint8_t, uint16_t)){
external_SensorBridge_send_clock_timer_start_listener = _listener;
}
void register_SensorBridge_send_clock_timer_start_listener(void (*_listener)(struct SensorBridge_Instance *, uint8_t, uint16_t)){
SensorBridge_send_clock_timer_start_listener = _listener;
}
void SensorBridge_send_clock_timer_start(struct SensorBridge_Instance *_instance, uint8_t id, uint16_t time){
if (SensorBridge_send_clock_timer_start_listener != 0x0) SensorBridge_send_clock_timer_start_listener(_instance, id, time);
if (external_SensorBridge_send_clock_timer_start_listener != 0x0) external_SensorBridge_send_clock_timer_start_listener(_instance, id, time);
;
}
void (*external_SensorBridge_send_clock_timer_cancel_listener)(struct SensorBridge_Instance *, uint8_t)= 0x0;
void (*SensorBridge_send_clock_timer_cancel_listener)(struct SensorBridge_Instance *, uint8_t)= 0x0;
void register_external_SensorBridge_send_clock_timer_cancel_listener(void (*_listener)(struct SensorBridge_Instance *, uint8_t)){
external_SensorBridge_send_clock_timer_cancel_listener = _listener;
}
void register_SensorBridge_send_clock_timer_cancel_listener(void (*_listener)(struct SensorBridge_Instance *, uint8_t)){
SensorBridge_send_clock_timer_cancel_listener = _listener;
}
void SensorBridge_send_clock_timer_cancel(struct SensorBridge_Instance *_instance, uint8_t id){
if (SensorBridge_send_clock_timer_cancel_listener != 0x0) SensorBridge_send_clock_timer_cancel_listener(_instance, id);
if (external_SensorBridge_send_clock_timer_cancel_listener != 0x0) external_SensorBridge_send_clock_timer_cancel_listener(_instance, id);
;
}
void (*external_SensorBridge_send_netmon_start_netmonitor_listener)(struct SensorBridge_Instance *, uint8_t)= 0x0;
void (*SensorBridge_send_netmon_start_netmonitor_listener)(struct SensorBridge_Instance *, uint8_t)= 0x0;
void register_external_SensorBridge_send_netmon_start_netmonitor_listener(void (*_listener)(struct SensorBridge_Instance *, uint8_t)){
external_SensorBridge_send_netmon_start_netmonitor_listener = _listener;
}
void register_SensorBridge_send_netmon_start_netmonitor_listener(void (*_listener)(struct SensorBridge_Instance *, uint8_t)){
SensorBridge_send_netmon_start_netmonitor_listener = _listener;
}
void SensorBridge_send_netmon_start_netmonitor(struct SensorBridge_Instance *_instance, uint8_t interval){
if (SensorBridge_send_netmon_start_netmonitor_listener != 0x0) SensorBridge_send_netmon_start_netmonitor_listener(_instance, interval);
if (external_SensorBridge_send_netmon_start_netmonitor_listener != 0x0) external_SensorBridge_send_netmon_start_netmonitor_listener(_instance, interval);
;
}
void (*external_SensorBridge_send_netmon_stop_netmonitor_listener)(struct SensorBridge_Instance *)= 0x0;
void (*SensorBridge_send_netmon_stop_netmonitor_listener)(struct SensorBridge_Instance *)= 0x0;
void register_external_SensorBridge_send_netmon_stop_netmonitor_listener(void (*_listener)(struct SensorBridge_Instance *)){
external_SensorBridge_send_netmon_stop_netmonitor_listener = _listener;
}
void register_SensorBridge_send_netmon_stop_netmonitor_listener(void (*_listener)(struct SensorBridge_Instance *)){
SensorBridge_send_netmon_stop_netmonitor_listener = _listener;
}
void SensorBridge_send_netmon_stop_netmonitor(struct SensorBridge_Instance *_instance){
if (SensorBridge_send_netmon_stop_netmonitor_listener != 0x0) SensorBridge_send_netmon_stop_netmonitor_listener(_instance);
if (external_SensorBridge_send_netmon_stop_netmonitor_listener != 0x0) external_SensorBridge_send_netmon_stop_netmonitor_listener(_instance);
;
}



