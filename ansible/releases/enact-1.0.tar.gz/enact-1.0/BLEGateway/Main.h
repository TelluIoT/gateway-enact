/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *           Header for Thing Main
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#ifndef Main_H_
#define Main_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "thingml_typedefs.h"

/*****************************************************************************
 * Headers for type : Main
 *****************************************************************************/


// BEGIN: Code from the c_header annotation for type BTAddress
#include <bluetooth/bluetooth.h>
// END: Code from the c_header annotation for type BTAddress


// BEGIN: Code from the c_header annotation for type UUID
#ifndef BLE_UUID_T_H
#define BLE_UUID_T_H
typedef struct { uint8_t bytes[16]; } ble_uuid_t;
#endif
// END: Code from the c_header annotation for type UUID


// BEGIN: Code from the c_header annotation for type BLEAdvertiseData
#ifndef BLE_ADV_DATA_T_H
#define BLE_ADV_DATA_T_H
typedef struct { uint8_t bytes[31]; } ble_adv_data_t;
#endif
// END: Code from the c_header annotation for type BLEAdvertiseData


// BEGIN: Code from the c_header annotation for type BLERandomPart
#ifndef BLE_RANDOM_PART_T_H
#define BLE_RANDOM_PART_T_H
typedef struct { uint8_t bytes[8]; } ble_random_part_t;
#endif
// END: Code from the c_header annotation for type BLERandomPart


// BEGIN: Code from the c_header annotation for type GATTData
#ifndef BLE_GATT_DATA_T_H
#define BLE_GATT_DATA_T_H
typedef struct { uint8_t length; uint8_t bytes[23]; } ble_gatt_data_t;
#endif
// END: Code from the c_header annotation for type GATTData


// BEGIN: Code from the c_header annotation for type SMPPublicKey
#ifndef SMP_PUBLIC_KEY_T_H
#define SMP_PUBLIC_KEY_T_H
typedef struct { uint8_t bytes[32]; } smp_public_key_t;
#endif
// END: Code from the c_header annotation for type SMPPublicKey


// BEGIN: Code from the c_header annotation for type HCIEventMask
#include <bluetooth/bluetooth.h>
#include <bluetooth/hci.h>
// END: Code from the c_header annotation for type HCIEventMask


// BEGIN: Code from the c_header annotation for type BLERandomNumber
#ifndef BLE_RANDOM_NUMBER_T_H
#define BLE_RANDOM_NUMBER_T_H
typedef struct { uint8_t bytes[16]; } ble_random_number_t;
#endif
// END: Code from the c_header annotation for type BLERandomNumber


// BEGIN: Code from the c_header annotation for type BTLocalName
#include <bluetooth/bluetooth.h>
#include <bluetooth/hci.h>
// END: Code from the c_header annotation for type BTLocalName

// Definition of the instance struct:
struct Main_Instance {

// Instances of different sessions
bool active;
// Variables for the ID of the ports of the instance
uint16_t id_local;
uint16_t id_mqtt;
uint16_t id_Socket;
uint16_t id_HCICommands;
uint16_t id_HCIEvents;
uint16_t id_ATT;
uint16_t id_SMP;
uint16_t id_Signals;
uint16_t id_clock;
// Variables for the current instance state
int Main_States_State;
int Main_States_Initialise_State;
// Variables for the properties of the instance
uint8_t Main_wd_timer_id_var;
uint8_t Main_timer_id_var;
char * Main_client_id_var;
char * Main_broker_host_var;
bdaddr_t Main_DeviceAddress_var;
uint16_t Main_broker_port_var;

};
// Declaration of prototypes outgoing messages :
void Main_States_OnEntry(int state, struct Main_Instance *_instance);
void Main_handle_Socket_Closed(struct Main_Instance *_instance);
void Main_handle_Socket_Opened(struct Main_Instance *_instance, bdaddr_t Address);
void Main_handle_mqtt_mqtt_disconnected(struct Main_Instance *_instance);
void Main_handle_mqtt_mqtt_connected(struct Main_Instance *_instance);
void Main_handle_clock_timer_timeout(struct Main_Instance *_instance, uint8_t id);
void Main_handle_HCIEvents_SetLEScanEnableCompleted(struct Main_Instance *_instance, uint8_t NumberAllowedCommandPackets, uint8_t Status);
void Main_handle_HCIEvents_SetLEEventMaskCompleted(struct Main_Instance *_instance, uint8_t NumberAllowedCommandPackets, uint8_t Status);
void Main_handle_HCIEvents_LEAdvertisementReport(struct Main_Instance *_instance, uint8_t Type, uint8_t AddressType, bdaddr_t Address, uint8_t Length, ble_adv_data_t Data, int8_t RSSI);
void Main_handle_HCIEvents_ResetCompleted(struct Main_Instance *_instance, uint8_t NumberAllowedCommandPackets, uint8_t Status);
void Main_handle_HCIEvents_SetEventMaskCompleted(struct Main_Instance *_instance, uint8_t NumberAllowedCommandPackets, uint8_t Status);
void Main_handle_HCIEvents_SetLEScanParametersCompleted(struct Main_Instance *_instance, uint8_t NumberAllowedCommandPackets, uint8_t Status);
void Main_handle_Signals_Interrupt(struct Main_Instance *_instance);
// Declaration of callbacks for incoming messages:
void register_Main_send_local_ble_activity_listener(void (*_listener)(struct Main_Instance *, uint8_t));
void register_external_Main_send_local_ble_activity_listener(void (*_listener)(struct Main_Instance *, uint8_t));
void register_Main_send_local_ble_error_listener(void (*_listener)(struct Main_Instance *, uint8_t));
void register_external_Main_send_local_ble_error_listener(void (*_listener)(struct Main_Instance *, uint8_t));
void register_Main_send_local_heartbeat_ble_listener(void (*_listener)(struct Main_Instance *, uint8_t));
void register_external_Main_send_local_heartbeat_ble_listener(void (*_listener)(struct Main_Instance *, uint8_t));
void register_Main_send_local_ruuvi_measurement_listener(void (*_listener)(struct Main_Instance *, uint32_t, char *, uint32_t, uint8_t, int32_t, int32_t, int16_t, int16_t, int16_t, uint16_t, int8_t));
void register_external_Main_send_local_ruuvi_measurement_listener(void (*_listener)(struct Main_Instance *, uint32_t, char *, uint32_t, uint8_t, int32_t, int32_t, int16_t, int16_t, int16_t, uint16_t, int8_t));
void register_Main_send_mqtt_mqtt_connect_listener(void (*_listener)(struct Main_Instance *, char *, char *, uint16_t, bool));
void register_external_Main_send_mqtt_mqtt_connect_listener(void (*_listener)(struct Main_Instance *, char *, char *, uint16_t, bool));
void register_Main_send_mqtt_mqtt_disconnect_listener(void (*_listener)(struct Main_Instance *));
void register_external_Main_send_mqtt_mqtt_disconnect_listener(void (*_listener)(struct Main_Instance *));
void register_Main_send_mqtt_mqtt_set_credentials_listener(void (*_listener)(struct Main_Instance *, char *, char *));
void register_external_Main_send_mqtt_mqtt_set_credentials_listener(void (*_listener)(struct Main_Instance *, char *, char *));
void register_Main_send_mqtt_mqtt_set_tls_certificates_listener(void (*_listener)(struct Main_Instance *, char *, char *, char *, char *));
void register_external_Main_send_mqtt_mqtt_set_tls_certificates_listener(void (*_listener)(struct Main_Instance *, char *, char *, char *, char *));
void register_Main_send_mqtt_mqtt_set_prefix_listener(void (*_listener)(struct Main_Instance *, char *));
void register_external_Main_send_mqtt_mqtt_set_prefix_listener(void (*_listener)(struct Main_Instance *, char *));
void register_Main_send_Socket_Open_listener(void (*_listener)(struct Main_Instance *));
void register_external_Main_send_Socket_Open_listener(void (*_listener)(struct Main_Instance *));
void register_Main_send_Socket_Close_listener(void (*_listener)(struct Main_Instance *));
void register_external_Main_send_Socket_Close_listener(void (*_listener)(struct Main_Instance *));
void register_Main_send_HCICommands_Reset_listener(void (*_listener)(struct Main_Instance *));
void register_external_Main_send_HCICommands_Reset_listener(void (*_listener)(struct Main_Instance *));
void register_Main_send_HCICommands_SetEventMask_listener(void (*_listener)(struct Main_Instance *, set_event_mask_cp));
void register_external_Main_send_HCICommands_SetEventMask_listener(void (*_listener)(struct Main_Instance *, set_event_mask_cp));
void register_Main_send_HCICommands_SetEventMaskAll_listener(void (*_listener)(struct Main_Instance *));
void register_external_Main_send_HCICommands_SetEventMaskAll_listener(void (*_listener)(struct Main_Instance *));
void register_Main_send_HCICommands_SetLocalName_listener(void (*_listener)(struct Main_Instance *, change_local_name_cp));
void register_external_Main_send_HCICommands_SetLocalName_listener(void (*_listener)(struct Main_Instance *, change_local_name_cp));
void register_Main_send_HCICommands_Disconnect_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint8_t));
void register_external_Main_send_HCICommands_Disconnect_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint8_t));
void register_Main_send_HCICommands_SetLEEventMask_listener(void (*_listener)(struct Main_Instance *, set_event_mask_cp));
void register_external_Main_send_HCICommands_SetLEEventMask_listener(void (*_listener)(struct Main_Instance *, set_event_mask_cp));
void register_Main_send_HCICommands_SetLEEventMaskAll_listener(void (*_listener)(struct Main_Instance *));
void register_external_Main_send_HCICommands_SetLEEventMaskAll_listener(void (*_listener)(struct Main_Instance *));
void register_Main_send_HCICommands_SetLEAdvertisementParameters_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, uint8_t, uint8_t, uint8_t, bdaddr_t, uint8_t, uint8_t));
void register_external_Main_send_HCICommands_SetLEAdvertisementParameters_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, uint8_t, uint8_t, uint8_t, bdaddr_t, uint8_t, uint8_t));
void register_Main_send_HCICommands_SetLEAdvertiseEnable_listener(void (*_listener)(struct Main_Instance *, uint8_t));
void register_external_Main_send_HCICommands_SetLEAdvertiseEnable_listener(void (*_listener)(struct Main_Instance *, uint8_t));
void register_Main_send_HCICommands_SetLEAdvertisingData_listener(void (*_listener)(struct Main_Instance *, uint8_t, ble_adv_data_t));
void register_external_Main_send_HCICommands_SetLEAdvertisingData_listener(void (*_listener)(struct Main_Instance *, uint8_t, ble_adv_data_t));
void register_Main_send_HCICommands_SetLEScanResponseData_listener(void (*_listener)(struct Main_Instance *, uint8_t, ble_adv_data_t));
void register_external_Main_send_HCICommands_SetLEScanResponseData_listener(void (*_listener)(struct Main_Instance *, uint8_t, ble_adv_data_t));
void register_Main_send_HCICommands_SetLEScanParameters_listener(void (*_listener)(struct Main_Instance *, uint8_t, uint16_t, uint16_t, uint8_t, uint8_t));
void register_external_Main_send_HCICommands_SetLEScanParameters_listener(void (*_listener)(struct Main_Instance *, uint8_t, uint16_t, uint16_t, uint8_t, uint8_t));
void register_Main_send_HCICommands_SetLEScanEnable_listener(void (*_listener)(struct Main_Instance *, uint8_t, uint8_t));
void register_external_Main_send_HCICommands_SetLEScanEnable_listener(void (*_listener)(struct Main_Instance *, uint8_t, uint8_t));
void register_Main_send_HCICommands_LECreateConnection_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, uint8_t, uint8_t, bdaddr_t, uint8_t, uint16_t, uint16_t, uint16_t, uint16_t, uint16_t, uint16_t));
void register_external_Main_send_HCICommands_LECreateConnection_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, uint8_t, uint8_t, bdaddr_t, uint8_t, uint16_t, uint16_t, uint16_t, uint16_t, uint16_t, uint16_t));
void register_Main_send_HCICommands_LECreateConnectionCancel_listener(void (*_listener)(struct Main_Instance *));
void register_external_Main_send_HCICommands_LECreateConnectionCancel_listener(void (*_listener)(struct Main_Instance *));
void register_Main_send_HCICommands_LERand_listener(void (*_listener)(struct Main_Instance *));
void register_external_Main_send_HCICommands_LERand_listener(void (*_listener)(struct Main_Instance *));
void register_Main_send_HCICommands_LEEncrypt_listener(void (*_listener)(struct Main_Instance *, ble_random_number_t, ble_random_number_t));
void register_external_Main_send_HCICommands_LEEncrypt_listener(void (*_listener)(struct Main_Instance *, ble_random_number_t, ble_random_number_t));
void register_Main_send_HCICommands_LEStartEncryption_listener(void (*_listener)(struct Main_Instance *, uint16_t, ble_random_part_t, uint16_t, ble_random_number_t));
void register_external_Main_send_HCICommands_LEStartEncryption_listener(void (*_listener)(struct Main_Instance *, uint16_t, ble_random_part_t, uint16_t, ble_random_number_t));
void register_Main_send_ATT_ATTFindInformationRequest_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, uint16_t));
void register_external_Main_send_ATT_ATTFindInformationRequest_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, uint16_t));
void register_Main_send_ATT_ATTFindInformationResponse_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint8_t, ble_gatt_data_t));
void register_external_Main_send_ATT_ATTFindInformationResponse_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint8_t, ble_gatt_data_t));
void register_Main_send_ATT_ATTFindInformationError_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, uint8_t));
void register_external_Main_send_ATT_ATTFindInformationError_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, uint8_t));
void register_Main_send_ATT_ATTReadByTypeRequest_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, uint16_t, ble_uuid_t));
void register_external_Main_send_ATT_ATTReadByTypeRequest_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, uint16_t, ble_uuid_t));
void register_Main_send_ATT_ATTReadByTypeResponse_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint8_t, ble_gatt_data_t));
void register_external_Main_send_ATT_ATTReadByTypeResponse_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint8_t, ble_gatt_data_t));
void register_Main_send_ATT_ATTReadByTypeError_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, uint8_t));
void register_external_Main_send_ATT_ATTReadByTypeError_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, uint8_t));
void register_Main_send_ATT_ATTReadRequest_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t));
void register_external_Main_send_ATT_ATTReadRequest_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t));
void register_Main_send_ATT_ATTReadResponse_listener(void (*_listener)(struct Main_Instance *, uint16_t, ble_gatt_data_t));
void register_external_Main_send_ATT_ATTReadResponse_listener(void (*_listener)(struct Main_Instance *, uint16_t, ble_gatt_data_t));
void register_Main_send_ATT_ATTReadError_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, uint8_t));
void register_external_Main_send_ATT_ATTReadError_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, uint8_t));
void register_Main_send_ATT_ATTReadByGroupTypeRequest_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, uint16_t, ble_uuid_t));
void register_external_Main_send_ATT_ATTReadByGroupTypeRequest_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, uint16_t, ble_uuid_t));
void register_Main_send_ATT_ATTReadByGroupTypeResponse_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint8_t, ble_gatt_data_t));
void register_external_Main_send_ATT_ATTReadByGroupTypeResponse_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint8_t, ble_gatt_data_t));
void register_Main_send_ATT_ATTReadByGroupTypeError_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, uint8_t));
void register_external_Main_send_ATT_ATTReadByGroupTypeError_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, uint8_t));
void register_Main_send_ATT_ATTWriteRequest_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, ble_gatt_data_t));
void register_external_Main_send_ATT_ATTWriteRequest_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, ble_gatt_data_t));
void register_Main_send_ATT_ATTWriteResponse_listener(void (*_listener)(struct Main_Instance *, uint16_t));
void register_external_Main_send_ATT_ATTWriteResponse_listener(void (*_listener)(struct Main_Instance *, uint16_t));
void register_Main_send_ATT_ATTWriteError_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, uint8_t));
void register_external_Main_send_ATT_ATTWriteError_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, uint8_t));
void register_Main_send_ATT_ATTWriteCommand_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, ble_gatt_data_t));
void register_external_Main_send_ATT_ATTWriteCommand_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, ble_gatt_data_t));
void register_Main_send_ATT_ATTHandleValueNotification_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, ble_gatt_data_t));
void register_external_Main_send_ATT_ATTHandleValueNotification_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, ble_gatt_data_t));
void register_Main_send_ATT_ATTHandleValueIndication_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, ble_gatt_data_t));
void register_external_Main_send_ATT_ATTHandleValueIndication_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, ble_gatt_data_t));
void register_Main_send_ATT_ATTHandleValueConfirmation_listener(void (*_listener)(struct Main_Instance *, uint16_t));
void register_external_Main_send_ATT_ATTHandleValueConfirmation_listener(void (*_listener)(struct Main_Instance *, uint16_t));
void register_Main_send_SMP_SMPPairingRequest_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint8_t, bool, bool, bool, bool, bool, uint8_t, uint8_t, uint8_t));
void register_external_Main_send_SMP_SMPPairingRequest_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint8_t, bool, bool, bool, bool, bool, uint8_t, uint8_t, uint8_t));
void register_Main_send_SMP_SMPPairingResponse_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint8_t, bool, bool, bool, bool, bool, uint8_t, uint8_t, uint8_t));
void register_external_Main_send_SMP_SMPPairingResponse_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint8_t, bool, bool, bool, bool, bool, uint8_t, uint8_t, uint8_t));
void register_Main_send_SMP_SMPPairingConfirm_listener(void (*_listener)(struct Main_Instance *, uint16_t, ble_random_number_t));
void register_external_Main_send_SMP_SMPPairingConfirm_listener(void (*_listener)(struct Main_Instance *, uint16_t, ble_random_number_t));
void register_Main_send_SMP_SMPPairingRandom_listener(void (*_listener)(struct Main_Instance *, uint16_t, ble_random_number_t));
void register_external_Main_send_SMP_SMPPairingRandom_listener(void (*_listener)(struct Main_Instance *, uint16_t, ble_random_number_t));
void register_Main_send_SMP_SMPPairingFailed_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint8_t));
void register_external_Main_send_SMP_SMPPairingFailed_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint8_t));
void register_Main_send_SMP_SMPPairingPublicKey_listener(void (*_listener)(struct Main_Instance *, uint16_t, smp_public_key_t, smp_public_key_t));
void register_external_Main_send_SMP_SMPPairingPublicKey_listener(void (*_listener)(struct Main_Instance *, uint16_t, smp_public_key_t, smp_public_key_t));
void register_Main_send_SMP_SMPPairingDHKeyCheck_listener(void (*_listener)(struct Main_Instance *, uint16_t, ble_random_number_t));
void register_external_Main_send_SMP_SMPPairingDHKeyCheck_listener(void (*_listener)(struct Main_Instance *, uint16_t, ble_random_number_t));
void register_Main_send_SMP_SMPKeypressNotification_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint8_t));
void register_external_Main_send_SMP_SMPKeypressNotification_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint8_t));
void register_Main_send_SMP_SMPEncryptionInformation_listener(void (*_listener)(struct Main_Instance *, uint16_t, ble_random_number_t));
void register_external_Main_send_SMP_SMPEncryptionInformation_listener(void (*_listener)(struct Main_Instance *, uint16_t, ble_random_number_t));
void register_Main_send_SMP_SMPMasterIdentification_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, ble_random_part_t));
void register_external_Main_send_SMP_SMPMasterIdentification_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint16_t, ble_random_part_t));
void register_Main_send_SMP_SMPIdentityInformation_listener(void (*_listener)(struct Main_Instance *, uint16_t, ble_random_number_t));
void register_external_Main_send_SMP_SMPIdentityInformation_listener(void (*_listener)(struct Main_Instance *, uint16_t, ble_random_number_t));
void register_Main_send_SMP_SMPIdentityAddressInformation_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint8_t, bdaddr_t));
void register_external_Main_send_SMP_SMPIdentityAddressInformation_listener(void (*_listener)(struct Main_Instance *, uint16_t, uint8_t, bdaddr_t));
void register_Main_send_SMP_SMPSigningInformation_listener(void (*_listener)(struct Main_Instance *, uint16_t, ble_random_number_t));
void register_external_Main_send_SMP_SMPSigningInformation_listener(void (*_listener)(struct Main_Instance *, uint16_t, ble_random_number_t));
void register_Main_send_SMP_SMPSecurityRequest_listener(void (*_listener)(struct Main_Instance *, uint16_t, bool, bool, bool, bool));
void register_external_Main_send_SMP_SMPSecurityRequest_listener(void (*_listener)(struct Main_Instance *, uint16_t, bool, bool, bool, bool));
void register_Main_send_Signals_Quit_listener(void (*_listener)(struct Main_Instance *, int16_t));
void register_external_Main_send_Signals_Quit_listener(void (*_listener)(struct Main_Instance *, int16_t));
void register_Main_send_clock_timer_start_listener(void (*_listener)(struct Main_Instance *, uint8_t, uint16_t));
void register_external_Main_send_clock_timer_start_listener(void (*_listener)(struct Main_Instance *, uint8_t, uint16_t));
void register_Main_send_clock_timer_cancel_listener(void (*_listener)(struct Main_Instance *, uint8_t));
void register_external_Main_send_clock_timer_cancel_listener(void (*_listener)(struct Main_Instance *, uint8_t));

// Definition of the states:
#define MAIN_STATES_INITIALISE_STATE 0
#define MAIN_STATES_INITIALISE_OPENSOCKET_STATE 1
#define MAIN_STATES_INITIALISE_SCAN_STATE 2
#define MAIN_STATES_CONNECTTOMQTT_STATE 3
#define MAIN_STATES_FAILED_STATE 4
#define MAIN_STATES_QUIT_STATE 5
#define MAIN_STATES_INITIALISE_SETEVENTMASK_STATE 6
#define MAIN_STATES_READY_STATE 7
#define MAIN_STATES_STATE 8
#define MAIN_STATES_INITIALISE_SETLEEVENTMASK_STATE 9
#define MAIN_STATES_INITIALISE_RESETADAPTER_STATE 10



#ifdef __cplusplus
}
#endif

#endif //Main_H_
