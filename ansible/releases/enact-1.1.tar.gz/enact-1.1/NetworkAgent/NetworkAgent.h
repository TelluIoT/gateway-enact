/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *           Header for Thing NetworkAgent
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#ifndef NetworkAgent_H_
#define NetworkAgent_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "thingml_typedefs.h"

/*****************************************************************************
 * Headers for type : NetworkAgent
 *****************************************************************************/


// BEGIN: Code from the c_header annotation NetworkAgent

  #include <stdlib.h>
// END: Code from the c_header annotation NetworkAgent

// Definition of the instance struct:
struct NetworkAgent_Instance {

// Instances of different sessions
bool active;
// Variables for the ID of the ports of the instance
uint16_t id_clock;
// Variables for the current instance state
int NetworkAgent_NetworkAgentSC_State;
int NetworkAgent_NetworkAgentSC_NeverConnected_State;
int NetworkAgent_NetworkAgentSC_Monitoring_State;
int NetworkAgent_NetworkAgentSC_ConnectionLost_State;
// Variables for the properties of the instance
int16_t NetworkAgent_INIT_MAX_RETRY_var;
int16_t NetworkAgent_LOST_MAX_RETRY_var;
int16_t NetworkAgent_NetworkAgentSC_InitDelay_seconds_var;
int16_t NetworkAgent_NetworkAgentSC_Monitoring_Waiting_sec_count_var;
bool NetworkAgent_NetworkAgentSC_ConnectionLost_connected_var;
int16_t NetworkAgent_NetworkAgentSC_NeverConnected_Waiting_seconds_var;
int16_t NetworkAgent_LOST_RETRY_DELAY_var;
int16_t NetworkAgent_NetworkAgentSC_NeverConnected_retries_var;
char * NetworkAgent_build_version_var;
int16_t NetworkAgent_NetworkAgentSC_Monitoring_error_count_var;
int16_t NetworkAgent_NetworkAgentSC_NeverConnected_Waiting_sec_count_var;
int16_t NetworkAgent_NetworkAgentSC_InitDelay_sec_count_var;
bool NetworkAgent_NetworkAgentSC_NeverConnected_connected_var;
int16_t NetworkAgent_NetworkAgentSC_Monitoring_Waiting_seconds_var;
int16_t NetworkAgent_INIT_RETRY_DELAY_var;
int16_t NetworkAgent_NetworkAgentSC_ConnectionLost_retries_var;
int16_t NetworkAgent_MONITORING_INTERVAL_var;
int16_t NetworkAgent_NetworkAgentSC_ConnectionLost_Waiting_seconds_var;
uint8_t NetworkAgent_timer_id_var;
int16_t NetworkAgent_MONITORING_ERROR_THRESHOLD_var;
int16_t NetworkAgent_NetworkAgentSC_ConnectionLost_Waiting_sec_count_var;

};
// Declaration of prototypes outgoing messages :
void NetworkAgent_NetworkAgentSC_OnEntry(int state, struct NetworkAgent_Instance *_instance);
void NetworkAgent_handle_clock_timer_timeout(struct NetworkAgent_Instance *_instance, uint8_t id);
// Declaration of callbacks for incoming messages:
void register_NetworkAgent_send_clock_timer_start_listener(void (*_listener)(struct NetworkAgent_Instance *, uint8_t, uint16_t));
void register_external_NetworkAgent_send_clock_timer_start_listener(void (*_listener)(struct NetworkAgent_Instance *, uint8_t, uint16_t));
void register_NetworkAgent_send_clock_timer_cancel_listener(void (*_listener)(struct NetworkAgent_Instance *, uint8_t));
void register_external_NetworkAgent_send_clock_timer_cancel_listener(void (*_listener)(struct NetworkAgent_Instance *, uint8_t));

// Definition of the states:
#define NETWORKAGENT_NETWORKAGENTSC_INITDELAY_STATE 0
#define NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_RESTARTNETWORK_STATE 1
#define NETWORKAGENT_NETWORKAGENTSC_MONITORING_WAITING_STATE 2
#define NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_CHECKNETWORK_STATE 3
#define NETWORKAGENT_NETWORKAGENTSC_STATE 4
#define NETWORKAGENT_NETWORKAGENTSC_MONITORING_STATE 5
#define NETWORKAGENT_NETWORKAGENTSC_MONITORING_CHECKNETWORK_STATE 6
#define NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_WAITING_STATE 7
#define NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_STATE 8
#define NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_WAITING_STATE 9
#define NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_STATE 10
#define NETWORKAGENT_NETWORKAGENTSC_NEVERCONNECTED_RESTARTNETWORK_STATE 11
#define NETWORKAGENT_NETWORKAGENTSC_CONNECTIONLOST_CHECKNETWORK_STATE 12



#ifdef __cplusplus
}
#endif

#endif //NetworkAgent_H_
