/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *        Implementation for Thing Prometheus
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#include "Prometheus.h"

/*****************************************************************************
 * Implementation for type : Prometheus
 *****************************************************************************/


// BEGIN: Code from the c_global annotation Prometheus
char mon_info[2048];
#define PAGE "<html><head><title>libmicrohttpd demo</title>"\
             "</head><body>libmicrohttpd demo</body></html>"

struct MHD_Daemon * httpdaemon;

static int ahc_echo(void * cls,
		    struct MHD_Connection * connection,
		    const char * url,
		    const char * method,
                    const char * version,
		    const char * upload_data,
		    size_t * upload_data_size,
                    void ** ptr) {
  static int dummy;
  const char * page = cls;
  struct MHD_Response * response;
  int ret;

  if (0 != strcmp(method, "GET"))
    return MHD_NO; /* unexpected method */
  if (&dummy != *ptr)
    {
      /* The first time only the headers are valid,
         do not respond in the first round... */
      *ptr = &dummy;
      return MHD_YES;
    }
  if (0 != *upload_data_size)
    return MHD_NO; /* upload data in a GET!? */
  *ptr = NULL; /* clear context pointer */
  response = MHD_create_response_from_buffer (strlen(page),
                                              (void*) page,
  					      MHD_RESPMEM_PERSISTENT);
  ret = MHD_queue_response(connection,
			   MHD_HTTP_OK,
			   response);
  MHD_destroy_response(response);
  return ret;
}


struct ruuvi_struct {
    uint32_t deviceID;		/* key */
    char btaddr[18];
    uint64_t timestamp;
    uint8_t humidity;
    int32_t temperature;
    int32_t pressure;
    uint8_t rssi;
    int16_t ax;
    int16_t ay;
    int16_t az;
    uint16_t battery;
    uint16_t frames;
    UT_hash_handle hh;		/* makes this structure hashable */
};

struct ruuvi_struct *ruuvis = NULL;    /* must initialize to NULL */

#define DATA_MAX_SIZE 64*1024	// 64k of data is the max
char prometheus_data[DATA_MAX_SIZE]; 

struct Prometheus_Instance* __instance_var;
// END: Code from the c_global annotation Prometheus

// Declaration of prototypes:
//Prototypes: State Machine
void Prometheus_PC_OnExit(int state, struct Prometheus_Instance *_instance);
//Prototypes: Message Sending
void Prometheus_send_clock_timer_start(struct Prometheus_Instance *_instance, uint8_t id, uint16_t time);
void Prometheus_send_clock_timer_cancel(struct Prometheus_Instance *_instance, uint8_t id);
void Prometheus_send_localmqtt_mqtt_connect(struct Prometheus_Instance *_instance, char * client_id, char * host, uint16_t portno, bool tls);
void Prometheus_send_localmqtt_mqtt_disconnect(struct Prometheus_Instance *_instance);
void Prometheus_send_localmqtt_mqtt_set_credentials(struct Prometheus_Instance *_instance, char * usr, char * pwd);
void Prometheus_send_localmqtt_mqtt_set_prefix(struct Prometheus_Instance *_instance, char * prefix);
//Prototypes: Function
uint64_t f_Prometheus_getEpochTimeStamp(struct Prometheus_Instance *_instance);
void f_Prometheus_updatePrometheusString(struct Prometheus_Instance *_instance);
int respondToHttpRequest(void *cls, struct MHD_Connection *connection,
                          const char *url,
                          const char *method, const char *version,
                          const char *upload_data,
                          size_t *upload_data_size, void **con_cls);
void f_Prometheus_initializeHTTPServer(struct Prometheus_Instance *_instance, uint16_t httpport);
// Declaration of functions:
// Definition of function getEpochTimeStamp
uint64_t f_Prometheus_getEpochTimeStamp(struct Prometheus_Instance *_instance) {
time_t utc = time(NULL);
return utc;
}
// Definition of function updatePrometheusString
void f_Prometheus_updatePrometheusString(struct Prometheus_Instance *_instance) {
uint32_t len = 0;
struct ruuvi_struct *r;
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"# HELP ruuvi_frames_total Total Ruuvi frames received\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"# TYPE ruuvi_frames_total counter\n");
for(r=ruuvis; r != NULL; r=r->hh.next) len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"ruuvi_frames_total{device=\"%s\"} %d\n", r->btaddr, r->frames);
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"# HELP ruuvi_rssi_dbm Ruuvi tag received signal strength RSSI (dbm)\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"# TYPE ruuvi_rssi_dbm gauge\n");
for(r=ruuvis; r != NULL; r=r->hh.next) len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"ruuvi_rssi_dbm{device=\"%s\"} %d\n", r->btaddr, r->rssi);
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"# HELP ruuvi_battery_mvolts Ruuvi tag battery voltage (mV)\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"# TYPE ruuvi_battery_mvolts gauge\n");
for(r=ruuvis; r != NULL; r=r->hh.next) len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"ruuvi_battery_mvolts{device=\"%s\"} %d\n", r->btaddr, r->battery);
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"# HELP ruuvi_temperature_celsius Ruuvi tag sensor temperature (C x100)\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"# TYPE ruuvi_temperature_celsius gauge\n");
for(r=ruuvis; r != NULL; r=r->hh.next) len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"ruuvi_temperature_celsius{device=\"%s\"} %d\n", r->btaddr, r->temperature);
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"# HELP ruuvi_relative_humidity Ruuvi tag sensor relative humidity (%RH)\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"# TYPE ruuvi_relative_humidity gauge\n");
for(r=ruuvis; r != NULL; r=r->hh.next) len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"ruuvi_relative_humidity{device=\"%s\"} %d\n", r->btaddr, r->humidity);
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"# HELP ruuvi_pressure_pa Ruuvi tag sensor air pressure (Pa)\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"# TYPE ruuvi_pressure_pa gauge\n");
for(r=ruuvis; r != NULL; r=r->hh.next) len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"ruuvi_pressure_pa{device=\"%s\"} %d\n", r->btaddr, r->pressure);
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"# HELP ruuvi_acceleration_g Ruuvi tag sensor acceleration X/Y/Z\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"# TYPE ruuvi_acceleration_g gauge\n");
for(r=ruuvis; r != NULL; r=r->hh.next) len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"ruuvi_acceleration_g{axis=\"X\",device=\"%s\"} %d\n", r->btaddr, r->ax);
for(r=ruuvis; r != NULL; r=r->hh.next) len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"ruuvi_acceleration_g{axis=\"Y\",device=\"%s\"} %d\n", r->btaddr, r->ay);
for(r=ruuvis; r != NULL; r=r->hh.next) len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, 
			"ruuvi_acceleration_g{axis=\"Z\",device=\"%s\"} %d\n", r->btaddr, r->az);
uint64_t now = f_Prometheus_getEpochTimeStamp(_instance);
if(now - _instance->Prometheus_altitude_timestamp_var < 30) {
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# HELP gps_altitude GPS Altitude\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# TYPE gps_altitude gauge\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "gps_altitude{} %f\n", _instance->Prometheus_altitude_var);
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# HELP gps_vspeed GPS Vertical Speed\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# TYPE gps_vspeed gauge\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "gps_vspeed{} %f\n", _instance->Prometheus_altitude_vspeed_var);

}
if(now - _instance->Prometheus_position_timestamp_var < 30) {
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# HELP gps_position_latitude GPS Latitude\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# TYPE gps_position_latitude gauge\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "gps_position_latitude{} %f\n", _instance->Prometheus_latitude_var);
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# HELP gps_position_longitude GPS longitude\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# TYPE gps_position_longitude gauge\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "gps_position_longitude{} %f\n", _instance->Prometheus_longitude_var);
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# HELP gps_speed GPS speed\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# TYPE gps_speed gauge\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "gps_speed{} %f\n", _instance->Prometheus_speed_var);

}
if(now - _instance->Prometheus_gpsstatus_timestamp_var < 30) {
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# HELP gps_status GPS Status\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# TYPE gps_status gauge\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "gps_status{} %d\n", _instance->Prometheus_gpsstatus_var);
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# HELP gps_satellites_visible GPS satellites_visible\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# TYPE gps_satellites_visible gauge\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "gps_satellites_visible{} %d\n", _instance->Prometheus_satellites_visible_var);
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# HELP gps_satellites_used GPS satellites_used\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# TYPE gps_satellites_used gauge\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "gps_satellites_used{} %d\n", _instance->Prometheus_satellites_used_var);

}
if(now - _instance->Prometheus_arduino_timestamp_var < 30) {
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# HELP arduino_temp Temperature of the arduino board\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# TYPE arduino_temp gauge\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "arduino_temp{} %d\n", _instance->Prometheus_arduino_temp_var);
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# HELP arduino_psu Supply voltage of the arduino board\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# TYPE arduino_psu gauge\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "arduino_psu{} %d\n", _instance->Prometheus_arduino_psu_var);

}
if(now - _instance->Prometheus_adc_timestamp_var < 30) {
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# HELP arduino_adc Raw adc values from the arduino\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# TYPE arduino_adc gauge\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "arduino_adc{channel=\"0\"} %d\n", _instance->Prometheus_arduino_adc_var[0]);
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "arduino_adc{channel=\"1\"} %d\n", _instance->Prometheus_arduino_adc_var[1]);
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "arduino_adc{channel=\"2\"} %d\n", _instance->Prometheus_arduino_adc_var[2]);
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "arduino_adc{channel=\"3\"} %d\n", _instance->Prometheus_arduino_adc_var[3]);
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# HELP gateway_psu Supply voltage of the gateway\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# TYPE gateway_psu gauge\n");
len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "gateway_psu{} %d\n", _instance->Prometheus_psu_voltage_var);

}
FILE *temperatureFile;
		long cputemp = 0;
		temperatureFile = fopen ("/sys/class/thermal/thermal_zone0/temp", "r");
		if (temperatureFile == NULL) printf("[ERROR] Unable to read CPU temperature from /sys/class/thermal/thermal_zone0/temp\n");
		else {
			fscanf (temperatureFile, "%ld", &cputemp);
			fclose (temperatureFile);
			
			len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# HELP gateway_cputemp CPU Temperature of the Compute Module\n");
			len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "# TYPE gateway_cputemp gauge\n");
			len += snprintf(prometheus_data+len, DATA_MAX_SIZE-1-len, "gateway_cputemp{} %d\n", cputemp);
			
			
		}
}
// Definition of function respondToHttpRequest
int respondToHttpRequest(void *cls, struct MHD_Connection *connection,
                          const char *url,
                          const char *method, const char *version,
                          const char *upload_data,
                          size_t *upload_data_size, void **con_cls) {
struct MHD_Response *response;
f_Prometheus_updatePrometheusString(__instance_var);
response = MHD_create_response_from_buffer (strlen (prometheus_data), (void*) prometheus_data, MHD_RESPMEM_PERSISTENT);
int16_t result = MHD_queue_response(connection, MHD_HTTP_OK, response);
MHD_destroy_response(response);
return result;
}
// Definition of function initializeHTTPServer
void f_Prometheus_initializeHTTPServer(struct Prometheus_Instance *_instance, uint16_t httpport) {
__instance_var = _instance;
httpdaemon = MHD_start_daemon(MHD_USE_SELECT_INTERNALLY,
							       httpport,
							       NULL,
							       NULL,
							       &respondToHttpRequest,
							       NULL,
							       MHD_OPTION_END);
if(httpdaemon == NULL) {
fprintf(stderr, "ERROR: Could not start HTTP daemon on port ");
fprintf(stderr, "%i",httpport);
fprintf(stderr, "\n");
exit(1);

}
}

// Sessions functionss:


// On Entry Actions:
void Prometheus_PC_OnEntry(int state, struct Prometheus_Instance *_instance) {
switch(state) {
case PROMETHEUS_PC_STATE:{
_instance->Prometheus_PC_State = PROMETHEUS_PC_CONNECT_STATE;
fprintf(stdout, "Starting Prometheus exporter...");
fprintf(stdout, "\n");
Prometheus_PC_OnEntry(_instance->Prometheus_PC_State, _instance);
break;
}
case PROMETHEUS_PC_CONNECT_STATE:{
fprintf(stdout, "Connecting to local MQTT Broker...");
Prometheus_send_localmqtt_mqtt_connect(_instance, _instance->Prometheus_local_client_id_var, _instance->Prometheus_local_broker_host_var, _instance->Prometheus_local_broker_port_var, 0);
f_Prometheus_initializeHTTPServer(_instance, 8086);
break;
}
case PROMETHEUS_PC_MQTTCONNECTED_STATE:{
Prometheus_send_clock_timer_start(_instance, _instance->Prometheus_timer_id_var, 10000);
break;
}
default: break;
}
}

// On Exit Actions:
void Prometheus_PC_OnExit(int state, struct Prometheus_Instance *_instance) {
switch(state) {
case PROMETHEUS_PC_STATE:{
Prometheus_PC_OnExit(_instance->Prometheus_PC_State, _instance);
break;}
case PROMETHEUS_PC_CONNECT_STATE:{
break;}
case PROMETHEUS_PC_MQTTCONNECTED_STATE:{
break;}
default: break;
}
}

// Event Handlers for incoming messages:
void Prometheus_handle_local_front_panel_hwmonitor(struct Prometheus_Instance *_instance, int8_t temp, uint16_t voltage) {
if(!(_instance->active)) return;
//Region PC
uint8_t Prometheus_PC_State_event_consumed = 0;
if (_instance->Prometheus_PC_State == PROMETHEUS_PC_MQTTCONNECTED_STATE) {
if (Prometheus_PC_State_event_consumed == 0 && 1) {
_instance->Prometheus_arduino_timestamp_var = f_Prometheus_getEpochTimeStamp(_instance);
_instance->Prometheus_arduino_psu_var = voltage;
_instance->Prometheus_arduino_temp_var = temp;
Prometheus_PC_State_event_consumed = 1;
}
}
//End Region PC
//End dsregion PC
//Session list: 
}
void Prometheus_handle_local_ruuvi_measurement(struct Prometheus_Instance *_instance, uint32_t timestamp, char * blemac, uint32_t deviceID, uint8_t humidity, int32_t temperature, int32_t pressure, int16_t ax, int16_t ay, int16_t az, uint16_t battery, int8_t rssi) {
if(!(_instance->active)) return;
//Region PC
uint8_t Prometheus_PC_State_event_consumed = 0;
if (_instance->Prometheus_PC_State == PROMETHEUS_PC_MQTTCONNECTED_STATE) {
if (Prometheus_PC_State_event_consumed == 0 && 1) {
struct ruuvi_struct *r;
uint64_t tdiff = 0;
HASH_FIND_INT(ruuvis, &deviceID, r);
if(r==NULL) {
r = (struct ruuvi_struct *)malloc(sizeof *r);
r->deviceID = deviceID;
strncpy(&r->btaddr, blemac, 18);
r->frames = 0;
HASH_ADD_INT( ruuvis, deviceID, r );
fprintf(stdout, "NEW ");

} else {
tdiff = timestamp - r->timestamp;

}
r->timestamp = timestamp;
r->temperature = temperature;
r->pressure = pressure;
r->humidity = humidity;
r->rssi = rssi;
r->ax = ax;
r->ay = ay;
r->az = az;
r->battery = battery;
r->frames++;
fprintf(stdout, "Sensor ");
fprintf(stdout, r->btaddr);
fprintf(stdout, "\t\tframes: ");
fprintf(stdout, "%i",r->frames);
fprintf(stdout, "\t\tdiff:");
fprintf(stdout, "%i",tdiff);
fprintf(stdout, "\n");
Prometheus_PC_State_event_consumed = 1;
}
}
//End Region PC
//End dsregion PC
//Session list: 
}
void Prometheus_handle_local_adc_values(struct Prometheus_Instance *_instance, uint16_t a0, uint16_t a1, uint16_t a2, uint16_t a3) {
if(!(_instance->active)) return;
//Region PC
uint8_t Prometheus_PC_State_event_consumed = 0;
if (_instance->Prometheus_PC_State == PROMETHEUS_PC_MQTTCONNECTED_STATE) {
if (Prometheus_PC_State_event_consumed == 0 && 1) {
_instance->Prometheus_adc_timestamp_var = f_Prometheus_getEpochTimeStamp(_instance);
_instance->Prometheus_arduino_adc_var[0] = a0;
_instance->Prometheus_arduino_adc_var[1] = a1;
_instance->Prometheus_arduino_adc_var[2] = a2;
_instance->Prometheus_arduino_adc_var[3] = a3;
uint32_t psu_factor = (_instance->Prometheus_arduino_psu_var * _instance->Prometheus_gateway_psu_sensor_cal_var) / 1000;
_instance->Prometheus_psu_voltage_var = (psu_factor * a0) / 1024;
Prometheus_PC_State_event_consumed = 1;
}
}
//End Region PC
//End dsregion PC
//Session list: 
}
void Prometheus_handle_local_gps_altitude(struct Prometheus_Instance *_instance, uint32_t timestamp, double altitude, double altitude_err, double vspeed, double vspeed_err) {
if(!(_instance->active)) return;
//Region PC
uint8_t Prometheus_PC_State_event_consumed = 0;
if (_instance->Prometheus_PC_State == PROMETHEUS_PC_MQTTCONNECTED_STATE) {
if (Prometheus_PC_State_event_consumed == 0 && 1) {
_instance->Prometheus_altitude_var = altitude;
_instance->Prometheus_altitude_timestamp_var = timestamp;
_instance->Prometheus_altitude_vspeed_var = vspeed;
Prometheus_PC_State_event_consumed = 1;
}
}
//End Region PC
//End dsregion PC
//Session list: 
}
void Prometheus_handle_local_gps_position(struct Prometheus_Instance *_instance, uint32_t timestamp, uint32_t gpstime, double latitude, double latitude_err, double longitude, double longitude_err, double speed, double speed_err, double track, double track_err) {
if(!(_instance->active)) return;
//Region PC
uint8_t Prometheus_PC_State_event_consumed = 0;
if (_instance->Prometheus_PC_State == PROMETHEUS_PC_MQTTCONNECTED_STATE) {
if (Prometheus_PC_State_event_consumed == 0 && 1) {
_instance->Prometheus_position_timestamp_var = timestamp;
_instance->Prometheus_latitude_var = latitude;
_instance->Prometheus_longitude_var = longitude;
_instance->Prometheus_speed_var = speed;
Prometheus_PC_State_event_consumed = 1;
}
}
//End Region PC
//End dsregion PC
//Session list: 
}
void Prometheus_handle_local_gps_status(struct Prometheus_Instance *_instance, uint32_t timestamp, uint8_t status, uint8_t satellites_visible, uint8_t satellites_used) {
if(!(_instance->active)) return;
//Region PC
uint8_t Prometheus_PC_State_event_consumed = 0;
if (_instance->Prometheus_PC_State == PROMETHEUS_PC_MQTTCONNECTED_STATE) {
if (Prometheus_PC_State_event_consumed == 0 && 1) {
_instance->Prometheus_gpsstatus_timestamp_var = timestamp;
_instance->Prometheus_gpsstatus_var = status;
_instance->Prometheus_satellites_visible_var = satellites_visible;
_instance->Prometheus_satellites_used_var = satellites_used;
Prometheus_PC_State_event_consumed = 1;
}
}
//End Region PC
//End dsregion PC
//Session list: 
}
void Prometheus_handle_localmqtt_mqtt_connected(struct Prometheus_Instance *_instance) {
if(!(_instance->active)) return;
//Region PC
uint8_t Prometheus_PC_State_event_consumed = 0;
if (_instance->Prometheus_PC_State == PROMETHEUS_PC_CONNECT_STATE) {
if (Prometheus_PC_State_event_consumed == 0 && 1) {
Prometheus_PC_OnExit(PROMETHEUS_PC_CONNECT_STATE, _instance);
_instance->Prometheus_PC_State = PROMETHEUS_PC_MQTTCONNECTED_STATE;
fprintf(stdout, "OK");
fprintf(stdout, "\n");
Prometheus_PC_OnEntry(PROMETHEUS_PC_MQTTCONNECTED_STATE, _instance);
Prometheus_PC_State_event_consumed = 1;
}
}
//End Region PC
//End dsregion PC
//Session list: 
}
void Prometheus_handle_localmqtt_mqtt_disconnected(struct Prometheus_Instance *_instance) {
if(!(_instance->active)) return;
//Region PC
uint8_t Prometheus_PC_State_event_consumed = 0;
if (_instance->Prometheus_PC_State == PROMETHEUS_PC_MQTTCONNECTED_STATE) {
if (Prometheus_PC_State_event_consumed == 0 && 1) {
fprintf(stdout, "Lost MQTT connection, exiting...");
fprintf(stdout, "\n");
exit(0);
Prometheus_PC_State_event_consumed = 1;
}
}
//End Region PC
//End dsregion PC
//Session list: 
}
void Prometheus_handle_clock_timer_timeout(struct Prometheus_Instance *_instance, uint8_t id) {
if(!(_instance->active)) return;
//Region PC
uint8_t Prometheus_PC_State_event_consumed = 0;
if (_instance->Prometheus_PC_State == PROMETHEUS_PC_MQTTCONNECTED_STATE) {
if (Prometheus_PC_State_event_consumed == 0 && id == _instance->Prometheus_timer_id_var) {
uint64_t ct = f_Prometheus_getEpochTimeStamp(_instance);
struct ruuvi_struct *r, *tmp;
HASH_ITER(hh, ruuvis, r, tmp) {
if((ct - r->timestamp) > _instance->Prometheus_ruuvi_timeout_sec_var) {
fprintf(stdout, "DROP Sensor ");
fprintf(stdout, "%i",r->deviceID);
fprintf(stdout, "\n");
HASH_DEL(ruuvis, r);
free(r);

}
}
Prometheus_send_clock_timer_start(_instance, _instance->Prometheus_timer_id_var, 10000);
Prometheus_PC_State_event_consumed = 1;
}
}
//End Region PC
//End dsregion PC
//Session list: 
}

// Observers for outgoing messages:
void (*external_Prometheus_send_clock_timer_start_listener)(struct Prometheus_Instance *, uint8_t, uint16_t)= 0x0;
void (*Prometheus_send_clock_timer_start_listener)(struct Prometheus_Instance *, uint8_t, uint16_t)= 0x0;
void register_external_Prometheus_send_clock_timer_start_listener(void (*_listener)(struct Prometheus_Instance *, uint8_t, uint16_t)){
external_Prometheus_send_clock_timer_start_listener = _listener;
}
void register_Prometheus_send_clock_timer_start_listener(void (*_listener)(struct Prometheus_Instance *, uint8_t, uint16_t)){
Prometheus_send_clock_timer_start_listener = _listener;
}
void Prometheus_send_clock_timer_start(struct Prometheus_Instance *_instance, uint8_t id, uint16_t time){
if (Prometheus_send_clock_timer_start_listener != 0x0) Prometheus_send_clock_timer_start_listener(_instance, id, time);
if (external_Prometheus_send_clock_timer_start_listener != 0x0) external_Prometheus_send_clock_timer_start_listener(_instance, id, time);
;
}
void (*external_Prometheus_send_clock_timer_cancel_listener)(struct Prometheus_Instance *, uint8_t)= 0x0;
void (*Prometheus_send_clock_timer_cancel_listener)(struct Prometheus_Instance *, uint8_t)= 0x0;
void register_external_Prometheus_send_clock_timer_cancel_listener(void (*_listener)(struct Prometheus_Instance *, uint8_t)){
external_Prometheus_send_clock_timer_cancel_listener = _listener;
}
void register_Prometheus_send_clock_timer_cancel_listener(void (*_listener)(struct Prometheus_Instance *, uint8_t)){
Prometheus_send_clock_timer_cancel_listener = _listener;
}
void Prometheus_send_clock_timer_cancel(struct Prometheus_Instance *_instance, uint8_t id){
if (Prometheus_send_clock_timer_cancel_listener != 0x0) Prometheus_send_clock_timer_cancel_listener(_instance, id);
if (external_Prometheus_send_clock_timer_cancel_listener != 0x0) external_Prometheus_send_clock_timer_cancel_listener(_instance, id);
;
}
void (*external_Prometheus_send_localmqtt_mqtt_connect_listener)(struct Prometheus_Instance *, char *, char *, uint16_t, bool)= 0x0;
void (*Prometheus_send_localmqtt_mqtt_connect_listener)(struct Prometheus_Instance *, char *, char *, uint16_t, bool)= 0x0;
void register_external_Prometheus_send_localmqtt_mqtt_connect_listener(void (*_listener)(struct Prometheus_Instance *, char *, char *, uint16_t, bool)){
external_Prometheus_send_localmqtt_mqtt_connect_listener = _listener;
}
void register_Prometheus_send_localmqtt_mqtt_connect_listener(void (*_listener)(struct Prometheus_Instance *, char *, char *, uint16_t, bool)){
Prometheus_send_localmqtt_mqtt_connect_listener = _listener;
}
void Prometheus_send_localmqtt_mqtt_connect(struct Prometheus_Instance *_instance, char * client_id, char * host, uint16_t portno, bool tls){
if (Prometheus_send_localmqtt_mqtt_connect_listener != 0x0) Prometheus_send_localmqtt_mqtt_connect_listener(_instance, client_id, host, portno, tls);
if (external_Prometheus_send_localmqtt_mqtt_connect_listener != 0x0) external_Prometheus_send_localmqtt_mqtt_connect_listener(_instance, client_id, host, portno, tls);
;
}
void (*external_Prometheus_send_localmqtt_mqtt_disconnect_listener)(struct Prometheus_Instance *)= 0x0;
void (*Prometheus_send_localmqtt_mqtt_disconnect_listener)(struct Prometheus_Instance *)= 0x0;
void register_external_Prometheus_send_localmqtt_mqtt_disconnect_listener(void (*_listener)(struct Prometheus_Instance *)){
external_Prometheus_send_localmqtt_mqtt_disconnect_listener = _listener;
}
void register_Prometheus_send_localmqtt_mqtt_disconnect_listener(void (*_listener)(struct Prometheus_Instance *)){
Prometheus_send_localmqtt_mqtt_disconnect_listener = _listener;
}
void Prometheus_send_localmqtt_mqtt_disconnect(struct Prometheus_Instance *_instance){
if (Prometheus_send_localmqtt_mqtt_disconnect_listener != 0x0) Prometheus_send_localmqtt_mqtt_disconnect_listener(_instance);
if (external_Prometheus_send_localmqtt_mqtt_disconnect_listener != 0x0) external_Prometheus_send_localmqtt_mqtt_disconnect_listener(_instance);
;
}
void (*external_Prometheus_send_localmqtt_mqtt_set_credentials_listener)(struct Prometheus_Instance *, char *, char *)= 0x0;
void (*Prometheus_send_localmqtt_mqtt_set_credentials_listener)(struct Prometheus_Instance *, char *, char *)= 0x0;
void register_external_Prometheus_send_localmqtt_mqtt_set_credentials_listener(void (*_listener)(struct Prometheus_Instance *, char *, char *)){
external_Prometheus_send_localmqtt_mqtt_set_credentials_listener = _listener;
}
void register_Prometheus_send_localmqtt_mqtt_set_credentials_listener(void (*_listener)(struct Prometheus_Instance *, char *, char *)){
Prometheus_send_localmqtt_mqtt_set_credentials_listener = _listener;
}
void Prometheus_send_localmqtt_mqtt_set_credentials(struct Prometheus_Instance *_instance, char * usr, char * pwd){
if (Prometheus_send_localmqtt_mqtt_set_credentials_listener != 0x0) Prometheus_send_localmqtt_mqtt_set_credentials_listener(_instance, usr, pwd);
if (external_Prometheus_send_localmqtt_mqtt_set_credentials_listener != 0x0) external_Prometheus_send_localmqtt_mqtt_set_credentials_listener(_instance, usr, pwd);
;
}
void (*external_Prometheus_send_localmqtt_mqtt_set_prefix_listener)(struct Prometheus_Instance *, char *)= 0x0;
void (*Prometheus_send_localmqtt_mqtt_set_prefix_listener)(struct Prometheus_Instance *, char *)= 0x0;
void register_external_Prometheus_send_localmqtt_mqtt_set_prefix_listener(void (*_listener)(struct Prometheus_Instance *, char *)){
external_Prometheus_send_localmqtt_mqtt_set_prefix_listener = _listener;
}
void register_Prometheus_send_localmqtt_mqtt_set_prefix_listener(void (*_listener)(struct Prometheus_Instance *, char *)){
Prometheus_send_localmqtt_mqtt_set_prefix_listener = _listener;
}
void Prometheus_send_localmqtt_mqtt_set_prefix(struct Prometheus_Instance *_instance, char * prefix){
if (Prometheus_send_localmqtt_mqtt_set_prefix_listener != 0x0) Prometheus_send_localmqtt_mqtt_set_prefix_listener(_instance, prefix);
if (external_Prometheus_send_localmqtt_mqtt_set_prefix_listener != 0x0) external_Prometheus_send_localmqtt_mqtt_set_prefix_listener(_instance, prefix);
;
}



