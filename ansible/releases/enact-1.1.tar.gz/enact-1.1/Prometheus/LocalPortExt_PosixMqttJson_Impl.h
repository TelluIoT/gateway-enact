/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *           Header for Thing LocalPortExt_PosixMqttJson_Impl
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#ifndef LocalPortExt_PosixMqttJson_Impl_H_
#define LocalPortExt_PosixMqttJson_Impl_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "thingml_typedefs.h"

/*****************************************************************************
 * Headers for type : LocalPortExt_PosixMqttJson_Impl
 *****************************************************************************/


// BEGIN: Code from the c_header annotation LocalPortExt_PosixMqttJson_Impl
#include "jsmn.h"
// END: Code from the c_header annotation LocalPortExt_PosixMqttJson_Impl

// Definition of the instance struct:
struct LocalPortExt_PosixMqttJson_Impl_Instance {

// Instances of different sessions
bool active;
// Variables for the ID of the ports of the instance
uint16_t id_localext;
uint16_t id_posixmqtt;
// Variables for the current instance state
int LocalPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State;
// Variables for the properties of the instance
char * LocalPortExt_PosixMqttJson_Impl_mqtt_topic_name_var;

};
// Declaration of prototypes outgoing messages :
void LocalPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_OnEntry(int state, struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance);
void LocalPortExt_PosixMqttJson_Impl_handle_posixmqtt_mqtt_message(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic, uint8_t * payload, uint32_t size);
void LocalPortExt_PosixMqttJson_Impl_handle_posixmqtt_mqtt_connected(struct LocalPortExt_PosixMqttJson_Impl_Instance *_instance);
// Declaration of callbacks for incoming messages:
void register_LocalPortExt_PosixMqttJson_Impl_send_localext_ruuvi_measurement_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, char *, uint32_t, uint8_t, int32_t, int32_t, int16_t, int16_t, int16_t, uint16_t, int8_t));
void register_external_LocalPortExt_PosixMqttJson_Impl_send_localext_ruuvi_measurement_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, char *, uint32_t, uint8_t, int32_t, int32_t, int16_t, int16_t, int16_t, uint16_t, int8_t));
void register_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_status_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, uint8_t, uint8_t, uint8_t));
void register_external_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_status_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, uint8_t, uint8_t, uint8_t));
void register_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_position_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, uint32_t, double, double, double, double, double, double, double, double));
void register_external_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_position_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, uint32_t, double, double, double, double, double, double, double, double));
void register_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_altitude_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, double, double, double, double));
void register_external_LocalPortExt_PosixMqttJson_Impl_send_localext_gps_altitude_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint32_t, double, double, double, double));
void register_LocalPortExt_PosixMqttJson_Impl_send_localext_adc_values_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint16_t, uint16_t, uint16_t, uint16_t));
void register_external_LocalPortExt_PosixMqttJson_Impl_send_localext_adc_values_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, uint16_t, uint16_t, uint16_t, uint16_t));
void register_LocalPortExt_PosixMqttJson_Impl_send_localext_front_panel_hwmonitor_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, int8_t, uint16_t));
void register_external_LocalPortExt_PosixMqttJson_Impl_send_localext_front_panel_hwmonitor_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, int8_t, uint16_t));
void register_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t));
void register_external_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t));
void register_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, char *));
void register_external_LocalPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(void (*_listener)(struct LocalPortExt_PosixMqttJson_Impl_Instance *, char *));

// Definition of the states:
#define LOCALPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_RUNNING_STATE 0
#define LOCALPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_STATE 1



#ifdef __cplusplus
}
#endif

#endif //LocalPortExt_PosixMqttJson_Impl_H_
