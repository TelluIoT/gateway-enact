/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *           Header for Thing BLEGatewayPortExt_PosixMqttJson_Impl
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#ifndef BLEGatewayPortExt_PosixMqttJson_Impl_H_
#define BLEGatewayPortExt_PosixMqttJson_Impl_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "thingml_typedefs.h"

/*****************************************************************************
 * Headers for type : BLEGatewayPortExt_PosixMqttJson_Impl
 *****************************************************************************/


// BEGIN: Code from the c_header annotation BLEGatewayPortExt_PosixMqttJson_Impl
#include "jsmn.h"
// END: Code from the c_header annotation BLEGatewayPortExt_PosixMqttJson_Impl

// Definition of the instance struct:
struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance {

// Instances of different sessions
bool active;
// Variables for the ID of the ports of the instance
uint16_t id_localext;
uint16_t id_posixmqtt;
// Variables for the current instance state
int BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State;
// Variables for the properties of the instance
char * BLEGatewayPortExt_PosixMqttJson_Impl_mqtt_topic_name_var;

};
// Declaration of prototypes outgoing messages :
void BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_OnEntry(int state, struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance);
void BLEGatewayPortExt_PosixMqttJson_Impl_handle_posixmqtt_mqtt_connected(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance);
void BLEGatewayPortExt_PosixMqttJson_Impl_handle_posixmqtt_mqtt_message(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic, uint8_t * payload, uint32_t size);
void BLEGatewayPortExt_PosixMqttJson_Impl_handle_localext_ble_activity(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance, uint8_t device);
void BLEGatewayPortExt_PosixMqttJson_Impl_handle_localext_heartbeat_ble(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance, uint8_t interval);
void BLEGatewayPortExt_PosixMqttJson_Impl_handle_localext_ruuvi_measurement(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance, uint32_t timestamp, char * blemac, uint32_t deviceID, uint8_t humidity, int32_t temperature, int32_t pressure, int16_t ax, int16_t ay, int16_t az, uint16_t battery, int8_t rssi);
void BLEGatewayPortExt_PosixMqttJson_Impl_handle_localext_ble_error(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance, uint8_t device);
// Declaration of callbacks for incoming messages:
void register_BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(void (*_listener)(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t));
void register_external_BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(void (*_listener)(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t));
void register_BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(void (*_listener)(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *, char *));
void register_external_BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(void (*_listener)(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *, char *));

// Definition of the states:
#define BLEGATEWAYPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_RUNNING_STATE 0
#define BLEGATEWAYPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_STATE 1



#ifdef __cplusplus
}
#endif

#endif //BLEGatewayPortExt_PosixMqttJson_Impl_H_
