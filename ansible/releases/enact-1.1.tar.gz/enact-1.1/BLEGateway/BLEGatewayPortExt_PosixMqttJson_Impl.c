/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *        Implementation for Thing BLEGatewayPortExt_PosixMqttJson_Impl
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#include "BLEGatewayPortExt_PosixMqttJson_Impl.h"

/*****************************************************************************
 * Implementation for type : BLEGatewayPortExt_PosixMqttJson_Impl
 *****************************************************************************/

// Declaration of prototypes:
//Prototypes: State Machine
void BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_OnExit(int state, struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance);
//Prototypes: Message Sending
void BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic, uint8_t * payload, uint32_t size);
void BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic);
//Prototypes: Function
void f_BLEGatewayPortExt_PosixMqttJson_Impl_subscribe_for_message(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance, char * msg_name);
void f_BLEGatewayPortExt_PosixMqttJson_Impl_publish_message(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance, char * msg_name, uint8_t * payload, uint32_t size);
void f_BLEGatewayPortExt_PosixMqttJson_Impl_posixmqtt_subscribe(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance);
bool f_BLEGatewayPortExt_PosixMqttJson_Impl_posixmqtt_parsemsg(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic, char * payload, uint32_t len);
// Declaration of functions:
// Definition of function subscribe_for_message
void f_BLEGatewayPortExt_PosixMqttJson_Impl_subscribe_for_message(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance, char * msg_name) {
char topic[256];
snprintf(topic, 256, "%s/%s", _instance->BLEGatewayPortExt_PosixMqttJson_Impl_mqtt_topic_name_var, msg_name);
BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe(_instance, topic);
}
// Definition of function publish_message
void f_BLEGatewayPortExt_PosixMqttJson_Impl_publish_message(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance, char * msg_name, uint8_t * payload, uint32_t size) {
char topic[256];
snprintf(topic, 256, "%s/%s", _instance->BLEGatewayPortExt_PosixMqttJson_Impl_mqtt_topic_name_var, msg_name);
BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish(_instance, topic, payload, size);
}
// Definition of function posixmqtt_subscribe
void f_BLEGatewayPortExt_PosixMqttJson_Impl_posixmqtt_subscribe(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance) {
}
// Definition of function posixmqtt_parsemsg
bool f_BLEGatewayPortExt_PosixMqttJson_Impl_posixmqtt_parsemsg(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic, char * payload, uint32_t len) {
jsmn_parser parser;
		jsmn_init(&parser);
		jsmntok_t tokens[32];
int16_t parse_result;
int mqtt_topic_name_length = strlen(_instance->BLEGatewayPortExt_PosixMqttJson_Impl_mqtt_topic_name_var);
if(!(strlen(topic) > mqtt_topic_name_length+1)) {
return 0;

}
if(strncmp(topic, _instance->BLEGatewayPortExt_PosixMqttJson_Impl_mqtt_topic_name_var, mqtt_topic_name_length) != 0) {
return 0;

}
if(!(topic[mqtt_topic_name_length] == '/')) {
return 0;

}
char * msg_name = &topic[mqtt_topic_name_length+1];
parse_result = jsmn_parse(&parser, payload, len, tokens, 32);;
return 0;
}

// Sessions functionss:


// On Entry Actions:
void BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_OnEntry(int state, struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance) {
switch(state) {
case BLEGATEWAYPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_STATE:{
_instance->BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State = BLEGATEWAYPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_RUNNING_STATE;
BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_OnEntry(_instance->BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State, _instance);
break;
}
case BLEGATEWAYPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_RUNNING_STATE:{
break;
}
default: break;
}
}

// On Exit Actions:
void BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_OnExit(int state, struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance) {
switch(state) {
case BLEGATEWAYPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_STATE:{
BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_OnExit(_instance->BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State, _instance);
break;}
case BLEGATEWAYPORTEXT_POSIXMQTTJSON_IMPL_POSIXMQTTJSONSC_RUNNING_STATE:{
break;}
default: break;
}
}

// Event Handlers for incoming messages:
void BLEGatewayPortExt_PosixMqttJson_Impl_handle_posixmqtt_mqtt_connected(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance) {
if(!(_instance->active)) return;
//Region PosixMQTTJSonSC
uint8_t BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 0;
//End Region PosixMQTTJSonSC
//End dsregion PosixMQTTJSonSC
//Session list: 
if (1) {
f_BLEGatewayPortExt_PosixMqttJson_Impl_posixmqtt_subscribe(_instance);
BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 1;
}
}
void BLEGatewayPortExt_PosixMqttJson_Impl_handle_posixmqtt_mqtt_message(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic, uint8_t * payload, uint32_t size) {
if(!(_instance->active)) return;
//Region PosixMQTTJSonSC
uint8_t BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 0;
//End Region PosixMQTTJSonSC
//End dsregion PosixMQTTJSonSC
//Session list: 
if (1) {
f_BLEGatewayPortExt_PosixMqttJson_Impl_posixmqtt_parsemsg(_instance, topic, payload, size);
BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 1;
}
}
void BLEGatewayPortExt_PosixMqttJson_Impl_handle_localext_ble_activity(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance, uint8_t device) {
if(!(_instance->active)) return;
//Region PosixMQTTJSonSC
uint8_t BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 0;
//End Region PosixMQTTJSonSC
//End dsregion PosixMQTTJSonSC
//Session list: 
if (1) {
size_t maxlength = 18;
char * payload = malloc(maxlength);
if(payload == NULL) {
printf("FATAL: ThingML runtime failed to allocate memory serializing message to JSON. Exiting.");
exit(-1);
}
uint16_t index = 0;
int result = 0;
payload[index++] = '{';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "device");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%u", device);
if (result >= 0) { index += result; } else { return; }
payload[index++] = '}';
payload[index++] = 0;
f_BLEGatewayPortExt_PosixMqttJson_Impl_publish_message(_instance, "ble_activity", payload, strlen(payload));
free(payload);
BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 1;
}
}
void BLEGatewayPortExt_PosixMqttJson_Impl_handle_localext_heartbeat_ble(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance, uint8_t interval) {
if(!(_instance->active)) return;
//Region PosixMQTTJSonSC
uint8_t BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 0;
//End Region PosixMQTTJSonSC
//End dsregion PosixMQTTJSonSC
//Session list: 
if (1) {
size_t maxlength = 20;
char * payload = malloc(maxlength);
if(payload == NULL) {
printf("FATAL: ThingML runtime failed to allocate memory serializing message to JSON. Exiting.");
exit(-1);
}
uint16_t index = 0;
int result = 0;
payload[index++] = '{';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "interval");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%u", interval);
if (result >= 0) { index += result; } else { return; }
payload[index++] = '}';
payload[index++] = 0;
f_BLEGatewayPortExt_PosixMqttJson_Impl_publish_message(_instance, "heartbeat_ble", payload, strlen(payload));
free(payload);
BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 1;
}
}
void BLEGatewayPortExt_PosixMqttJson_Impl_handle_localext_ruuvi_measurement(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance, uint32_t timestamp, char * blemac, uint32_t deviceID, uint8_t humidity, int32_t temperature, int32_t pressure, int16_t ax, int16_t ay, int16_t az, uint16_t battery, int8_t rssi) {
if(!(_instance->active)) return;
//Region PosixMQTTJSonSC
uint8_t BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 0;
//End Region PosixMQTTJSonSC
//End dsregion PosixMQTTJSonSC
//Session list: 
if (1) {
size_t maxlength = 220 + strlen(blemac);
char * payload = malloc(maxlength);
if(payload == NULL) {
printf("FATAL: ThingML runtime failed to allocate memory serializing message to JSON. Exiting.");
exit(-1);
}
uint16_t index = 0;
int result = 0;
payload[index++] = '{';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "timestamp");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%u", timestamp);
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "blemac");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
if (blemac) { result = sprintf(&payload[index],"\"%.*s\"", 220-index, blemac); }
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "deviceID");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%u", deviceID);
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "humidity");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%u", humidity);
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "temperature");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%d", temperature);
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "pressure");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%d", pressure);
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "ax");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%d", ax);
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "ay");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%d", ay);
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "az");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%d", az);
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "battery");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%u", battery);
if (result >= 0) { index += result; } else { return; }
payload[index++] = ',';payload[index++] = ' ';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "rssi");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%d", rssi);
if (result >= 0) { index += result; } else { return; }
payload[index++] = '}';
payload[index++] = 0;
f_BLEGatewayPortExt_PosixMqttJson_Impl_publish_message(_instance, "ruuvi_measurement", payload, strlen(payload));
free(payload);
BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 1;
}
}
void BLEGatewayPortExt_PosixMqttJson_Impl_handle_localext_ble_error(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance, uint8_t device) {
if(!(_instance->active)) return;
//Region PosixMQTTJSonSC
uint8_t BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 0;
//End Region PosixMQTTJSonSC
//End dsregion PosixMQTTJSonSC
//Session list: 
if (1) {
size_t maxlength = 18;
char * payload = malloc(maxlength);
if(payload == NULL) {
printf("FATAL: ThingML runtime failed to allocate memory serializing message to JSON. Exiting.");
exit(-1);
}
uint16_t index = 0;
int result = 0;
payload[index++] = '{';
payload[index++] = '"'; result = sprintf(&payload[index],"%s", "device");
if (result >= 0) { index += result; payload[index++] = '"';payload[index++] = ':';} else { return; }
result = sprintf(&payload[index], "%u", device);
if (result >= 0) { index += result; } else { return; }
payload[index++] = '}';
payload[index++] = 0;
f_BLEGatewayPortExt_PosixMqttJson_Impl_publish_message(_instance, "ble_error", payload, strlen(payload));
free(payload);
BLEGatewayPortExt_PosixMqttJson_Impl_PosixMQTTJSonSC_State_event_consumed = 1;
}
}

// Observers for outgoing messages:
void (*external_BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener)(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t)= 0x0;
void (*BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener)(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t)= 0x0;
void register_external_BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(void (*_listener)(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t)){
external_BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener = _listener;
}
void register_BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(void (*_listener)(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *, char *, uint8_t *, uint32_t)){
BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener = _listener;
}
void BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic, uint8_t * payload, uint32_t size){
if (BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener != 0x0) BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(_instance, topic, payload, size);
if (external_BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener != 0x0) external_BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_publish_listener(_instance, topic, payload, size);
;
}
void (*external_BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener)(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *, char *)= 0x0;
void (*BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener)(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *, char *)= 0x0;
void register_external_BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(void (*_listener)(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *, char *)){
external_BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener = _listener;
}
void register_BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(void (*_listener)(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *, char *)){
BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener = _listener;
}
void BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe(struct BLEGatewayPortExt_PosixMqttJson_Impl_Instance *_instance, char * topic){
if (BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener != 0x0) BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(_instance, topic);
if (external_BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener != 0x0) external_BLEGatewayPortExt_PosixMqttJson_Impl_send_posixmqtt_mqtt_subscribe_listener(_instance, topic);
;
}



