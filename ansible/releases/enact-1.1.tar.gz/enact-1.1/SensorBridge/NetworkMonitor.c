/*****************************************************
 *      THIS IS A GENERATED FILE. DO NOT EDIT.
 *        Implementation for Thing NetworkMonitor
 *  Generated from ThingML (http://www.thingml.org)
 *****************************************************/

#include "NetworkMonitor.h"

/*****************************************************************************
 * Implementation for type : NetworkMonitor
 *****************************************************************************/

// Declaration of prototypes:
//Prototypes: State Machine
void NetworkMonitor_NetworkMonitorSC_OnExit(int state, struct NetworkMonitor_Instance *_instance);
//Prototypes: Message Sending
void NetworkMonitor_send_clock_timer_start(struct NetworkMonitor_Instance *_instance, uint8_t id, uint16_t time);
void NetworkMonitor_send_clock_timer_cancel(struct NetworkMonitor_Instance *_instance, uint8_t id);
void NetworkMonitor_send_monitor_network_heartbeat(struct NetworkMonitor_Instance *_instance);
void NetworkMonitor_send_monitor_network_connected(struct NetworkMonitor_Instance *_instance);
void NetworkMonitor_send_monitor_network_disconnected(struct NetworkMonitor_Instance *_instance);
//Prototypes: Function
bool f_NetworkMonitor_pingGoogle(struct NetworkMonitor_Instance *_instance);
void f_NetworkMonitor_startPingLoop(struct NetworkMonitor_Instance *_instance);
void f_NetworkMonitor_stopPingLoop(struct NetworkMonitor_Instance *_instance);
// Declaration of functions:
// Definition of function pingGoogle
bool f_NetworkMonitor_pingGoogle(struct NetworkMonitor_Instance *_instance) {
int sockfd = socket(AF_INET, SOCK_STREAM, 0);
		uint8_t result = 0;
		struct sockaddr_in addr = {AF_INET, htons(53), inet_addr("8.8.8.8")};
	    struct timeval timeout;
	    timeout.tv_sec = 1;
	    timeout.tv_usec = 0;
	    setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout, sizeof(timeout));
		if (connect(sockfd, (struct sockaddr *) &addr, sizeof(addr)) == 0) result = 1; 
		close(sockfd);
return result;
}
// Fork a thread to execute the function f_NetworkMonitor_startPingLoop

// Struct for the parameters of the function  f_NetworkMonitor_startPingLoop
struct f_NetworkMonitor_startPingLoop_struct {
  struct NetworkMonitor_Instance *_instance;

  pthread_mutex_t *lock;
  pthread_cond_t *cv;
};

// Definition of function start_receiver_process (executed in a separate thread)
void f_NetworkMonitor_startPingLoop_run(struct NetworkMonitor_Instance *_instance)
{
  bool lastping = f_NetworkMonitor_pingGoogle(_instance);
if(lastping) {
NetworkMonitor_send_monitor_network_connected(_instance);

} else {
NetworkMonitor_send_monitor_network_disconnected(_instance);

}
_instance->NetworkMonitor_stoploop_var = 0;
while( !(_instance->NetworkMonitor_stoploop_var)) {
if(f_NetworkMonitor_pingGoogle(_instance)) {
NetworkMonitor_send_monitor_network_heartbeat(_instance);
if(lastping == 0) {
NetworkMonitor_send_monitor_network_connected(_instance);

}
lastping = 1;

} else {
if(lastping == 1) {
NetworkMonitor_send_monitor_network_disconnected(_instance);
lastping = 0;

}

}
sleep(_instance->NetworkMonitor_delay_var);

}
fprintf(stdout, "Network Monitor Thread has terminated.\n");

}


void f_NetworkMonitor_startPingLoop_proc(void * p)
{
  // Get parameters from the main thread
  struct f_NetworkMonitor_startPingLoop_struct params = *((struct f_NetworkMonitor_startPingLoop_struct *) p);
  
  // Unblock the main thread
  pthread_mutex_lock(params.lock);
  pthread_cond_signal(params.cv);
  pthread_mutex_unlock(params.lock);
  
  // Run the function
  //f_NetworkMonitor_startPingLoop_run(params._instance, params.esums_device);
  f_NetworkMonitor_startPingLoop_run(params._instance);
}

// Operation called by the runtime and forking a new thread
void f_NetworkMonitor_startPingLoop(struct NetworkMonitor_Instance *_instance)
{
  // Store parameters
  struct f_NetworkMonitor_startPingLoop_struct params;
  pthread_mutex_t lock;
  pthread_cond_t cv;
  params.lock = &lock;
  params.cv = &cv;
  params._instance = _instance;

  pthread_mutex_init(params.lock, NULL);
  pthread_cond_init(params.cv, NULL);
  //Start the new thread
  pthread_mutex_lock(params.lock);
  pthread_t thread; 
  pthread_create( &thread, NULL, f_NetworkMonitor_startPingLoop_proc, (void*) &params);
  // Wait until it has started and read its parameters
  pthread_cond_wait(params.cv, params.lock);
  // Realease mutex
  pthread_mutex_unlock(params.lock);
}// Definition of function stopPingLoop
void f_NetworkMonitor_stopPingLoop(struct NetworkMonitor_Instance *_instance) {
_instance->NetworkMonitor_stoploop_var = 1;
}

// Sessions functionss:


// On Entry Actions:
void NetworkMonitor_NetworkMonitorSC_OnEntry(int state, struct NetworkMonitor_Instance *_instance) {
switch(state) {
case NETWORKMONITOR_NETWORKMONITORSC_STATE:{
_instance->NetworkMonitor_NetworkMonitorSC_State = NETWORKMONITOR_NETWORKMONITORSC_IDLE_STATE;
NetworkMonitor_NetworkMonitorSC_OnEntry(_instance->NetworkMonitor_NetworkMonitorSC_State, _instance);
break;
}
case NETWORKMONITOR_NETWORKMONITORSC_ACTIVE_STATE:{
break;
}
case NETWORKMONITOR_NETWORKMONITORSC_IDLE_STATE:{
break;
}
default: break;
}
}

// On Exit Actions:
void NetworkMonitor_NetworkMonitorSC_OnExit(int state, struct NetworkMonitor_Instance *_instance) {
switch(state) {
case NETWORKMONITOR_NETWORKMONITORSC_STATE:{
NetworkMonitor_NetworkMonitorSC_OnExit(_instance->NetworkMonitor_NetworkMonitorSC_State, _instance);
break;}
case NETWORKMONITOR_NETWORKMONITORSC_ACTIVE_STATE:{
break;}
case NETWORKMONITOR_NETWORKMONITORSC_IDLE_STATE:{
break;}
default: break;
}
}

// Event Handlers for incoming messages:
void NetworkMonitor_handle_monitor_start_netmonitor(struct NetworkMonitor_Instance *_instance, uint8_t interval) {
if(!(_instance->active)) return;
//Region NetworkMonitorSC
uint8_t NetworkMonitor_NetworkMonitorSC_State_event_consumed = 0;
if (_instance->NetworkMonitor_NetworkMonitorSC_State == NETWORKMONITOR_NETWORKMONITORSC_IDLE_STATE) {
if (NetworkMonitor_NetworkMonitorSC_State_event_consumed == 0 && 1) {
NetworkMonitor_NetworkMonitorSC_OnExit(NETWORKMONITOR_NETWORKMONITORSC_IDLE_STATE, _instance);
_instance->NetworkMonitor_NetworkMonitorSC_State = NETWORKMONITOR_NETWORKMONITORSC_ACTIVE_STATE;
_instance->NetworkMonitor_delay_var = interval;
f_NetworkMonitor_startPingLoop(_instance);
NetworkMonitor_NetworkMonitorSC_OnEntry(NETWORKMONITOR_NETWORKMONITORSC_ACTIVE_STATE, _instance);
NetworkMonitor_NetworkMonitorSC_State_event_consumed = 1;
}
}
//End Region NetworkMonitorSC
//End dsregion NetworkMonitorSC
//Session list: 
}
void NetworkMonitor_handle_monitor_stop_netmonitor(struct NetworkMonitor_Instance *_instance) {
if(!(_instance->active)) return;
//Region NetworkMonitorSC
uint8_t NetworkMonitor_NetworkMonitorSC_State_event_consumed = 0;
if (_instance->NetworkMonitor_NetworkMonitorSC_State == NETWORKMONITOR_NETWORKMONITORSC_ACTIVE_STATE) {
if (NetworkMonitor_NetworkMonitorSC_State_event_consumed == 0 && 1) {
NetworkMonitor_NetworkMonitorSC_OnExit(NETWORKMONITOR_NETWORKMONITORSC_ACTIVE_STATE, _instance);
_instance->NetworkMonitor_NetworkMonitorSC_State = NETWORKMONITOR_NETWORKMONITORSC_IDLE_STATE;
f_NetworkMonitor_stopPingLoop(_instance);
NetworkMonitor_NetworkMonitorSC_OnEntry(NETWORKMONITOR_NETWORKMONITORSC_IDLE_STATE, _instance);
NetworkMonitor_NetworkMonitorSC_State_event_consumed = 1;
}
}
//End Region NetworkMonitorSC
//End dsregion NetworkMonitorSC
//Session list: 
}

// Observers for outgoing messages:
void (*external_NetworkMonitor_send_clock_timer_start_listener)(struct NetworkMonitor_Instance *, uint8_t, uint16_t)= 0x0;
void (*NetworkMonitor_send_clock_timer_start_listener)(struct NetworkMonitor_Instance *, uint8_t, uint16_t)= 0x0;
void register_external_NetworkMonitor_send_clock_timer_start_listener(void (*_listener)(struct NetworkMonitor_Instance *, uint8_t, uint16_t)){
external_NetworkMonitor_send_clock_timer_start_listener = _listener;
}
void register_NetworkMonitor_send_clock_timer_start_listener(void (*_listener)(struct NetworkMonitor_Instance *, uint8_t, uint16_t)){
NetworkMonitor_send_clock_timer_start_listener = _listener;
}
void NetworkMonitor_send_clock_timer_start(struct NetworkMonitor_Instance *_instance, uint8_t id, uint16_t time){
if (NetworkMonitor_send_clock_timer_start_listener != 0x0) NetworkMonitor_send_clock_timer_start_listener(_instance, id, time);
if (external_NetworkMonitor_send_clock_timer_start_listener != 0x0) external_NetworkMonitor_send_clock_timer_start_listener(_instance, id, time);
;
}
void (*external_NetworkMonitor_send_clock_timer_cancel_listener)(struct NetworkMonitor_Instance *, uint8_t)= 0x0;
void (*NetworkMonitor_send_clock_timer_cancel_listener)(struct NetworkMonitor_Instance *, uint8_t)= 0x0;
void register_external_NetworkMonitor_send_clock_timer_cancel_listener(void (*_listener)(struct NetworkMonitor_Instance *, uint8_t)){
external_NetworkMonitor_send_clock_timer_cancel_listener = _listener;
}
void register_NetworkMonitor_send_clock_timer_cancel_listener(void (*_listener)(struct NetworkMonitor_Instance *, uint8_t)){
NetworkMonitor_send_clock_timer_cancel_listener = _listener;
}
void NetworkMonitor_send_clock_timer_cancel(struct NetworkMonitor_Instance *_instance, uint8_t id){
if (NetworkMonitor_send_clock_timer_cancel_listener != 0x0) NetworkMonitor_send_clock_timer_cancel_listener(_instance, id);
if (external_NetworkMonitor_send_clock_timer_cancel_listener != 0x0) external_NetworkMonitor_send_clock_timer_cancel_listener(_instance, id);
;
}
void (*external_NetworkMonitor_send_monitor_network_heartbeat_listener)(struct NetworkMonitor_Instance *)= 0x0;
void (*NetworkMonitor_send_monitor_network_heartbeat_listener)(struct NetworkMonitor_Instance *)= 0x0;
void register_external_NetworkMonitor_send_monitor_network_heartbeat_listener(void (*_listener)(struct NetworkMonitor_Instance *)){
external_NetworkMonitor_send_monitor_network_heartbeat_listener = _listener;
}
void register_NetworkMonitor_send_monitor_network_heartbeat_listener(void (*_listener)(struct NetworkMonitor_Instance *)){
NetworkMonitor_send_monitor_network_heartbeat_listener = _listener;
}
void NetworkMonitor_send_monitor_network_heartbeat(struct NetworkMonitor_Instance *_instance){
if (NetworkMonitor_send_monitor_network_heartbeat_listener != 0x0) NetworkMonitor_send_monitor_network_heartbeat_listener(_instance);
if (external_NetworkMonitor_send_monitor_network_heartbeat_listener != 0x0) external_NetworkMonitor_send_monitor_network_heartbeat_listener(_instance);
;
}
void (*external_NetworkMonitor_send_monitor_network_connected_listener)(struct NetworkMonitor_Instance *)= 0x0;
void (*NetworkMonitor_send_monitor_network_connected_listener)(struct NetworkMonitor_Instance *)= 0x0;
void register_external_NetworkMonitor_send_monitor_network_connected_listener(void (*_listener)(struct NetworkMonitor_Instance *)){
external_NetworkMonitor_send_monitor_network_connected_listener = _listener;
}
void register_NetworkMonitor_send_monitor_network_connected_listener(void (*_listener)(struct NetworkMonitor_Instance *)){
NetworkMonitor_send_monitor_network_connected_listener = _listener;
}
void NetworkMonitor_send_monitor_network_connected(struct NetworkMonitor_Instance *_instance){
if (NetworkMonitor_send_monitor_network_connected_listener != 0x0) NetworkMonitor_send_monitor_network_connected_listener(_instance);
if (external_NetworkMonitor_send_monitor_network_connected_listener != 0x0) external_NetworkMonitor_send_monitor_network_connected_listener(_instance);
;
}
void (*external_NetworkMonitor_send_monitor_network_disconnected_listener)(struct NetworkMonitor_Instance *)= 0x0;
void (*NetworkMonitor_send_monitor_network_disconnected_listener)(struct NetworkMonitor_Instance *)= 0x0;
void register_external_NetworkMonitor_send_monitor_network_disconnected_listener(void (*_listener)(struct NetworkMonitor_Instance *)){
external_NetworkMonitor_send_monitor_network_disconnected_listener = _listener;
}
void register_NetworkMonitor_send_monitor_network_disconnected_listener(void (*_listener)(struct NetworkMonitor_Instance *)){
NetworkMonitor_send_monitor_network_disconnected_listener = _listener;
}
void NetworkMonitor_send_monitor_network_disconnected(struct NetworkMonitor_Instance *_instance){
if (NetworkMonitor_send_monitor_network_disconnected_listener != 0x0) NetworkMonitor_send_monitor_network_disconnected_listener(_instance);
if (external_NetworkMonitor_send_monitor_network_disconnected_listener != 0x0) external_NetworkMonitor_send_monitor_network_disconnected_listener(_instance);
;
}



