deb-packages documentation is available in the following section of CompuLab's website:
[Products] >> [Computer-on-Modules] >> [IOT-GATE-RPi] >> [Development Resources] >>
IOT-GATE-RPi deb-packages documentation link
