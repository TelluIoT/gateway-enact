#!/bin/bash

apt install -y ./iot-gate-dt.deb
apt install -y ./iot-gate-eth.deb
apt install -y ./rpi3-rtc.deb
apt install -y ./iot-gate-serial.deb
apt install -y ./rpi3-modem.deb
